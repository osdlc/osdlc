/**
 * `@sksizer/command-seam` — one injectable contract for running external
 * binaries, in four doors: two that CAPTURE a finished run (sync and async),
 * one that STREAMS a finished run with inherited stdio, and one that hands
 * back a HANDLE to a still-running, supervised process.
 *
 * The seam exists so that "shell out to `git`" — or to a build, a live
 * process the operator must see, or a long-lived one the caller
 * supervises — is a dependency a caller supplies rather than an ambient
 * capability: production wires `spawnRunner(binary)` /
 * `spawnRunnerAsync(binary)` / `streamRunner(binary)` /
 * `managedProcessRunner(binary)`, tests inject a fake, and a host with its
 * own process supervision injects that. The two capture doors share one
 * vocabulary — {@link CommandResult}, {@link CommandRunOptions},
 * {@link CommandFailed} — so a call site can move between them without
 * re-learning the contract, and one `instanceof CommandFailed` check matches
 * failures from either. The streaming door reuses that same options shape
 * (minus `input`); the managed-process door is its own contract, since
 * "hand back a running handle" has no capture/exit-code result to share.
 */

export {
  catchFailed,
  CommandFailed,
  mapFailed,
  resolveRunner,
  runChecked,
  spawnRunner,
  type CommandResult,
  type CommandRunner,
  type CommandRunOptions,
  type EnvOverrides,
} from './sync.ts'

export {
  asAsync,
  catchFailedAsync,
  mapFailedAsync,
  resolveRunnerAsync,
  runCheckedAsync,
  spawnRunnerAsync,
  type AsyncCommandRunner,
  type AsyncCommandRunOptions,
} from './async.ts'

export {
  failureText,
  firstLine,
  parseJsonResult,
  ran,
  runJson,
  runJsonAsync,
  type JsonRun,
  type RunJsonOptions,
} from './result.ts'

export { shellJoin, shellQuote } from './quote.ts'

export {
  runShell,
  runShellAsync,
  shellRunner,
  shellRunnerAsync,
  type AsyncShellRunner,
  type AsyncShellRunOptions,
  type ShellRunner,
  type ShellPositionals,
  type ShellRunOptions,
} from './shell.ts'

export {
  streamRunner,
  type StreamRunner,
  type StreamRunOptions,
  type StreamResult,
} from './stream.ts'

export {
  managedProcessRunner,
  type ManagedProcessRunner,
  type ManagedProcessHandle,
  type ManagedProcessOptions,
  type ManagedProcessExit,
} from './process.ts'
