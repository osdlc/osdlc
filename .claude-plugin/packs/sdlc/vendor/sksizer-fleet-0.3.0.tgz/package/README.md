# @sksizer/fleet

This repo's wrapper over [`@osdlc/tiered-dirs`](https://www.npmjs.com/package/@osdlc/tiered-dirs).
It fixes the two things that belong to this repo and keeps the `Fleet` API every in-repo caller
uses:

- `VENDOR` is `com.sizerllc`. The vendor tier is `com.sizerllc`, and a suite is
  `com.sizerllc.<suiteKey>`.
- The override variables are `FLEET_ROOT`, `FLEET_<HOME>_DIR`,
  `FLEET_SCRATCH_DIR`, `FLEET_REQUIRE_OVERRIDE` and `FLEET_CONVENTION`
  (`ENV_VARS`, `ROOT_VAR`, `OVERRIDE_VAR`, `OVERRIDE_VARS`).

`Fleet.fromSystem` uses the native per-OS table, for GUI apps. `Fleet.cli`
uses the XDG table, for CLI and developer tools. `FLEET_CONVENTION` overrides
both, so setting it flips GUI and CLI programs alike.

```ts
import { Fleet } from '@sksizer/fleet';

const fleet = Fleet.fromSystem();

fleet.suite('determined').cache().scoped('vaults', vaultId).app('vault-search').path;
// ~/Library/Caches/com.sizerllc.determined/vaults/<vaultId>/vault-search

Fleet.cli().standalone('sdlc').config().path; // ~/.config/sdlc on Linux and macOS
```

The suite segment is composed from `VENDOR`, never derived from a bundle
identifier: derivation from `com.sizerllc.family.*` would yield
`com.sizerllc.family`, the brand being retired.

## API

```ts
const VENDOR: 'com.sizerllc';
const ENV_VARS: EnvVars;               // envVars('FLEET')
const ROOT_VAR: string;                // 'FLEET_ROOT'
const OVERRIDE_VAR: Record<keyof BaseDirs, string>;
const OVERRIDE_VARS: readonly string[];

function systemBaseDirs(opts?: ResolveOptions): BaseDirs;  // reads FLEET_*

class Fleet extends TieredDirs {
  constructor(bases: BaseDirs);
  static fromSystem(opts?: ResolveOptions): Fleet;
  static cli(opts?: ResolveOptions): Fleet;    // convention: 'xdg'
}
```

`FleetTier` is the `Tier` type (type-only, so it cannot be constructed or used with `instanceof`)
and `FleetError` is `TieredDirsError` (it carries a `code`) from `@osdlc/tiered-dirs` under their
old names. `TieredDirs`, `rootedBaseDirs`, `isValidSegment` and the types are re-exported unchanged.
See the [tiered-dirs README](https://www.npmjs.com/package/@osdlc/tiered-dirs) for the tier and home
model, the per-OS table, the override order and the test-root rules.

The Rust `fleet` crate is the twin of this package, over the `tiered-dirs`
crate.
