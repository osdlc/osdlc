import { describe, expect, test } from 'bun:test'

import { selectByScope } from './select.js'

describe('selectByScope', () => {
  test('maps each entry to its matching files in changeset order', () => {
    const { covered, unmatched } = selectByScope(
      [
        { id: 'src', patterns: ['src/**'] },
        { id: 'docs', patterns: ['docs/**'] },
        { id: 'all', patterns: ['**'] },
      ],
      ['src/a.ts', 'README.md', 'src/b.ts'],
      [],
    )

    expect(covered.get('src')).toEqual(['src/a.ts', 'src/b.ts'])
    expect(covered.get('all')).toEqual(['src/a.ts', 'README.md', 'src/b.ts'])
    expect(covered.has('docs')).toBe(false)
    expect(unmatched).toEqual(['docs'])
  })

  test('an entry with several patterns matches any of them', () => {
    const { covered } = selectByScope(
      [{ id: 'e', patterns: ['src/**', 'docs/**'] }],
      ['docs/x.md', 'src/y.ts', 'other.txt'],
      [],
    )

    expect(covered.get('e')).toEqual(['docs/x.md', 'src/y.ts'])
  })

  test('exclude patterns drop files before matching', () => {
    const { covered, unmatched } = selectByScope(
      [
        { id: 'e', patterns: ['**'] },
        { id: 'lock', patterns: ['*.lock'] },
      ],
      ['a.ts', 'bun.lock'],
      ['*.lock'],
    )

    expect(covered.get('e')).toEqual(['a.ts'])
    expect(unmatched).toEqual(['lock'])
  })

  test('unmatched keeps entry order; an empty changeset matches nothing', () => {
    const { covered, unmatched } = selectByScope(
      [
        { id: 'b', patterns: ['b/**'] },
        { id: 'a', patterns: ['a/**'] },
      ],
      [],
      [],
    )

    expect(covered.size).toBe(0)
    expect(unmatched).toEqual(['b', 'a'])
  })
})
