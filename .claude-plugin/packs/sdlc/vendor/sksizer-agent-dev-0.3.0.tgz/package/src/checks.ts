/**
 * Run a folder of checks and report the verdicts.
 *
 * Script checks run one after another in prefix order, each with its cwd at
 * the project root. With a changeset, a script runs only when its scope
 * matches a changed file, and reads those files on stdin. Processes are
 * started through `@sksizer/command-seam`, through a runner the caller can
 * replace. Each script leads its own process group, so a timeout or abort also
 * kills the processes it started.
 */
import { spawnRunnerAsync, type AsyncCommandRunner } from '@sksizer/command-seam'

import { selectByScope } from './select.js'
import {
  PROMPT_UNSUPPORTED,
  type CheckFolder,
  type ScriptCheck,
  type SkippedEntry,
} from './providers/check-folder.js'

export type CheckStatus = 'PASS' | 'FAIL' | 'SKIP' | 'ERROR'

export interface CheckResult {
  /** File name inside the folder. */
  entry: string
  status: CheckStatus
  /** Why the check failed, errored or was skipped. */
  reason?: string
  durationMs: number
  exitCode?: number
  stdout?: string
  stderr?: string
}

export interface ChecksRun {
  dir: string
  results: CheckResult[]
}

/** What a run is judged against: the changed files and the label scripts see as `CHECK_BASE`. */
export interface ChecksChangeset {
  /** Repo-relative paths. */
  files: readonly string[]
  /** Passed to scripts as `CHECK_BASE`. */
  base: string
}

/** Reason for a script whose scope matches no changed file. */
export const NO_FILES_IN_SCOPE = 'no changed files in scope'

export interface RunChecksOptions {
  projectRoot: string
  /** Select script checks by scope; without it every script runs with empty stdin. */
  changeset?: ChecksChangeset | undefined
  /** Builds the runner for one script path. Default: `spawnRunnerAsync`. */
  runnerFor?: (path: string) => AsyncCommandRunner
  /** Monotonic clock in milliseconds. Default: `performance.now`. */
  now?: () => number
  /** Aborting kills the running check and stops the run. */
  signal?: AbortSignal
}

/** What a run would execute and what it would skip. */
export interface ChecksPlan {
  dir: string
  run: Array<Pick<ScriptCheck, 'entry' | 'order' | 'name' | 'timeoutSec'>>
  skipped: SkippedEntry[]
}

/** The environment a script check sees, on top of the parent's. */
export function checkEnv(
  check: ScriptCheck,
  folder: CheckFolder,
  projectRoot: string,
  base?: string,
) {
  return {
    CHECK_ROOT: projectRoot,
    CHECK_NAME: check.name,
    CHECK_ORDER: String(check.order),
    CHECK_DIR: folder.dir,
    ...(base === undefined ? {} : { CHECK_BASE: base }),
  }
}

/**
 * In-scope files per script entry; a script absent from the map matches no
 * changed file. Without a changeset every script is selected with no files.
 */
export function selectScripts(
  folder: CheckFolder,
  changeset: ChecksChangeset | undefined,
): Map<string, string[]> {
  const scripts = folder.checks.filter((c): c is ScriptCheck => c.kind === 'script')
  if (changeset === undefined) return new Map(scripts.map((c) => [c.entry, []]))
  return selectByScope(
    scripts.map((c) => ({ id: c.entry, patterns: c.scope })),
    changeset.files,
    [],
  ).covered
}

/** Split a folder into what runs and what is skipped, without running it. */
export function planChecks(folder: CheckFolder, changeset?: ChecksChangeset): ChecksPlan {
  const selected = selectScripts(folder, changeset)
  const run: ChecksPlan['run'] = []
  const skipped: SkippedEntry[] = []
  for (const check of folder.checks) {
    if (check.kind === 'script') {
      if (!selected.has(check.entry)) {
        skipped.push({ entry: check.entry, reason: NO_FILES_IN_SCOPE })
        continue
      }
      run.push({
        entry: check.entry,
        order: check.order,
        name: check.name,
        timeoutSec: check.timeoutSec,
      })
    } else {
      skipped.push({ entry: check.entry, reason: PROMPT_UNSUPPORTED })
    }
  }
  return { dir: folder.dir, run, skipped: [...skipped, ...folder.skipped] }
}

async function runScript(
  check: ScriptCheck,
  folder: CheckFolder,
  opts: RunChecksOptions,
  files: readonly string[],
): Promise<CheckResult> {
  const runnerFor = opts.runnerFor ?? spawnRunnerAsync
  const now = opts.now ?? (() => performance.now())
  const timeoutMs = check.timeoutSec * 1000
  const started = now()
  const result = await runnerFor(check.path).run([], {
    cwd: opts.projectRoot,
    env: checkEnv(check, folder, opts.projectRoot, opts.changeset?.base),
    timeoutMs,
    input: files.map((f) => `${f}\n`).join(''),
    signal: opts.signal,
    processGroup: true,
  })
  const durationMs = Math.round(now() - started)
  const base = { entry: check.entry, durationMs, stdout: result.stdout, stderr: result.stderr }

  if (opts.signal?.aborted === true) return { ...base, status: 'ERROR', reason: 'interrupted' }
  if (result.neverExited === true) {
    // The seam reports a timeout kill, a signal and a failed start alike.
    if (durationMs >= timeoutMs) {
      return { ...base, status: 'ERROR', reason: `timed out after ${check.timeoutSec}s` }
    }
    const detail = result.stderr.trim()
    return {
      ...base,
      status: 'ERROR',
      reason: `terminated by signal or failed to start${detail === '' ? '' : `: ${detail}`}`,
    }
  }
  if (result.exitCode === 0) return { ...base, status: 'PASS', exitCode: 0 }
  return {
    ...base,
    status: 'FAIL',
    exitCode: result.exitCode,
    reason: `exit ${result.exitCode}`,
  }
}

/**
 * Run every selected script check in order. A script whose scope matches no
 * changed file is SKIP in its place; prompt checks and skipped entries follow
 * as SKIP. An abort ends the run after the check it interrupted.
 */
export async function runChecks(folder: CheckFolder, opts: RunChecksOptions): Promise<ChecksRun> {
  const selected = selectScripts(folder, opts.changeset)
  const results: CheckResult[] = []
  for (const check of folder.checks) {
    if (opts.signal?.aborted === true) break
    if (check.kind === 'prompt') {
      results.push({
        entry: check.entry,
        status: 'SKIP',
        reason: PROMPT_UNSUPPORTED,
        durationMs: 0,
      })
    } else {
      const files = selected.get(check.entry)
      results.push(
        files === undefined
          ? { entry: check.entry, status: 'SKIP', reason: NO_FILES_IN_SCOPE, durationMs: 0 }
          : await runScript(check, folder, opts, files),
      )
    }
  }
  for (const s of folder.skipped) {
    results.push({ entry: s.entry, status: 'SKIP', reason: s.reason, durationMs: 0 })
  }
  return { dir: folder.dir, results }
}

export function summarize(results: CheckResult[]): Record<CheckStatus, number> {
  const counts: Record<CheckStatus, number> = { PASS: 0, FAIL: 0, SKIP: 0, ERROR: 0 }
  for (const r of results) counts[r.status]++
  return counts
}

/** 1 when any check failed or errored, else 0. */
export function checksExitCode(results: CheckResult[]): 0 | 1 {
  return results.some((r) => r.status === 'FAIL' || r.status === 'ERROR') ? 1 : 0
}

export function formatDuration(ms: number): string {
  return ms < 1000 ? `${ms}ms` : `${(ms / 1000).toFixed(1)}s`
}

function summaryLine(counts: Record<CheckStatus, number>): string {
  return `${counts.PASS} passed, ${counts.FAIL} failed, ${counts.ERROR} errored, ${counts.SKIP} skipped`
}

/** Output lines under a failing check, indented. */
function indentedOutput(r: CheckResult): string[] {
  const text = [r.stdout, r.stderr]
    .map((s) => (s ?? '').trimEnd())
    .filter((s) => s !== '')
    .join('\n')
  return text === '' ? [] : text.split('\n').map((l) => `        ${l}`)
}

/** One line per check, failure output indented beneath it, then a summary. */
export function formatReport(run: ChecksRun): string {
  const lines: string[] = []
  for (const r of run.results) {
    const parts = [r.status.padEnd(5), r.entry]
    if (r.reason !== undefined) parts.push(`- ${r.reason}`)
    if (r.status !== 'SKIP') parts.push(`(${formatDuration(r.durationMs)})`)
    lines.push(parts.join(' '))
    if (r.status === 'FAIL' || r.status === 'ERROR') lines.push(...indentedOutput(r))
  }
  lines.push('', summaryLine(summarize(run.results)))
  return lines.join('\n') + '\n'
}

/** The `--dry-run` text: what would run, then what is skipped and why. */
export function formatPlan(plan: ChecksPlan): string {
  const lines = plan.run.map((c) => `RUN   ${c.entry} (timeout ${c.timeoutSec}s)`)
  for (const s of plan.skipped) lines.push(`SKIP  ${s.entry} - ${s.reason}`)
  lines.push('', `${plan.run.length} would run, ${plan.skipped.length} skipped. Nothing was run.`)
  return lines.join('\n') + '\n'
}

/** The `--json` form of a run. */
export function runToJson(run: ChecksRun): {
  dir: string
  results: CheckResult[]
  summary: Record<CheckStatus, number>
} {
  return { dir: run.dir, results: run.results, summary: summarize(run.results) }
}
