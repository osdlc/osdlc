/**
 * Scope selection: which entries does a changeset touch?
 *
 * Pure. Shared by rule-source planning and script-check selection so both use
 * one matcher.
 */
import { index, matches } from '@sksizer/intersect'

export interface ScopeEntry {
  id: string
  patterns: readonly string[]
}

export interface ScopeSelection {
  /** Matched entry id to its in-scope files, in changeset order. */
  covered: Map<string, string[]>
  /** Ids of entries that matched no file, in entry order. */
  unmatched: string[]
}

/**
 * Pair every entry with the changed files its patterns match.
 *
 * @param entries - Ids must be unique; the intersect registry rejects duplicates.
 * @param changedFiles - Repo-relative paths in the changeset.
 * @param exclude - Patterns that remove files from the changeset first.
 */
export function selectByScope(
  entries: readonly ScopeEntry[],
  changedFiles: readonly string[],
  exclude: readonly string[],
): ScopeSelection {
  const files =
    exclude.length === 0 ? [...changedFiles] : changedFiles.filter((f) => !matches(f, [...exclude]))

  const registry = index(entries.map((e) => ({ id: e.id, patterns: [...e.patterns] })))

  // The registry answers "which entries cover this path", so query per file and invert.
  const covered = new Map<string, string[]>()
  for (const file of files) {
    for (const id of registry.matching(file)) {
      const group = covered.get(id)
      if (group === undefined) covered.set(id, [file])
      else group.push(file)
    }
  }

  const unmatched = entries.filter((e) => !covered.has(e.id)).map((e) => e.id)
  return { covered, unmatched }
}
