/**
 * Reading the changeset out of git.
 *
 * Goes through `@osdlc/typed-git`'s typed client — no hand-built argv.
 */
import { Git } from '@osdlc/typed-git'

import type { FileDiff } from './prompt.js'

export interface Changeset {
  /** The ref the changeset was computed against. */
  base: string
  files: string[]
}

/**
 * Resolve the default comparison base: the remote's own default branch.
 *
 * Falls back to `main` when the symbolic ref is absent — a fresh clone, or a
 * repo whose `origin/HEAD` was never set.
 */
export function defaultBase(git: Git): string {
  const head = git.revParse('--abbrev-ref', 'origin/HEAD')
  if (head === null) return 'main'
  return head.startsWith('origin/') ? head.slice('origin/'.length) : head
}

/**
 * Rev syntax that names a commit directly rather than a branch.
 *
 * `HEAD` is the one that bites: `origin/HEAD` exists in any cloned repo as the
 * symbolic ref to the default branch, so treating every base as a branch name
 * silently rewrites `--base HEAD` into `--base main` and compares the whole
 * branch when the caller asked for the working tree.
 */
const NAMES_A_COMMIT = /^HEAD$|[~^:@]|^[0-9a-f]{7,40}$/

/**
 * Resolve `base` to the ref actually worth diffing against.
 *
 * A commit-naming rev (`HEAD`, a sha, `main~2`) is used as written — there is
 * no remote copy of those to prefer.
 *
 * For a branch name, the two refs can disagree in three ways: local behind
 * remote (a stale checkout that never fetched), local ahead of or diverged
 * from remote (an unpushed or rewritten branch), or only one of the two
 * existing at all (a branch never pushed, or named but not fetched locally).
 * Only the "local behind" case should prefer the remote copy — a local `main`
 * that lags would make already-merged commits look like part of this change.
 * Local ahead or diverged means the caller's own branch IS the fork point they
 * mean, and resolving to the remote's stale tip would walk the merge base
 * back past every commit they made — the 1075-unrelated-file bug this
 * function exists to close. When only one ref exists, that one is used;
 * neither existing falls through to the name as written, same as before.
 */
export function resolveBase(git: Git, base: string): string {
  if (NAMES_A_COMMIT.test(base)) return base
  const remote = `origin/${base}`
  const localExists = git.objectExists(base)
  const remoteExists = git.objectExists(remote)
  if (!localExists) return remoteExists ? remote : base
  if (!remoteExists) return base
  // Both exist: local an ancestor of (behind or equal to) remote keeps the
  // stale-branch protection; ahead or diverged uses the local ref.
  return git.isAncestor(base, remote) ? remote : base
}

/**
 * Resolve the comparison point: the merge base of `base` and `HEAD`.
 *
 * Diffing against the merge base rather than the branch tip means a stale base
 * branch does not make unrelated commits look like part of this change — the
 * `base...HEAD` guarantee — while still leaving a concrete rev the working
 * tree can be diffed against.
 */
function forkPoint(git: Git, base: string): string {
  const ref = resolveBase(git, base)
  return git.mergeBase(ref, 'HEAD') ?? ref
}

/**
 * Files changed between the fork point and the working tree.
 *
 * Uncommitted work is included deliberately. Under a pre-push hook the working
 * tree matches HEAD and this is the branch diff either way; run on demand
 * mid-change it reports what you are actually about to be judged on, rather
 * than an empty changeset because nothing is committed yet.
 */
export function changedFiles(git: Git, base: string): string[] {
  const tracked = git.diffNameOnly({ rangeArgs: [forkPoint(git, base)] })
  // `git diff` never lists an untracked file, so a brand-new file would go
  // unjudged — exactly the case a rule about new code most wants to see.
  const untracked = git.lsFiles({ others: true, excludeStandard: true })
  return [...new Set([...tracked, ...untracked])].sort()
}

/** Files added, copied, modified or renamed in the index, sorted. */
export function stagedFiles(git: Git): string[] {
  return git.diffNameOnly({ cached: true, diffFilter: 'ACMR' }).sort()
}

/** Every file in the index, sorted. */
export function trackedFiles(git: Git): string[] {
  return git.lsFiles({ cached: true }).sort()
}

/**
 * Unified diff per file.
 *
 * Deleted files are included, with their deletion diff. A file with no diff
 * against the base is rendered whole, as added (an untracked file, or an
 * unchanged one). A path with no diff that does not exist is left out. A
 * `base` that does not resolve throws, as does a failed `diffText`.
 * `git.try.diffAddedFile` swallows every `CommandFailed` (exit 2 included), so
 * a file it cannot render is left out, whatever the cause.
 */
export function fileDiffs(git: Git, base: string, files: readonly string[]): FileDiff[] {
  const ref = forkPoint(git, base)
  const out: FileDiff[] = []
  for (const file of files) {
    const tracked = git.diffText(ref, { paths: [file] }).trim()
    if (tracked !== '') {
      out.push({ file, diff: tracked })
      continue
    }
    // Untracked files produce no diff above; render them as all-added so new
    // and modified files reach the judge in the same shape.
    // `try` turns any `CommandFailed` from `diffAddedFile` into a skip.
    const added = git.try.diffAddedFile(file)
    if (added.ok && added.value.trim() !== '') out.push({ file, diff: added.value.trim() })
  }
  return out
}
