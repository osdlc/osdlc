# Contributing

Thanks for your interest in this package.

## Issues

Report bugs and ask for features in the issue tracker of the repository that
hosts this package. For a bug, include the package version, your runtime and
its version, your operating system, and the command or call and inputs that
misbehave. Report security problems privately. See [SECURITY.md](./SECURITY.md).

## Pull requests

Open pull requests against the repository that hosts this package. They are
reviewed and merged there.

## Running the tests

The tests run under [Vitest](https://vitest.dev). Install dependencies,
then run the checks from the package directory.

```sh
bun install
bun run test
```

Other checks:

```sh
bun run typecheck
bun run lint
bun run format:check
```

## Code style

- TypeScript and ES modules, with `.js` suffixes on relative imports. The package ships
  TypeScript source, so there is no build step.
- Prettier formats the code and oxlint checks it. Run `bun run format` and
  `bun run lint` before you commit.
- Add a test for each behaviour change or bug fix.
- A new export gets TSDoc and an example in a `tests/*.usage.test.ts` file.
- Tests must not need the network or an agent.
