# @osdlc/agent-dev

Verify a changeset against the rules that actually govern it.

A repository's rules are scattered across nested `CLAUDE.md` files, `AGENTS.md`
files, and whatever formal standards corpus it keeps. They are read while code
is being written and forgotten by the time it is committed. This package finds
every rule source whose scope encloses a changed file and dispatches one
headless judgement per source, over exactly the files it covers.

```ts
import {
  changedFiles, defaultBase, discoverSources, fileDiffs,
  instructionFiles, verify, DEFAULT_CONFIG,
} from "@osdlc/agent-dev";
import { Git } from "@osdlc/typed-git";

const git = new Git(projectRoot);
const base = defaultBase(git);
const files = changedFiles(git, base);

const sources = await discoverSources([instructionFiles()], { projectRoot, changedFiles: files });
const run = await verify({
  projectRoot, sources, changedFiles: files,
  diffs: fileDiffs(git, base, files),
  config: { ...DEFAULT_CONFIG, model: "claude-haiku-4-5-20251001" },
});

run.findings;   // merged, ordered broad-to-specific
run.skipped;    // sources proven irrelevant — these cost nothing
run.degraded;   // true when a judgement failed to complete
```

## Install

```sh
npm install @osdlc/agent-dev
```

ESM only. Node.js 24 or later, or Bun 1.3 or later; the package ships TypeScript source.

## The `dfv` command

The package ships its own CLI. It needs nothing but a git repo — the
instruction-file provider reads the `CLAUDE.md` / `AGENTS.md` files already
there.

```bash
dfv                    # judge uncommitted work
dfv --dry-run          # what it would judge, and what that would cost — free
dfv --base main        # the whole branch
dfv --blocking         # exit non-zero on findings at or above the floor
dfv --json             # the run as JSON
dfv --max-files 6      # split wide rule sources into smaller judgements
```

`--base` takes any rev: a branch name for the whole branch, `@{u}` to include
unpushed commits, a sha or `HEAD~3` to reach further back. Omitted, it compares
against `HEAD` — uncommitted work only.

`dfv` ships one provider by design. Another rule corpus is a
`RuleSourceProvider` supplied by whatever owns it; teaching this binary about
one would put that knowledge in a package built to stay blind to it.

## `dfv checks`

`dfv checks <dir>` runs a folder of numbered check scripts. The folder is a
required argument.

```bash
dfv checks checks.d            # checks whose scope matches uncommitted work
dfv checks checks.d --base main  # ... or the files changed against main
dfv checks checks.d --staged   # ... or the staged files
dfv checks checks.d --all      # ... or every tracked file
dfv checks checks.d --dry-run  # list what would run and what is skipped
dfv checks checks.d --json     # the results as JSON
```

An executable file named `<number>-<name>` is a check, where the name matches
`[a-z0-9][a-z0-9._-]*`. Checks run one at a time, ordered by number and then
name, so `9-a` runs before `10-a`. A `.md` file is a prompt check; it is
listed and reported as skipped.

Everything else is skipped, and the report says why:

| Entry | Reason |
|---|---|
| no numeric prefix | `no numeric prefix` |
| a number prefix with a bad rest (`10_lint`, `10-`, `10-Lint`) | what is wrong with the rest |
| leading `.` or `_` | `leading '.'`, `leading '_'` |
| `.disabled` suffix | `disabled` |
| file without the executable bit | `not executable` |
| directory | `directory` |
| broken symlink | `broken symlink (ENOENT)` |
| file that cannot be read | `unreadable (<code>)` |

Each script runs with the project root as its working directory and these
variables set:

| Variable | Value |
|---|---|
| `CHECK_ROOT` | absolute project root |
| `CHECK_NAME` | the name after the number prefix, extension kept (`10-lint.sh` gives `lint.sh`) |
| `CHECK_ORDER` | the number prefix |
| `CHECK_DIR` | absolute path of the folder |
| `CHECK_BASE` | the base rev of the changeset: `HEAD` with no flag or `--staged`, the resolved rev with `--base`, empty with `--all` |

A script declares which files it cares about with `# applies_to: <glob>` lines
in its leading comments. Several lines add up; none means every file. A script
reads the changed files that match, one path per line, on stdin. One that
matches no changed file is skipped with `no changed files in scope`. `--base`,
`--staged` and `--all` are mutually exclusive. Outside git there is no
changeset, so every script runs with empty stdin and no `CHECK_BASE`.

A `# timeout: <seconds>` line in a script's leading comments sets its time
limit. The default is 600 seconds. Exit 0 passes and a non-zero exit fails. A
timeout or a signal is an error. Each script leads its own process group, and
a timeout kills the whole group, so the processes a script started do not
outlive it.

The report has one line per check, with its status (`PASS`, `FAIL`, `SKIP` or
`ERROR`), the reason and the duration, then a summary line. Output from a
failing check is indented under it, stdout first, then stderr. `-C <dir>` runs
from `<dir>` instead of the current directory. The project root is the git
top-level of that directory, or the directory itself outside git.

| Exit | Meaning |
|---|---|
| 0 | every check passed or was skipped |
| 1 | a check failed or errored |
| 2 | usage error, or the folder cannot be read |
| 130 | interrupted by SIGINT or SIGTERM; the running check's group is killed |

Scripts run through `@osdlc/command-seam`. `runChecks` takes a `runnerFor`
option, so tests and other callers can supply their own runner. Prompt
checks, concurrency and `--fail-fast` are not part of this
command yet.

## The model

Selection is set intersection, not a tree walk. Every rule source declares the
paths it governs, and `@osdlc/intersect` decides which ones the changeset
touches.

| Rule source | Scope |
|---|---|
| `CLAUDE.md` / `AGENTS.md` at directory `D` | `D/**`, implicitly |
| Anything else | whatever its provider declares |

Given a changeset touching `lib/model/read.ts`, `skills/task-work/SKILL.md`,
and `apps/pumice/src/main.rs`:

```text
                                    read.ts  SKILL.md  main.rs
  CLAUDE.md /                          ●         ●        ●     → job: all three
  CLAUDE.md /docs                      ·         ·        ·     → dropped, costs nothing
  CLAUDE.md /apps/pumice               ·         ·        ●     → job: main.rs
  CLAUDE.md /lib                       ●         ·        ·     → job: read.ts
  CLAUDE.md /skills                    ·         ●        ·     → job: SKILL.md
  standard, skills/**/SKILL.md         ·         ●        ·     → job: SKILL.md
```

Two things fall out. `docs/CLAUDE.md` is proven irrelevant by pattern algebra,
so no model call is made for it. And `SKILL.md` is judged three times, by three
different rule sets — the root rules, the skills-directory rules, and the
standard. That overlap is the point: each judge sees one ruleset and is asked
about nothing else.

Jobs are flat and isolated. Each carries only its own rule text, so no judge
can silently overrule another, and a finding is never reported twice for the
same reason. Concurrency is a rate limit rather than a correctness concern —
verification is read-only and no job touches the working tree.

## Sharding

A rule source scoped at the repo root governs every changed file, so on a wide
branch it draws the entire changeset into one prompt. `maxFilesPerJob` (default
12, `--max-files` on the CLI) splits such a source into several jobs, each
judged against the same rules over its own slice of the files.

The constraint being managed is attention, not context. A judge handed sixty
diffs reasons worse about each one than a judge handed a dozen, well before any
window fills. The wide job also sets the run's wall clock, because everything
else finishes while it is still reading.

Sharding is not free, and the trade is explicit: every shard re-sends the full
rule text, so total prompt volume goes up while each individual judgement gets
smaller and they run at the same time. It buys latency and judgement quality
with tokens.

Findings are attributed to the rule source, never to the shard, so a split is
invisible downstream — the report shows one row per source, and the merge
behaves as if the source had been judged once.

Sharding and `concurrency` are coupled, and this is the part worth getting
right. A judgement costs roughly the same wall clock whatever its prompt size,
because the time goes on starting an agent and having it reason rather than on
reading — so a run costs about `ceil(jobs / concurrency)` of those, and
splitting a job in six does not divide its time by six. Measured on a 63-file
branch:

| Jobs | Concurrency | Waves | Wall clock |
|---|---|---|---|
| 12 (unsharded) | 6 | 2 | 190s |
| 30 (sharded) | 12 | 3 | 253s |
| 30 (sharded) | 32 | 1 | 155s |

Sharding under a cap below the job count is the one configuration that loses to
not sharding at all. The default `concurrency` is therefore a ceiling sized for
a branch-wide run to be a single wave, not a target — a small changeset plans
few jobs and opens only those.

## Providers

The package ships one provider, for instruction files, because every repository
has those. Every other rule corpus arrives through `RuleSourceProvider`, so
`agent-dev` never learns that corpus exists:

```ts
interface RuleSourceProvider {
  id: string;
  discover(ctx: DiscoveryContext): Promise<RuleSource[]>;
}
```

Downstream — planner, dispatch, findings — sees only `RuleSource`: an id, some
prose, and the patterns it governs. A provider for another corpus, such as a
tree of standards documents, is registered this way, and it lives with the code
that owns that corpus rather than here.

Instruction files that only redirect (`See @./README.md`) have their `@path`
imports inlined, the way Claude Code reads them; otherwise those become jobs
with no rules in them. `[[wikilinks]]` are deliberately not followed — they are
cross-references, not imports, and following them would pull a whole docs tree
into one prompt.

## Dispatch

Judgements go through `@osdlc/agent-call`, so the engine is swappable
(`claude`, `codex`, `antigravity`, `opencode`) and the exact invocation is
inspectable before anything spawns. `verify` accepts a `dispatch` seam, which
is how the whole pipeline is tested without a model.

Findings are validated, never cast: a judge that returns a malformed entry
loses that entry, not the rest, and one citing a file outside its own scope is
rejected.

## Prompt size

Sizes are measured in bytes, and reported as an estimated token count —
`estimateTokens` divides by a round constant. There is deliberately no
tokenizer: Anthropic publishes no local one for current Claude models, so the
exact count needs a `count_tokens` round-trip that would cost `--dry-run` its
one strong property, that it is free and offline. A third-party BPE would be
OpenAI's vocabulary, precise-looking and wrong; and with four engines behind
`agent-call`, no single tokenizer is correct for all of them anyway.

`maxPromptBytes` therefore stays denominated in bytes, which are exact and
engine-independent. When a real run's engine reports its own input-token count,
that lands on the outcome as `promptTokens` — the true cost of the call, and
not comparable to the estimate, since a CLI agent prepends its own system
prompt to whatever was sent.

## Testing

`bun run test` (Vitest). No test spawns a model — the dispatch seam is injected, and spec
construction is asserted through `agent-call`'s pure `planCall`.

## Evaluating the judge

Everything above measures what a run costs. `src/eval/` measures whether the
findings are any good, which is a different question and the harder one.

```bash
bun run test:eval                          # one run against the fixture
AGENT_DEV_EVAL_RUNS=5 bun run test:eval    # five, to see run-to-run agreement
```

It is opt-in (`AGENT_DEV_EVAL=1`) and excluded from CI. The rest of this
package's suite never spawns a model, and that property is worth more than
having a score on every push.

A throwaway repository is built with planted rule breaches, so "did it find
that" has a fact for an answer rather than a labelling opinion. Three breaches
are planted — an `any` type, a `node:child_process` import, and a `test/`
import that only the nested `src/CLAUDE.md` forbids, so finding it also proves
scoping worked.

The near-miss files carry the weight. One says "any" twice in prose while
being typed `unknown`; another names `node:child_process` in a comment
explaining why it does not import it. Both comply. Any judge scores well on
planted breaches by reporting everything, and only a file that reads as guilty
while complying separates a judge that follows the code from one that greps.

Scoring is deliberately asymmetric, matching what `buildPrompt` already tells
the judge — that inventing marginal findings is worse than reporting none. A
finding on a file the case declares clean is `spurious` and always gates. A
finding the case simply never mentioned is `extra`: reported, but neither
counted against precision nor a failure, since it may be a real breach the case
author missed or a second rule source restating one.

Cases gate one expectation at a time rather than against an aggregate
threshold, so a failure says `missed: src/shell.ts evidence~"child_process"`
rather than that a number moved. An expectation marked `aspirational` is
tracked in the scoreboard and never gates; a spurious finding can never be
marked aspirational, because the case asserts that file complies.

Read a pass as "the judge is not broken", not "the judge is good". Planted
breaches are single-rule and unobstructed; real ones arrive tangled with the
change that introduced them.

## Licence

Dual-licensed under [MIT](./LICENSE-MIT) or [Apache-2.0](./LICENSE-APACHE), at your option.
