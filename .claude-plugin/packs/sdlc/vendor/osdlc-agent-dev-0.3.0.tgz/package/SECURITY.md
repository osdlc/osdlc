# Security policy

## Reporting a vulnerability

Please report vulnerabilities privately. Do not open a public issue.

Use GitHub private vulnerability reporting on the repository that hosts this
package: open its Security tab and choose "Report a vulnerability".

Include the version, a short description, and steps to reproduce. A minimal
code sample helps.

## Supported versions

Only the latest release gets security fixes. While the version is 0.x, that
is the latest minor release. Upgrade to it.

## What this package runs

- `dfv checks <dir>` runs the executable scripts it finds in the folder you
  name. Only files with the executable bit are run. A file without it is
  listed as skipped. Run it only on folders you trust, as you would run any
  script from that folder.
- A judgement (`dfv` and `verify`) sends the diff and the text of the matching
  rule files to an agent. It runs with `permissions: { mode: 'read-only' }`, so
  the agent is asked not to change anything.
- Instruction files and their `@path` imports are read only from inside the
  project root.

## What to expect

This is a small project. We aim to reply within a week. We will tell you
whether we accept the report and keep you updated until a fix is released.
We will credit you in the release notes if you want that.
