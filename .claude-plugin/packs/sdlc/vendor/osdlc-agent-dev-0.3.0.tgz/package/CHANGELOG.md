# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Changed

- Depends on `@osdlc/agent-call` ^0.7.1 (was ^0.5.0), matching `@osdlc/pr-update`.

### Added

- `VerifyConfig.extraArgs`: flags handed to the agent before the prompt, such as codex's
  `--oss --local-provider ollama` for a local model.
- `dfv checks` runs a folder of numbered script checks one at a time and
  reports a verdict for each.
- `dfv checks` selects script checks by changeset: `--base <rev>`, `--staged`
  and `--all`, `# applies_to: <glob>` script headers, the in-scope files on
  stdin and `CHECK_BASE` in the environment. A script with no matching file is
  skipped with `no changed files in scope`.
- `selectByScope`, `stagedFiles` and `trackedFiles` are exported.

### Changed

- Depends on `@osdlc/intersect` `^0.3.0` from npm instead of the in-repo `@sksizer/intersect`.
  A changed path is now read as a literal name, so a file such as `pages/[id].vue` no longer
  matches as a character class. A scope pattern that `@osdlc/intersect` rejects, such as
  `{1..3}` or an extglob, now fails `dfv` and `dfv checks` with exit 2 and a `ScopeError` message
  that names the script or `exclude`. `escapeGlob` and `ScopeError` are exported.
- An instruction file in a directory whose name holds glob characters, such as `[id]` or `(auth)`,
  is scoped to that directory, not to a pattern read from its name.
- Depends on `@osdlc/agent-call` `^0.4.1` from npm instead of the in-repo `@sksizer/agent-call`.
  The error `detail` of a failed judgement changes: a nonzero exit joins the parser's text and the
  stderr tail, and a caller abort reads `aborted by the caller`.

## [0.3.0] - 2026-10-10

### Changed

- **BREAKING: `--engine gemini` is now `--engine antigravity`.** The `dfv`
  CLI and README follow `@sksizer/agent-call`, which replaced its `gemini`
  adapter with `antigravity`; `claude` stays the default.

## [0.2.0] - 2026-09-28

### Added

- `resolveBase(git, base)` is exported from `changeset`. `dfv --json` output
  carries a `resolvedBase` field beside `base`, and human output reports
  `<base> (resolved to <ref>)` when the two differ.

### Fixed

- **A branch ahead of or diverged from its remote was diffed against the
  remote's stale tip.** The base resolver always preferred `origin/<base>`,
  which walked the merge base back past every commit on the local branch and
  pulled unrelated files into the changeset (1075 in the reported case). The
  remote copy is now preferred only when the local ref is an ancestor of it (a
  stale checkout); a local ref that is ahead or diverged is used as written,
  and when only one of the two exists that one is used
  ([#2421](https://github.com/sksizer/dev/pull/2421)).

## [0.1.0] - 2026-09-08

First release. Verifies a changeset against every instruction file and
standard whose scope encloses it.

### Added

- **Rule sources through providers.** `RuleSource` is an id, prose and the
  paths it governs, so selection, dispatch and reporting never know where a
  rule came from. The `instruction-files` provider reads nested `CLAUDE.md`
  and `AGENTS.md` files (`instructionFiles`); `discoverSources` gathers them.
- **Selection and planning.** `planJobs` intersects each source's patterns
  with the changed files (`@sksizer/intersect`) and plans one judgement per
  source over exactly the files it covers, sharding large ones.
- **Judgement.** `verify` dispatches the jobs through `@sksizer/agent-call`
  with a structured findings schema; `parseFindings`, `mergeFindings`,
  `meetsFloor` and `exitCodeFor` turn the answers into a severity-floored
  exit code. `--dry-run` reports job count and estimated prompt tokens
  (`estimateTokens`, `formatTokens`) without calling an agent.
- **Changesets.** `changedFiles`, `fileDiffs` and `defaultBase` read the
  working diff through `@sksizer/easy-git`.
- **The `dfv` CLI** (`--base`, `--engine`, `--model`, `--json`, `--dry-run`, `--exclude`,
  `--severity`, `--concurrency`, `--max-files`).
