/**
 * The `router` config section: the model catalogue's facts and mapping policy.
 * Mounted by hosts (sdlc mounts it in its section list,
 * [[D-CXJE-config-sections-and-standalone-tools]]); the shape is
 * {@link RouterConfigSchema}. The shape is the whole check: the section needs
 * no host vocabulary. The host passes its `consumers` paths (relative to its
 * repository root) and, if it wants its own wording, the description.
 */

import { defineConfigSection, type Stability } from '@osdlc/config-layers'

import { RouterConfigSchema } from '../catalogue/schema.js'

/** What a host supplies to mount `router`. */
export interface RouterSectionOptions {
  /** The host's code paths that read the section, relative to its repository root. */
  readonly consumers: readonly string[]
  /** The key's description; defaults to a host-neutral one. */
  readonly description?: string
  /** Whether the host's compatibility promise covers the key; absent is `stable`. */
  readonly stability?: Stability
}

const DEFAULT_DESCRIPTION =
  'Model catalogue facts layered over the snapshot `@sksizer/tool-router` ships: `providers` (`{kind, endpoint, key_env}`; `key_env` names an environment variable, never a key), `tools`, `offerings` (rows that add one tool and model combination, or remove one with `remove: true`), `strict` (default false: an unknown model only warns; true refuses the load), and the mapping policy: `classify`, `chains.order` and `pins`. Unknown keys, an incomplete new tool or provider, a row naming an unknown tool, provider or model, and a pin its tool cannot run fail the load.'

export function routerSection({
  consumers,
  description = DEFAULT_DESCRIPTION,
  stability,
}: RouterSectionOptions) {
  return defineConfigSection({
    key: 'router',
    schema: RouterConfigSchema.optional().describe(description),
    meta: {
      ...(stability !== undefined ? { stability } : {}),
      category: 'integration',
      consumers: [...consumers],
      layers: ['project', 'local'],
      applies_via: 'read',
      enforcement: 'read',
      runs_in: ['cli', 'loop'],
    },
  })
}
