# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Renamed from `@sksizer/code-host` to `@osdlc/code-host`. Earlier entries below keep the old name.

### Added

- `reviewThreads`, `mergePr`, `MergeMethod` and `CodeHostUnsupported`: review threads and merging on
  the port.
- `createPr`, `setDraft` and `updateComment` on the port.
- `codeHostSection`, the `code_host` config section (needs `@osdlc/config-layers`).
- `forgejoTokenEnv` option on `selectCodeHost` and `authChecksFor`, and a `tokenEnv` argument on
  `forgejoAuthChecks`, to name the env var the Forgejo token is read from.

### Changed

- **BREAKING:** the Forgejo token is read from `FORGEJO_TOKEN` by default, not `SDLC_FORGEJO_TOKEN`,
  with no fallback to the old name. `FORGEJO_TOKEN_ENV` is now `DEFAULT_FORGEJO_TOKEN_ENV`.
- Package shape for npm: conditional exports over compiled `dist/`, Node >=22, MIT OR Apache-2.0.
- Depends on `@osdlc/command-seam` ^0.8.0, `@osdlc/typed-gh` ^0.5.0, `@osdlc/typed-git` ^0.5.2 and
  `@osdlc/config-layers` ^0.6.0 from npm.
- **BREAKING:** `githubAuthChecks` takes a required `remoteUrl` (`string | null`).
  `GH_REMOTE_CHECK` is the check it adds.
- `CommandRunner` comes from `@osdlc/command-seam`, the renamed package, with the same shape.
- Version set to 0.3.1 from the API history, ahead of the first public release.

## [0.1.0] - 2026-10-10

First release.

### Added

- **The `CodeHost` port.** What a code host answers about pull requests:
  `listPrs`, `listPrDetails`, `getPr` (with activity, check summaries and
  annotations), `postComment`, `updateBranch` (merge or rebase), `parsePrUrl`
  and `prForBranch`. `assemblePrFacts` builds the classifier's `PrFacts` view
  of a PR.
- **GitHub and Forgejo adapters.** The GitHub adapter runs on
  `@osdlc/typed-gh` (`Gh.api`, `prComment`, `prUpdateBranch`); both go
  through an injected `CommandRunner` (`@osdlc/command-seam`), never a raw
  spawn.
- **Host selection.** `codeHostNameForRemote`, `resolveCodeHost` and
  `selectCodeHost` pick the adapter from the git remote, including a
  self-hosted Forgejo. Remote URLs are parsed with `@osdlc/typed-git`'s
  `parseRemoteUrl`.
- **Doctor auth probes.** `githubAuthChecks` and `forgejoAuthChecks` return
  `AuthCheck` rows; `authChecksFor(name)` selects them.
- **PR references.** `parsePrInput` turns a bare number, `owner/repo#n`, a PR
  URL, or nothing (the current branch's PR) into a `PrInput`.
