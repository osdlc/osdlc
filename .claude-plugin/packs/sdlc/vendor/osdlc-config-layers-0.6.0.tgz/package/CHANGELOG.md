# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

First release, version 0.6.0. A CLI tool's project and machine config files, and the check a
command runs before it starts.

Twin: the Rust crate `config-layers` (today's `cli-tool-config` crate, renamed) at 0.6.0.

Depends on `@osdlc/etag-write`, `@osdlc/gfm-table` and `@osdlc/tiered-dirs` from npm. The
`SystemBaseDirsOptions` type is `ResolveOptions` (re-exported from `@osdlc/tiered-dirs`).

### Added

- **Project config built from sections.** `defineConfigSection` (with `fileSchema` and `layerCheck`
  hooks) and `assembleConfig`, which turns a section list into a memoized loader. The overlay file
  is deep-merged over the committed file before validation (`deepMergeConfig`).
  `unknownTopLevel: 'reject' | 'ignore' | 'warn'` says what an unowned top-level key means. A bad
  file is a `ConfigInvalidError` with exit code 14 (`CONFIG_INVALID_EXIT`). `readParsedFile` and
  `readMappingFile` read a file's bytes.
- **Where the file is.** `resolveConfigFile`: the tool names its file and the variable that
  relocates it; the overlay is `<stem>.local.<ext>`.
- **Per-key metadata.** `meta.ts`, `defineConfigVocabulary` (the tool's own categories,
  appliers, layers, run contexts and enforcement levels) and a completeness kit
  (`consumerProblems`, `enforcementProblems`, `machineLayerKeys`, `applierAndReservedProblems`)
  for a tool's own tests. Secrets and deprecations are declared in the meta.
- **Layered resolution.** `resolveLayeredSteps` and `resolveLayeredValue`: the env, local,
  project, default cascade, with the layer and mode each result came from.
- **Tooling for a `config` command**, all derived from the schema: `resolveKeyPath`,
  `describeShape`, `defaultOf`, `jsonSchemaOf` and the other explain helpers; `setPath` and
  `unsetPath`, which edit a dotted key and keep comments; `scaffoldYaml`, `scaffoldLocalYaml`
  and `starterYaml`; `renderReference`, a markdown reference page.
- **The machine file.** `machineConfigFile({ tool, schema, vendorDirs })` reads
  `<config>/<tool>/config.yaml` through the tool's schema. A missing, unreadable or invalid file
  degrades to the defaults, keeping valid sections and reporting every drop as a
  `MachineConfigIssue`. Migrations upgrade an older file in memory, `migrate()` writes the
  upgrade, and writes are atomic, checked against the schema and keep a `.bak`.
- **Needs.** `configNeeds` answers whether a setting a command depends on is set in the project
  file, the machine file or a stand-in input, and renders one message saying where to set it.
- **Named directories.** `pathsSchema`, `pathTokens`, `expandTokens` (`{name}`), `TokenError`
  and `resolveConfigPath`.
- **Directory helpers and close matches.** `systemDirs`, `VendorDirs`, `TieredDirs`, `envVars`,
  and `closestMatches` and `didYouMean`.
- TSDoc on every export, `@experimental` on every export this package defines, an `examples/`
  suite that uses every export through the package name, and tests that every export has an
  example and the README's experimental list matches the tags.
- The README says what the package is for, when not to use it, how it compares, which exports
  are experimental, and which platforms it supports.
- **Comment placement in `setPath`.** When `setPath` replaces a record entry value with a list,
  the old value's trailing comment now sits on the key's header line, not at the end of the
  list. This comes from `@sksizer/yaml-splice`, whose CHANGELOG says: "When a new value is
  written as a block, the old value's trailing comment moves to the block's header line".
