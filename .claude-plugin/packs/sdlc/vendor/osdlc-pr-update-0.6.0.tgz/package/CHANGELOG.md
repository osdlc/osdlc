# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.6.0] - 2026-10-20

The engine is host-neutral and the binary is a host of it
([D-0001](docs/decisions/D-0001-engine-hosts-and-one-judgement-seam.md)). Breaking.

### Changed

- Package shape for npm: licensed MIT OR Apache-2.0, Node >=22, a files whitelist that ships the
  decision record under `docs/`, and SECURITY and CONTRIBUTING notes.
- Renamed from `@sksizer/pr-update` to `@osdlc/pr-update`, and its `@sksizer/cli-tool` and
  `@sksizer/code-host` dependencies to `@osdlc/cli-tool` and `@osdlc/code-host`.
- **BREAKING:** `Repair` returns `Promise<RepairResult>`, and `updateOne`, `updateAll` and
  `runUpdate` are async. `commandRepair(command, timeoutSeconds)` is async.
- **BREAKING:** the deterministic rungs (rerere, lockfile, `resolvers`, `generators`) run at every
  rebase stop, not only the first. A stop they cannot clear aborts the rebase and retries the PR as
  a merge, where `repair` is offered the conflict once; `repair` is never called mid-rebase. The new
  `pr_update.on_rebase_conflict` (`merge`, the default, or `fail`) chooses. A result that fell back
  carries `strategyFallback` and reports `strategy: merge`.
- **BREAKING:** the config loader takes `{ name, envVar }` from its caller:
  `loadConfigLayers(file, projectRoot, env)` and `standaloneConfig(file, env)`. The binary reads
  `pr-update.yaml`, its `pr-update.local.yaml` overlay and `PR_UPDATE_CONFIG`, and no other file. It
  no longer reads another tool's config file or refuses a leftover `.pr-update.yaml`;
  `assertNoRetiredFile` is removed. `main` takes another file through `seams.configFile`.
- **BREAKING:** `--interactive` and the Ink checklist are removed, with the `interactive` input and
  output fields and the `ink`, `react`, `@types/react` and `ink-testing-library` dependencies.
  `--confirm-push` stays.
- **BREAKING:** the built-in project-specific resolver rule is gone from the package; a project
  lists its generators under `pr_update.resolvers`.
- A `--pr` or `--branch` run lists the code host once but fetches and `merge-tree`s only its PRs and
  their stack parents. `survey` takes `--pr` too.
- The package names no host, in source, tests or docs.

### Added

- Survey rows carry `crossRepo`, true when the head branch lives in a fork.
- `--branch [name]` on `survey` and `update`: the PR whose head is that branch, or the branch
  checked out in the current directory when no name is given. No such PR is a usage error. After a
  successful push the checkout is moved to the pushed head when it is on that branch, clean and at
  the old remote head; otherwise the result's `localCheckout` says why it was left.
- `update --report <file>`: the result as JSON, written atomically whatever the exit code.
- Built-in headless repair agents `claude`, `codex`, `cursor` and `pi`, each one
  `@osdlc/agent-call` call in the update worktree with an edit-only, no-prompt posture. Config
  `repair.agent` and `repair.model` (exclusive with `repair.command`); `update --repair-agent` and
  `--repair-command`. A project-file `repair.agent` is trust-gated like `repair.command`; a flag is
  not.
- `repair.timeout_seconds`, killing a repair that runs too long.
- `repairPrompt(req)`, the prompt every preset shares, for a host that runs its own agent;
  `agentRepair`, `planRepair` and `repairCallSpec`.
- `SurveyUsageError`, `scopeToPrs`, `syncLocalCheckout` and `scratchBranch`.

### Fixed

- Failed attempts are stored one file per PR target (repo, head and base branch) under
  `.pr-update/attempts/`, each written atomically, instead of one shared `.pr-update/attempts.json`.
  The loop runs one update per PR, so its writers never share a file and failure records, which
  `max_failed_attempts` counts, are no longer lost to interleaved read-modify-writes. The old
  `attempts.json` is not read or deleted: its records are forgotten, so each PR gets one fresh
  attempt. `attemptsFile` is replaced by `attemptsDir`, `attemptFile` and `listAttempts`.
- Two runs in one repository at once, such as a host updating several PRs in parallel, no longer
  fight over one scratch branch: each run's branch is named for its own worktree
  (`pr-update/scratch-<pid>.<time>`), and a killed run's branch is deleted with its worktree.

## [0.5.0]

### Changed

- Depends on `@osdlc/etag-write` `^0.2.0` from npm instead of `@sksizer/etag-write`.
- **BREAKING:** the standalone `pr-update` binary reads the `pr_update:` and `code_host:` blocks of
  a shared host config file (layered under its `.local` overlay, relocatable with an environment
  variable) instead of `.pr-update.yaml`, through `@sksizer/cli-tool/config`. Other top-level keys
  are skipped. `loadConfigFile` and `ConfigFileError` are removed: `loadConfigLayers` and
  `standaloneConfig` read through the shared loader, and an unusable config is a
  `ConfigInvalidError` (exit `14`).
- `update` refuses to run a command read from the project file (`lockfile_install`,
  `resolvers[].run`, `repair.command`, `test_command`) without consent and exits `21`.
- Version set to 0.5.0 from the API history, ahead of the first public release.

### Added

- `pr-update config list|get|set|unset|explain|scaffold`, with `pr_update` as the default namespace.
- `pr-update trust`, recording consent for a repository; `--trust` still grants it for one run.
- `prUpdateStandaloneSection`, the `pr_update` section including the standalone-only `test_command`.

### Fixed

- `execute` reads the runner's error where seam stderr is shown.

## [0.2.0] - 2026-10-10

### Changed

- **BREAKING:** the `Forge` port is renamed `CodeHost`
  `survey` lists PRs through the `CodeHost`
  port (`@sksizer/code-host`) instead of `@sksizer/easy-gh`; `SurveyEnv.codeHost` swaps the adapter
  (default GitHub over `gh`).
- CLI and config ergonomics; caller-glue
  enhancements from the command-seam, easy-git and easy-gh APIs.

### Added

- `conflictBaseSha` on a survey row's conflict prediction: the base ref's resolved SHA when
  `merge-tree` measured it, so a caller can tell whether the prediction is still fresh.
- Structured `conflicts: {path, why}[]` alongside `update`'s free-text `detail`.
- `--strategy rebase|merge` on `pr-update update`, overriding the run's default strategy without
  bypassing a per-PR `overrides` rule or the `unpushed_local` guard.
- Optional `Ports.generators`: in-process rebuild steps, a ladder rung after `resolvers`.
- Optional `Ports.repair` and the `repair: { command, on }` config block: a last-resort repair for
  an unclaimed conflict or failed verify step, called only under `--apply`. The executor rejects a
  repair that moves HEAD, creates refs, or leaves conflict markers or `git diff --check` errors.
  `updated` outcomes gain `repaired: {kind, note}[]`.

## [0.1.0] - 2026-09-27

### Added

- Extracted from the larger CLI it started in, so
  it can run standalone: `runSurvey` and `runUpdate` as a library, plus a `pr-update` CLI (`survey`
  / `update`) built on `@sksizer/cli-tool`, with a Forge port (GitHub and Forgejo adapters).
