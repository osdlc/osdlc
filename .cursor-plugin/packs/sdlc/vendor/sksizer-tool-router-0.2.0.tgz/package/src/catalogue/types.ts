// The model catalogue of D-5C1M Part 1: facts about tools, providers, models
// and the offerings that join them. Plain data, no I/O: the layers arrive as
// values (the shipped snapshot, the machine catalogue's layers, the `router:`
// config block) and are merged by `layerCatalogue`.
import type { Trait } from '../ref.js'

/** Where a fact came from. */
export type Source = 'snapshot' | 'models.dev' | 'config' | `probe:${string}`

/** The layer a fact came from and the date (`YYYY-MM-DD`) it was observed. */
export type Provenance = { source: Source; observed_at: string }

/**
 * A row with the provenance of the layer that last touched it, and per field
 * the layer that set that field (`fields`), so a partial override keeps the
 * snapshot's provenance on the fields it left alone.
 */
export type Sourced<T> = T & Provenance & { fields: Partial<Record<keyof T, Provenance>> }

export type Openness = 'closed' | 'curated' | 'open'
export type ToolMode = 'headless' | 'interactive'

/**
 * How a tool takes a model, effort or context: a flag (`--model`), a config
 * key (codex `-c model_reasoning_effort=…`), a model suffix (`opus[1m]`), a
 * bracket key (Cursor `model[effort=high]`), or not at all.
 */
export type Takes =
  { via: 'flag' | 'config' | 'suffix' | 'bracket'; name: string } | { via: 'none' }

/** A provider a tool serves; `via` is the launch mode that reaches it, when one is needed. */
export type ServesEntry = string | { provider: string; via: string }

/** The headless launch template of a declared tool: `{prompt}`, `{model}` and `{effort}` are slots. */
export type HeadlessTemplate = { args: string[]; prompt_via: 'argv' | 'stdin' }

/** A curated tool's own listing of one model. */
export type CuratedOffer = {
  /** The model's catalogue key, `provider/id`. */
  model: string
  native_name: string
  efforts?: string[] | undefined
  context?: ContextSizes | undefined
}

export type Tool = {
  id: string
  /** The executable, looked up on `PATH`: the snapshot's for a built-in tool, the tool id for a declared one. */
  binary: string
  serves: ServesEntry[]
  openness: Openness
  modes: ToolMode[]
  model: Takes
  effort: Takes
  context: Takes
  /** The levels the tool can pass; absent when the tool has no fixed list. */
  efforts?: string[] | undefined
  /** The tool's own aliases: alias to model key (`opus` to `anthropic/claude-opus-5-5`). */
  aliases?: Record<string, string> | undefined
  /** Hand the tool its alias rather than the model id (native-name rule 1). */
  prefer_alias?: boolean | undefined
  /**
   * The tool calls each provider itself, with that provider's key (`key_env`, or
   * credentials the tool stored for it), rather than through its own sign-in.
   * Availability then needs the key for a cloud model; absent means the tool's
   * own sign-in is enough.
   */
  provider_keys?: boolean | undefined
  /** A curated tool's own model list. */
  offers?: CuratedOffer[] | undefined
  headless?: HeadlessTemplate | undefined
  /** The tool version the row was checked against. */
  checked_against?: string | undefined
  /** Fields taken from documentation, not a run on the day of the snapshot. */
  verify?: string[] | undefined
}

export type ProviderKind =
  'anthropic' | 'openai' | 'google' | 'ollama' | 'lmstudio' | 'openai-compatible'

export type Provider = {
  id: string
  kind: ProviderKind
  endpoint?: string | undefined
  /** The name of the environment variable holding the key, never the key. */
  key_env?: string | undefined
}

/** A model trait (`TRAITS`); a wildcard expands only to `agent` models, never `embedding` ones. */
export type { Trait }

export type ContextSizes = {
  default?: number | undefined
  max?: number | undefined
  /** Named variants a tool selects, e.g. `1m`. */
  variants?: string[] | undefined
}

export type Model = {
  /** `provider/id`. */
  key: string
  provider: string
  id: string
  aliases?: string[] | undefined
  family?: string | undefined
  release_date?: string | undefined
  context?: ContextSizes | undefined
  efforts?: string[] | undefined
  /** US dollars per million tokens. */
  cost?: { input: number; output: number } | undefined
  traits?: Trait[] | undefined
  /** `deprecated` still runs, with a warning; `withdrawn` is skipped (validity, `checkRef`). */
  status: 'current' | 'deprecated' | 'withdrawn'
  deprecated_on?: string | undefined
}

/** One model on one tool: what the tool is given and how it differs from the model. */
export type Offering = Provenance & {
  tool: string
  /** The model's catalogue key, `provider/id`. */
  model: string
  native_name: string
  via?: string | undefined
  efforts?: string[] | undefined
  context?: ContextSizes | undefined
}

/** A `router.offerings` row: adds (or replaces) one offering, or removes one. */
export type OfferingRow = {
  tool: string
  model: string
  native_name?: string | undefined
  via?: string | undefined
  efforts?: string[] | undefined
  context?: ContextSizes | undefined
  remove?: boolean | undefined
}

/** A row as one layer states it: any subset of the fields, plus an optional own date. */
type LayerRow<T> = { [K in keyof Omit<T, 'id' | 'key'>]?: T[K] | undefined } & {
  observed_at?: string | undefined
}
export type ToolRow = LayerRow<Tool>
export type ProviderRow = LayerRow<Provider>
export type ModelRow = LayerRow<Model>

/** One layer, lowest first in `layerCatalogue`. Plain data: reading a file is the caller's job. */
export type CatalogueLayer = {
  source: Source
  observed_at: string
  tools?: Record<string, ToolRow> | undefined
  providers?: Record<string, ProviderRow> | undefined
  /** Keyed `provider/id`. */
  models?: Record<string, ModelRow> | undefined
  offerings?: OfferingRow[] | undefined
}

/**
 * A merged row that lacks a required field (it is left out), or a reference to
 * a tool, provider or model the catalogue lacks (the row stays).
 */
export type CatalogueProblem = {
  table: 'tools' | 'providers' | 'models' | 'offerings'
  key: string
  message: string
}

export type Catalogue = {
  tools: Record<string, Sourced<Tool>>
  providers: Record<string, Sourced<Provider>>
  models: Record<string, Sourced<Model>>
  /** `router.offerings` rows in layer order, each with its layer's provenance. */
  offeringRows: (OfferingRow & Provenance)[]
  problems: CatalogueProblem[]
}
