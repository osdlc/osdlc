import { z } from 'zod'

/**
 * The author rule's config keys, which a caller whose work has an author
 * (sdlc's `pr_review:`) carries beside its binding: `not_the_author` sets
 * aside every entry on the author's tool, and `if_only_author_left` says what
 * happens when only those are left. A profile does not hold them.
 */
export const IfOnlyAuthorLeftSchema = z.enum(['different-model', 'wait', 'person'])

export type IfOnlyAuthorLeft = z.infer<typeof IfOnlyAuthorLeftSchema>

export const authorRuleFields = {
  not_the_author: z
    .boolean()
    .optional()
    .describe(
      "Set aside every entry on the author's tool; with the author unknown, every entry. Default false.",
    ),
  if_only_author_left: IfOnlyAuthorLeftSchema.optional().describe(
    "When only the author's tool is left: `different-model` (default) takes an entry whose model differs, `wait` stops, `person` hands the work to a person.",
  ),
}

/** The author rule as the walk takes it (`ChooseContext.authorRule`). */
export type AuthorRule = { notTheAuthor: boolean; ifOnlyAuthorLeft: IfOnlyAuthorLeft }

/** The rule the config keys ask for: `not_the_author` false and `different-model` when unset. */
export function authorRule(config: {
  not_the_author?: boolean | undefined
  if_only_author_left?: IfOnlyAuthorLeft | undefined
}): AuthorRule {
  return {
    notTheAuthor: config.not_the_author ?? false,
    ifOnlyAuthorLeft: config.if_only_author_left ?? 'different-model',
  }
}
