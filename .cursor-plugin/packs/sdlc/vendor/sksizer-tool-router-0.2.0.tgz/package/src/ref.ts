import { formatSize, parseSize } from './context.js'
import { err, ok, type Result } from './result.js'

export type Tier = 'fast' | 'standard' | 'max'

export const TIERS: readonly Tier[] = ['fast', 'standard', 'max']

export function isTier(s: string): s is Tier {
  return (TIERS as readonly string[]).includes(s)
}

/** The model traits of the catalogue (`Trait`), which a qualifier filters on. */
export const TRAITS = ['local', 'agent', 'embedding', 'reasoning', 'long-context'] as const

export type Trait = (typeof TRAITS)[number]

function isTrait(s: string): s is Trait {
  return (TRAITS as readonly string[]).includes(s)
}

/** The wildcard tool `*`: every tool, for one tier. Allowed in profile entries only. */
export const WILDCARD = '*'

/**
 * The `[...]` group of a reference: `ctx` asks for at least that many tokens of
 * context (`max`: the largest the model offers); `traits` filter a tier or a
 * wildcard to the models that carry every one.
 */
export type Qualifiers = { ctx?: number | 'max'; traits: Trait[] }

/**
 * A parsed `tool/model[qualifiers]@effort` reference. Only `tool` is required;
 * `qualifiers` is present only when the reference has a `[...]` group.
 */
export type Ref = { tool: string; model?: string; qualifiers?: Qualifiers; effort?: string }

export type RefParseErrorKind =
  | 'empty-ref'
  | 'empty-tool'
  | 'invalid-tool'
  | 'empty-model'
  | 'empty-effort'
  | 'whitespace'
  | 'invalid-qualifiers'
  | 'duplicate-qualifier'
  /** A tool's own bracket (`opus[1m]`, `[context=1m]`); the message gives the sdlc form. */
  | 'native-bracket'
  /** A trait on a named model or the tool default: only tiers and wildcards filter. */
  | 'traits-need-tier'
  /** `*` without a tier, or with a model name. */
  | 'wildcard-needs-tier'

export type RefParseError = {
  kind: RefParseErrorKind
  text: string
  message: string
}

/** Whether a ref names every tool: the wildcard tool `*` with a tier. */
export function isWildcard(ref: Ref): boolean {
  return ref.tool === WILDCARD
}

/** Whether a ref's model is a tier word, a concrete name, or absent. */
export function modelKind(ref: Ref): 'tier' | 'name' | undefined {
  if (ref.model === undefined) return undefined
  return isTier(ref.model) ? 'tier' : 'name'
}

/** Tool ids are lower-case identifiers. */
export const TOOL_ID_PATTERN = /^[a-z][a-z0-9-]*$/

export function isToolId(s: string): boolean {
  return TOOL_ID_PATTERN.test(s)
}

function fail(
  kind: RefParseErrorKind,
  text: string,
  message: string,
): { ok: false; error: RefParseError } {
  return err({ kind, text, message: `${message}: ${JSON.stringify(text)}` })
}

function parseQualifiers(text: string, group: string): Result<Qualifiers, RefParseError> {
  const q: Qualifiers = { traits: [] }
  for (const item of group.split(',')) {
    if (item === '') return fail('invalid-qualifiers', text, 'empty qualifier')
    const eq = item.indexOf('=')
    if (eq < 0) {
      if (/^[0-9]+[a-z]*$/.test(item)) {
        return fail(
          'native-bracket',
          text,
          `a context size is written [ctx=${item}], not a tool's own [${item}]`,
        )
      }
      if (!isTrait(item)) {
        return fail(
          'invalid-qualifiers',
          text,
          `unknown trait '${item}'; known: ${TRAITS.join(', ')}`,
        )
      }
      if (q.traits.includes(item)) {
        return fail('duplicate-qualifier', text, `trait '${item}' appears twice`)
      }
      q.traits.push(item)
      continue
    }
    const key = item.slice(0, eq)
    const value = item.slice(eq + 1)
    if (key === 'context') {
      return fail(
        'native-bracket',
        text,
        `a context size is written [ctx=${value}], not a tool's own [context=${value}]`,
      )
    }
    if (key !== 'ctx') {
      return fail('invalid-qualifiers', text, `unknown qualifier '${key}'; the only key is ctx`)
    }
    if (q.ctx !== undefined) return fail('duplicate-qualifier', text, "'ctx' appears twice")
    const size = value === 'max' ? 'max' : parseSize(value)
    if (size === undefined) {
      return fail(
        'invalid-qualifiers',
        text,
        `ctx must be digits plus k or m, or max; got '${value}'`,
      )
    }
    q.ctx = size
  }
  q.traits.sort()
  return ok(q)
}

/**
 * Parse `tool/model[qualifiers]@effort`, in the order of D-5C1M "Reference
 * syntax": split off the effort at the last `@` that follows the last `]`,
 * then a trailing `[...]` group, then the tool at the first `/`. The model is
 * passed through unchanged. It may itself contain `/` and `:`; it holds an `@`
 * only when an effort follows and there are no qualifiers (`foo@v1@high`),
 * since the last `@` starts the effort and an `@` before a `[...]` group is
 * an error. The tool must match
 * `TOOL_ID_PATTERN`, or be the wildcard `*` with a tier. Qualifiers are
 * `ctx=<size>` and trait names, each once; traits need a tier or a wildcard. A
 * tool's own bracket (`opus[1m]`, `[context=1m]`) is an error naming the sdlc
 * form.
 */
export function parseRef(text: string): Result<Ref, RefParseError> {
  if (text === '') return fail('empty-ref', text, 'empty model reference')
  if (/\s/.test(text)) return fail('whitespace', text, 'model reference contains whitespace')

  const close = text.lastIndexOf(']')
  const at = text.lastIndexOf('@')
  const hasEffort = at > close
  const body = hasEffort ? text.slice(0, at) : text
  const effort = hasEffort ? text.slice(at + 1) : undefined
  if (effort === '') return fail('empty-effort', text, "empty effort after '@'")

  let head = body
  let qualifiers: Qualifiers | undefined
  if (body.endsWith(']')) {
    const open = body.lastIndexOf('[')
    if (open < 0) return fail('invalid-qualifiers', text, "']' without '['")
    const group = body.slice(open + 1, -1)
    if (group === '') return fail('invalid-qualifiers', text, 'empty qualifiers')
    const parsed = parseQualifiers(text, group)
    if (!parsed.ok) return parsed
    qualifiers = parsed.value
    head = body.slice(0, open)
  }
  if (/[[\]]/.test(head)) {
    return fail('invalid-qualifiers', text, "qualifiers are one trailing '[...]' group")
  }
  if (qualifiers !== undefined && head.includes('@')) {
    return fail('invalid-qualifiers', text, "qualifiers go before '@effort'")
  }

  const slash = head.indexOf('/')
  const tool = slash >= 0 ? head.slice(0, slash) : head
  const model = slash >= 0 ? head.slice(slash + 1) : undefined
  if (tool === '') return fail('empty-tool', text, 'empty tool')
  if (tool !== WILDCARD && !isToolId(tool)) {
    return fail('invalid-tool', text, `tool must match ${TOOL_ID_PATTERN.source} or be '*'`)
  }
  if (model === '') return fail('empty-model', text, "empty model after '/'")
  const tier = model !== undefined && isTier(model)
  if (tool === WILDCARD && !tier) {
    return fail(
      'wildcard-needs-tier',
      text,
      `'*' needs a tier (${TIERS.join(', ')}), as in '*/fast'`,
    )
  }
  if (qualifiers !== undefined && qualifiers.traits.length > 0 && !tier) {
    return fail(
      'traits-need-tier',
      text,
      'traits only filter, so they need a tier or a wildcard (claude/fast[local], */fast[local])',
    )
  }

  const ref: Ref = { tool }
  if (model !== undefined) ref.model = model
  if (qualifiers !== undefined) ref.qualifiers = qualifiers
  if (effort !== undefined) ref.effort = effort
  return ok(ref)
}

/** The `[...]` group in canonical order: `ctx` first, then traits sorted. */
export function formatQualifiers(q: Qualifiers): string {
  const items = [
    ...(q.ctx === undefined ? [] : [`ctx=${q.ctx === 'max' ? 'max' : formatSize(q.ctx)}`]),
    ...[...q.traits].sort(),
  ]
  return items.length > 0 ? `[${items.join(',')}]` : ''
}

export function formatRef(ref: Ref): string {
  let out = ref.tool
  if (ref.model !== undefined) out += `/${ref.model}`
  if (ref.qualifiers !== undefined) out += formatQualifiers(ref.qualifiers)
  if (ref.effort !== undefined) out += `@${ref.effort}`
  return out
}
