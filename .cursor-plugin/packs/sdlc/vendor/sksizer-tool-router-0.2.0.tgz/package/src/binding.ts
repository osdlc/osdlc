import { chooseFromProfile, refProfile, type Choice, type ChooseContext } from './choose.js'
import type { Profile } from './profile.js'
import { parseRef, type RefParseError } from './ref.js'
import { err, ok, type Result } from './result.js'

/**
 * A task/step binding: exactly one of a named profile or a single reference
 * (`tool:`). A `tool:` reference walks as a one-entry profile, so a wildcard
 * (`*` with a tier) expands through the chain order, as it does in a profile.
 */
export type Binding = { profile?: string; tool?: string }

export type BindingError =
  | { kind: 'binding-invalid'; message: string }
  | { kind: 'unknown-profile'; name: string; known: string[]; message: string }
  | { kind: 'invalid-ref'; error: RefParseError; message: string }

export function resolveBinding(
  binding: Binding,
  profiles: Record<string, Profile>,
  ctx: ChooseContext,
): Result<Choice, BindingError> {
  const hasProfile = binding.profile !== undefined
  const hasTool = binding.tool !== undefined
  if (hasProfile === hasTool) {
    return err({
      kind: 'binding-invalid',
      message: hasProfile
        ? "binding sets both 'profile' and 'tool'; set exactly one"
        : "binding sets neither 'profile' nor 'tool'; set exactly one",
    })
  }

  if (binding.profile !== undefined) {
    const profile = Object.hasOwn(profiles, binding.profile) ? profiles[binding.profile] : undefined
    if (profile === undefined) {
      const known = Object.keys(profiles).sort()
      return err({
        kind: 'unknown-profile',
        name: binding.profile,
        known,
        message: `unknown profile '${binding.profile}'; known: ${known.length > 0 ? known.join(', ') : '(none)'}`,
      })
    }
    return ok(chooseFromProfile(profile, ctx))
  }

  const parsed = parseRef(binding.tool ?? '')
  if (!parsed.ok) {
    return err({
      kind: 'invalid-ref',
      error: parsed.error,
      message: `binding tool: ${parsed.error.message}`,
    })
  }
  return ok(chooseFromProfile(refProfile(parsed.value), ctx))
}
