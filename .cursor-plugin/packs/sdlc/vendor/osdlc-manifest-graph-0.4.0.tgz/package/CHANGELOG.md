# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.4.0] - 2026-09-27

### Changed

- **BREAKING:** `walkManifests` no longer parses manifests itself; it delegates to the shared aspect
  layer in `@sksizer/detect-runners` ([#2393](https://github.com/sksizer/dev/pull/2393)).
  `@sksizer/detect-runners` is now a dependency.
- One task vocabulary for every project: manifest walking, graph and containment carry the shared
  task vocabulary ([#1885](https://github.com/sksizer/dev/pull/1885)).
- Ship only `src` and `README.md` in the package `files`
  ([#2331](https://github.com/sksizer/dev/pull/2331)).

## [0.3.0] - 2026-09-05

### Added

- `buildSystemGraph` names the virtual Cargo workspace root, and bulk folds are undoable
  ([#1766](https://github.com/sksizer/dev/pull/1766)).

### Fixed

- `applyContainment` is now idempotent on both ports
  ([#1752](https://github.com/sksizer/dev/pull/1752)).
- Array-valued manifest tables (`dependencies`, `bin`, Cargo dependency tables) no longer yield
  index-named entries ([#1692](https://github.com/sksizer/dev/pull/1692)).

## [0.2.0] - 2026-08-30

### Added

- `applyContainment` and `ROOT_ID`: a containment tree on `GraphNode.parent`, separate from the
  dependency edges, with `repo`, `group`, `package`, `crate` and `external` node kinds.
- `buildSystemGraph`: a structural diagram payload (`SystemGraph`) for a repo
  ([#1565](https://github.com/sksizer/dev/pull/1565)).
- Aspect scanning per manifest and a `manifest-graph` CLI.

## [0.1.0] - 2026-08-23

### Added

- `walkManifests`: finds every `package.json` and `Cargo.toml` under a directory and parses each
  into a typed `ManifestInfo`; malformed manifests come back carrying an `error` instead of
  aborting the walk.
- `buildDependencyGraph`: the dependency mesh the manifests declare, with optional external nodes.
