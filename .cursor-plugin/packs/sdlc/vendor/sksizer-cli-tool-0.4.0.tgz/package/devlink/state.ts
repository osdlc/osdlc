/**
 * The two files devlink keeps per tool, in the CONFIG home of the tool's
 * standalone tier (`<config>/<name>/`):
 *
 *   home             the active link — one absolute checkout path, or absent.
 *                    A bash launcher reads it with `cat`; that is why it is a
 *                    bare path and not JSON.
 *   history.jsonl    every link / use / off event, one JSON object per line,
 *                    append-only. `history` and `use #n` are views over it.
 *
 * Config rather than durable: the user sets it and clears it on purpose, and
 * losing it costs nothing but the redirect. The launcher reads the `home` file by name.
 */

import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, appendFileSync } from 'node:fs'
import { dirname, join } from 'node:path'

import { systemDirs, type TieredDirs } from '@osdlc/config-layers'
import type { ToolSpec } from './spec.ts'

/**
 * The name of the file that holds the active link.
 * @experimental
 */
export const HOME_FILE = 'home'
/**
 * The name of the file that records link changes, one JSON line each.
 * @experimental
 */
export const HISTORY_FILE = 'history.jsonl'

/**
 * The kinds of change the history records: `link`, `use` and `off`.
 * @experimental
 */
export type HistoryKind = 'link' | 'use' | 'off'

/**
 * One line of the history file: when, what kind of change, and which checkout.
 * @experimental
 */
export interface HistoryEvent {
  /** ISO-8601 timestamp. */
  at: string
  event: HistoryKind
  /** The checkout the event selected; null for `off`. */
  checkout: string | null
  /** The checkout's git branch at the time, when readable. */
  branch?: string | null
  /** The checkout's git HEAD (short) at the time, when readable. */
  head?: string | null
  /** Free text a caller attached — `--label`. */
  label?: string
}

/**
 * Options for where a tool's link state is kept.
 * @experimental
 */
export interface StateOptions {
  /**
   * The directories to resolve against. Defaults to `spec.vendorDirs` on the
   * running system; tests inject a rooted one to land under a temp dir.
   */
  dirs?: TieredDirs
}

/**
 * `<config>/<name>` for this tool.
 *
 * @experimental
 */
export function stateDir(spec: ToolSpec, opts: StateOptions = {}): string {
  const dirs = opts.dirs ?? systemDirs(spec.vendorDirs)
  return dirs.standalone(spec.name).config().path
}

/**
 * The path of the file that holds a tool's active link.
 * @experimental
 */
export function homePath(spec: ToolSpec, opts: StateOptions = {}): string {
  return join(stateDir(spec, opts), HOME_FILE)
}

/**
 * The path of the history file for a tool.
 * @experimental
 */
export function historyPath(spec: ToolSpec, opts: StateOptions = {}): string {
  return join(stateDir(spec, opts), HISTORY_FILE)
}

/**
 * The active link on disk (trimmed), or null when unset or empty.
 *
 * @experimental
 */
export function readActive(spec: ToolSpec, opts: StateOptions = {}): string | null {
  const path = homePath(spec, opts)
  if (!existsSync(path)) return null
  const value = readFileSync(path, 'utf-8').trim()
  return value.length > 0 ? value : null
}

/**
 * Save a checkout as the tool's active link.
 * @experimental
 */
export function writeActive(spec: ToolSpec, checkout: string, opts: StateOptions = {}): void {
  const path = homePath(spec, opts)
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, `${checkout}\n`, 'utf-8')
}

/**
 * Remove the active link. Returns whether one existed.
 *
 * @experimental
 */
export function clearActive(spec: ToolSpec, opts: StateOptions = {}): boolean {
  const path = homePath(spec, opts)
  const existed = existsSync(path)
  if (existed) rmSync(path, { force: true })
  return existed
}

/**
 * Add one event to the history file, creating the directory if needed.
 * @experimental
 */
export function appendHistory(spec: ToolSpec, event: HistoryEvent, opts: StateOptions = {}): void {
  const path = historyPath(spec, opts)
  mkdirSync(dirname(path), { recursive: true })
  appendFileSync(path, `${JSON.stringify(event)}\n`, 'utf-8')
}

/**
 * Every recorded event, oldest first. A line that is not a JSON object with
 * an `event` string is skipped rather than failing the read: the file is
 * append-only and a torn last line must not hide the rest.
 * @experimental
 */
export function readHistory(spec: ToolSpec, opts: StateOptions = {}): HistoryEvent[] {
  const path = historyPath(spec, opts)
  if (!existsSync(path)) return []
  const out: HistoryEvent[] = []
  for (const line of readFileSync(path, 'utf-8').split('\n')) {
    const trimmed = line.trim()
    if (trimmed.length === 0) continue
    let parsed: unknown
    try {
      parsed = JSON.parse(trimmed)
    } catch {
      continue
    }
    if (isHistoryEvent(parsed)) out.push(parsed)
  }
  return out
}

function isHistoryEvent(value: unknown): value is HistoryEvent {
  if (typeof value !== 'object' || value === null) return false
  const v = value as Record<string, unknown>
  return (
    typeof v['at'] === 'string' &&
    (v['event'] === 'link' || v['event'] === 'use' || v['event'] === 'off') &&
    (typeof v['checkout'] === 'string' || v['checkout'] === null)
  )
}
