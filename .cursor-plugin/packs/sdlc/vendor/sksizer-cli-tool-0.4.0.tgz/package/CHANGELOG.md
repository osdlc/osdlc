# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

First release. What a standalone CLI needs before it does anything of its own.

Depends on `@osdlc/config-layers` and `@osdlc/etag-write` from npm.

### Added

- **The CLI substrate.** `CliIo` with `processIo` and `captureIo`, the `CliContext` a `main`
  is handed (`processContext`, `captureContext`), the `EXIT` codes (`ok` 0, `error` 1,
  `usage` 2) and the 10-63 band a tool numbers its own outcomes in, and `runMain` for the bin
  shim. `runMain` sets `process.exitCode` and never calls `process.exit`.
- **`defineCli`.** Flags declared once over commander, so the parser and the help text cannot
  disagree. Kinds: `boolean` (optionally negatable), `tristate`, `string`, `enum`, `list` and
  `count`. A flag with a default or `required: true` types as present. `parse` returns `ok`,
  `help` or `error` as a value and writes nothing to a process stream. Two help tiers: `hidden`,
  `shortEpilogue` and `autoHelp: false`.
- **A yes/no prompt.** `askYesNo`, `canPrompt`, `readLine` and `isYes`: a synchronous terminal
  question with a default answer.
- **Close-match suggestions and directory helpers**, re-exported from
  `@osdlc/config-layers`: `closestMatches`, `didYouMean`, `systemDirs`, `TieredDirs`,
  `envVars` and their types. The tool names its own vendor directories with `VendorDirs`.
- **The devlink entry, `@sksizer/cli-tool/devlink`.** Run an installed tool from a development
  checkout. A `ToolSpec` (name, checkout marker, entry, launcher, aliases, suppressors, vendor
  directories); `resolve` picks a checkout in four layers (the `<NAME>_HOME` variable, a checkout
  above the cwd, the linked checkout, the local install); the active link and an append-only
  history under `<config>/<name>/`; the verbs `install`, `link`, `use`, `off`, `status` and
  `history` as functions with typed results, each honouring `dryRun`; `runDevCli` mounts them as
  `<tool> dev <verb>` with `--json` and `--dry-run`. `install` writes a small `sh` shim, not a
  symlink, which says so and exits 1 when its checkout is gone. Two launcher shapes:
  `execSelection` for a JavaScript `bin` shim, and `renderLauncher` for a bash launcher, with
  `launcherDrift` to keep the committed file honest.
- **The trust entry, `@sksizer/cli-tool/trust`.** A per-repository trust store (`trustStore`)
  under XDG state, and `resolveExecGate`, which combines a configured value, a per-run flag and
  the store into one allow or deny with a reason. A per-run flag is consent for one run and is
  never recorded. `withheldHint` is the one sentence every surface shows when the gate withholds.
  The standing policy layer (`policyDecision`, `trustDecision`, `policyExecGate`,
  `pathGlobToRegExp`) trusts by path glob or by owner, with the owner lookup injected as
  `ownerOf` so the package stays git-unaware.
- TSDoc on every export, `@experimental` on the exports the README lists as experimental, an
  `examples/` suite that uses every export through the package name, and tests that every export
  has an example and the README's experimental lists match the tags.
- The README says what the package is for, when not to use it, how it compares, which exports
  are experimental, and which platforms it supports.
