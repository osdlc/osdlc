# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to
[Semantic Versioning](https://semver.org/).

## [Unreleased]

### Changed

- Depends on `@osdlc/agent-call` ^0.7.1 (was ^0.5.0), matching `@osdlc/pr-update`.
- An effort the tool and model do not accept moves at most one step on agent-call's
  `EFFORT_LEVELS` (`none` to `max`), up first, then down; only a further one is an
  `unsupported-effort` error. `Resolved.effort` is the level used and the new
  `Resolved.effortAdjusted` (`{ requested, direction }`) records the move; a profile walk traces it
  and adds it to `chosen.warnings`. New `adjustEffort` and `effortAdjustedMessage` exports. The
  package now depends on `@osdlc/agent-call` (`^0.5.0`, its Node-free `./models` subpath only).
- **BREAKING:** the package is renamed `@sksizer/tool-router` (was `@sksizer/agent-route`) and moves
  to `packages/ts/tool-router`, named for the feature it implements, the tool router.
- **BREAKING:** `Binding` names its reference `tool`, not `model` (`{ profile } | { tool }`).
- **BREAKING:** the author rule is the caller's, not the profile's. A profile's long form drops
  `not_the_author` and `if_only_author_left` (an unknown key now), `Profile` drops `notTheAuthor`
  and `ifOnlyAuthorLeft`, and `chooseFromProfile` takes the rule as `ctx.authorRule`. New
  `authorRule`, `authorRuleFields` and `IfOnlyAuthorLeftSchema` give a caller's config the keys
  and their defaults.
- **BREAKING:** a tool's `binary` is not config. `RouterConfigSchema` drops `tools.<id>.binary`
  (an unknown key now) and `BINARY_PATTERN` is gone. A built-in tool runs as the snapshot names
  it, and a declared tool, which no longer needs `binary`, runs as its id.
- **BREAKING:** `ModelsConfigSchema` and `ModelsConfig` are `RouterConfigSchema` and
  `RouterConfig`, for sdlc's config block, renamed `router:` (was `models:`).
- Version set to 0.3.1 from the API history, ahead of the first public release.

### Added

- A `tool` binding may be a wildcard (`*/max`, `*/fast[local]`): `resolveBinding` walks it as a
  one-entry profile through the chain order, `DEFAULT_CHAIN_ORDER` unless the caller's policy sets
  one.
- `launchMode(query, tool, model)` and `viaArgs(via)`: the launch mode a tool needs to reach a
  model's provider (codex's `--oss --local-provider ollama`), the name the mode takes, and the
  model as `provider/id`.
- **A model catalogue** ([#2944](https://github.com/sksizer/dev/pull/2944), D-5C1M): tools,
  providers, models and offerings with a shipped snapshot (`catalogue/`), layered user and project
  overrides, a models.dev import and a query surface. Routing profiles, chains, context
  classification, validity checks and a detect report build on it. The package stays pure and
  browser-safe.
- **`./config` subpath**: `profilesSection`, `routingSection` and `routerSection` config sections.
  They take the host's `consumers` option and depend on `@sksizer/cli-tool`, so the subpath is not
  browser-safe.
- `routerSection` takes an optional `stability` (`stable` or `experimental`) that the host sets for
  the `router` key; absent is `stable`.

### Removed

- **BREAKING:** the per-tool tables (`tables`, `BUILTIN_TOOL_TABLES`, `mergeToolTables`) and the
  dependency on `@sksizer/agent-call`. Which model a tier names is catalogue data.

## [0.2.0] - 2026-10-10

### Changed

- **BREAKING:** the built-in tool tables drop `gemini` and add `antigravity`
  ([#2955](https://github.com/sksizer/dev/pull/2955)). Antigravity accepts `low`, `medium` and
  `high` effort only, so `max` resolves to an `unsupported-effort` error; it has no tier table, so
  a tier reference on it does not resolve.

## [0.1.0] - 2026-10-05

### Added

- Pure resolver for model references and routing profiles
  ([#2731](https://github.com/sksizer/dev/pull/2731)): reference parsing (`ref`), profile parsing
  and ordered selection with `not_the_author` and `if_only_author_left` (`profile`,
  `chooseFromProfile`), per-tool tables with `mergeToolTables` and `BUILTIN_TOOL_TABLES` (`tables`),
  and a `Result` type. Environmental inputs (tables, availability, author) are passed in; it never
  spawns, reads files or touches the network.

### Changed

- Imports model tables from the node-free `@sksizer/agent-call/models` entry point and ships its
  TypeScript source directly instead of a built `dist`
  ([#2771](https://github.com/sksizer/dev/pull/2771)).
