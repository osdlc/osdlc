# @osdlc/markdown-link

Obsidian wikilink parsing, with no dependencies. The TypeScript twin of the
parsing half of the Rust `markdown-link` crate (`packages/rust/markdown-link`; the crate is
still named `wikilink` until [#3564](https://github.com/sksizer/dev/pull/3564) lands). Each
function gives the same answer as its Rust namesake, and both suites read the
crate's `tests/fixtures/conformance.json`.

Resolution (`LinkIndex`) is not here yet.

## Exports

- Code: `stripCode` blanks fenced and inline code to spaces, keeping every
  `\n` and the code point count, so links in code are not harvested.
  `stripCodeWith(text, rules)` takes `'commonmark'` (the default) or
  `'skill-export'`.
- One link: `parseInner` splits a wikilink body into target, heading and
  alias; `targetRange` is where the target sits in it.
- Markdown link URLs: `isVaultLinkUrl` says whether a URL is a note or an
  attachment; `mdLinkTarget` percent-decodes it and drops `.md`.
- A body: `bodyLinksSpanned` finds every wikilink, embed and relative markdown
  link, with its span; `bodyLinks` is the same scan without spans.
- Display text: `displayText` replaces each wikilink and embed with what a
  reader sees, its alias or else its target. An embed's `|300` or `|300x200`
  is a size, not text, so `![[img.png|300]]` shows `img.png`.
- Typed references: `parseTypedRef` reads a whole `[[type/slug]]` or
  `[[type/slug|Alias]]` value into `{ kind, slug, alias }`, or `null`.
- `ATTACHMENT_EXTENSIONS`: the extensions that count as vault attachments.
  `@osdlc/markdown-render` re-exports it.

Spans and ranges are UTF-16 offsets, so `body.slice(start, end)` is the link.
The Rust crate reports byte offsets.

```ts
import { bodyLinksSpanned } from '@osdlc/markdown-link'

bodyLinksSpanned('See [[Note#h|alias]] and `[[not a link]]`')
// [{ kind: 'wikilink', raw: 'Note#h|alias', target: 'Note', start: 4, end: 20 }]
```
