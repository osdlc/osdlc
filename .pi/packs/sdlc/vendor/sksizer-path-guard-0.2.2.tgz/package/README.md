# @sksizer/path-guard

Path containment guard for TypeScript. Twin of the Rust
[`path-guard`](https://github.com/sksizer/rust-path-guard) crate.

A substring check such as `!p.includes('..')` is weak in both directions. It
rejects innocent names (`My ..dotfiles note.md`) and accepts hostile ones: an
absolute path, a Windows drive, a `~` a shell would expand, a NUL byte, or a
symlink whose target leaves the root although its spelling never says `..`.

So the guard has two layers, and both are mandatory:

1. **Lexical**: `validateRelative` rejects empty paths, NUL bytes, a leading
   `~`, Windows drive and UNC prefixes, absolute paths, and `.`, `..` or empty
   segments, without touching the filesystem. It returns the normalised form
   (backslashes folded to `/`, no trailing slash).
2. **Containment**: `resolveInside` joins a validated path onto a root and
   proves the result stays inside it. It resolves symlinks in whatever part of
   the path exists, so a symlink out of the root is refused and a path that
   does not exist yet can still be checked. A dangling symlink is followed to
   where its target would be created, so a link to a missing file outside the
   root is refused too; a chain of more than 40 links is refused. The root need
   not exist either. `tryResolveInside` is the same check returning null instead
   of throwing. `contains`
   answers the same question for two absolute paths.

```ts
import { PathError, resolveInside } from '@sksizer/path-guard'

resolveInside('/srv/data', 'notes/a.md') // '/srv/data/notes/a.md'

try {
  resolveInside('/srv/data', '../etc/passwd')
} catch (e) {
  if (e instanceof PathError) e.kind // 'parent_segment'
}
```

The check is a snapshot. A symlink planted or changed after `resolveInside`
returns is not seen. To create a file, open it with `fs.open(path, 'wx')`: that
open fails when the final component is a symlink, dangling or not. A symlink
swapped into a parent directory still needs a per-component no-follow open,
which Node does not have. A hard link to a file outside the root is out of
reach of any path check. Symlink handling is tested on POSIX only.

A refusal throws a `PathError` whose `kind` is one of `empty`, `nul`,
`tilde`, `windows_path`, `absolute`, `parent_segment`, `degenerate_segment`
or `escapes`.

The containment layer reads the filesystem through a `Resolver`, which answers `realpath` and
`readlink`. `nodeResolver` is the default; pass another, such as an in-memory table, as the last
argument of `resolveInside`, `contains` or `canonicalExistingPrefix`. A table must also hold every
ancestor of each entry, as the `Resolver` doc requires; a table of leaf entries gives wrong answers
with no error.

## Reading a file inside a root

A check followed by a read leaves a window: the file or a parent directory can
be swapped for a symlink in between. `openContainedFile(realRoot, path)` checks,
opens, then resolves the path again and accepts the handle only when it is the
file found at that real path (same device and inode). `readContainedFile`
reads through it and refuses anything that is not a regular file. The open is
non-blocking, so a FIFO cannot hang the call.

`isInside` is the lexical check alone. `realPathInside` and
`existingPathInside` resolve an existing path and check it against a root.
`realpathOrSelf` is `canonicalExistingPrefix` of the absolute path: it
resolves symlinks in the part that exists and folds any `..` after it against
that real path.

Paths are POSIX.

## Conformance

The Rust crate and this package run one shared fixture,
`packages/path-guard-parity/parity.json` in the monorepo they are developed in.
A published copy does not carry it, so there the parity suite skips with a
message.

## License

MIT.
