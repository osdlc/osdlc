# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed

- The owner lookup ignores the caller's `GIT_DIR`, `GIT_WORK_TREE`, `GIT_INDEX_FILE`,
  `GIT_COMMON_DIR` and per-call config variables (`GIT_CONFIG_PARAMETERS`,
  `GIT_CONFIG_COUNT`, `GIT_CONFIG_KEY_<n>`, `GIT_CONFIG_VALUE_<n>`).
- A relative-path remote such as `owner/repo` no longer matches an owner.
- A hosted-git-info shortcut remote such as `github:owner/repo` no longer matches an owner.

### Changed

- The trust policy now lives in `@sksizer/cli-tool/trust`, which takes the
  origin-owner lookup as an injected `ownerOf`. `policyDecision`, `trustDecision`
  and `policyExecGate` here are the same functions bound to a git-backed `ownerOf`,
  so callers are unchanged.

## [0.2.0] - 2026-09-18

### Added

- **`policyExecGate(store, policy, args, opts?)`** — `trustDecision` layered
  over `@sksizer/cli-tool/trust`'s `resolveExecGate` (via its new `trusted`
  hook), so a tool combines its configured value, a per-run flag AND the
  marker-or-policy decision in one call and gets `by`/`rule` back alongside
  the `ExecGate`. `detect-runners` and `waypost` are the second consumer,
  mounting this behind a user-layer `trust.paths`/`trust.owners` config block.
  ([#2179](https://github.com/sksizer/dev/pull/2179))

## [0.1.0] - 2026-09-16

### Added

- **First resident: the trust policy, moved from `sdlc`'s
  `lib/config/trust.ts`.** `policyDecision`/`trustDecision`, the path glob
  matcher and its dialect (`*`, `?`, `**`, with a trailing `/**` never
  matching the directory itself), and the origin-owner lookup over
  `@sksizer/easy-git`/`@sksizer/easy-gh`. Path token expansion (`~`,
  `{name}`) is injected by the caller, so `policyDecision`/`trustDecision`
  take an optional `expandPath` alongside the plain `{ paths, owners }` policy
  object. sdlc keeps a thin adapter over its machine-file `trust:` block; see
  `packages/ts/sdlc-tool/README.md` for the glob dialect and the
  origin-remote threat model this package owns.
  ([#2172](https://github.com/sksizer/dev/pull/2172))
