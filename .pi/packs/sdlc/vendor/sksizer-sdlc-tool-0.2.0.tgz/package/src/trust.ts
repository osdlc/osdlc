/**
 * The git-aware trust POLICY: which repository roots a tool may treat as
 * consented-to run their own scripts, decided from a policy object the
 * caller supplies rather than any config file this package reads itself.
 *
 * The policy itself — the path glob matcher and its dialect, the marker → path
 * → owner precedence, `policyExecGate` — lives in `@sksizer/cli-tool/trust`
 * ([[D-CXJE-config-sections-and-standalone-tools]] Decision 6), so a standalone
 * tool gets it without this package. What stays here is the one thing that
 * needs git: the owner of a root's `origin` remote, which this module binds as
 * the default `ownerOf`, so `policy.owners` matches here and never does in a
 * tool that supplies no git.
 *
 * Ported from sdlc's `lib/config/trust.ts`
 * ([[D-V2XJ-verb-cascade-and-repo-trust]]). `policy` is caller-supplied data,
 * never read from a file here: a tool's own config format (sdlc's machine-file
 * `trust:` block, or another tool's equivalent) is exactly the kind of thing
 * this package must not know about. Path token expansion is likewise the
 * caller's, as an injected `expandPath` callback.
 */

import { parseOwnerRepo } from '@osdlc/typed-gh'
import { Git } from '@osdlc/typed-git'
import {
  policyDecision as basePolicyDecision,
  policyExecGate as basePolicyExecGate,
  trustDecision as baseTrustDecision,
  type PolicyDecision,
  type PolicyDecisionOptions,
  type TrustBy,
  type TrustDecision,
  type TrustPolicy,
  type ExecGate,
  type TrustStore,
} from '@sksizer/cli-tool/trust'

export type {
  PolicyBy,
  PolicyDecision,
  PolicyDecisionOptions,
  TrustBy,
  TrustDecision,
  TrustPolicy,
} from '@sksizer/cli-tool/trust'

/**
 * `root`'s `origin` remote owner, or null when there is none we can read.
 */
function originOwner(root: string): string | null {
  const res = new Git(root).try.remoteGetUrl('origin')
  if (!res.ok || res.value === null) return null
  return parseOwnerRepo(res.value)?.owner ?? null
}

/** {@link PolicyDecisionOptions}, with the git-backed owner lookup filled in. */
function withGit(opts: PolicyDecisionOptions): PolicyDecisionOptions {
  return { ownerOf: originOwner, ...opts }
}

/**
 * `policy.paths`/`policy.owners` only — never a marker store. Exposed
 * separately from {@link trustDecision} so a caller can ask "does policy
 * ALSO cover this root" independent of whether a marker exists (an
 * `untrust`-style "removing the marker changes nothing" notice). The owner is
 * read from the root's `origin` remote.
 */
export function policyDecision(
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<PolicyDecision> {
  return basePolicyDecision(root, policy, withGit(opts))
}

/**
 * Whether `root` (any spelling — a symlink and its target are one decision)
 * is trusted, and by what: a marker grant in `store` first, then `policy`
 * ({@link policyDecision}).
 */
export function trustDecision(
  store: TrustStore,
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<TrustDecision> {
  return baseTrustDecision(store, root, policy, withGit(opts))
}

/**
 * `resolveExecGate` (`@sksizer/cli-tool/trust`), with {@link trustDecision}
 * standing in for the store's own marker-only `isTrusted` check. The one call a
 * tool of this package's shape makes to turn "is this root trusted, by marker or
 * by policy" plus "is execution configured on, and did a per-run flag say
 * otherwise" into the single boolean it acts on, with `by`/`rule` attached.
 */
export function policyExecGate(
  store: TrustStore,
  policy: TrustPolicy,
  args: { root: string; configured: boolean; flag?: boolean | undefined },
  opts: PolicyDecisionOptions = {},
): Promise<ExecGate & { by: TrustBy | null; rule?: string }> {
  return basePolicyExecGate(store, policy, args, withGit(opts))
}
