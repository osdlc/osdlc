/**
 * The git-aware trust policy: which repository roots a tool may treat as
 * consented-to run their own scripts, decided from a policy object the
 * caller supplies rather than any config file this package reads itself.
 *
 * The policy itself (the path glob matcher and its dialect, the marker, path,
 * owner precedence, `policyExecGate`) lives in `@osdlc/cli-tool/trust`, so a
 * tool that needs no git gets it without this package. What stays here is the
 * one thing that needs git: the owner of a root's `origin` remote. This module
 * binds it as the default `ownerOf`, so `policy.owners` matches here and never
 * does in a tool that supplies no git.
 *
 * `policy` is caller-supplied data, never read from a file here. Path token
 * expansion is likewise the caller's, as an injected `expandPath` callback.
 */

import { parseOwnerRepo } from '@osdlc/typed-gh'
import { Git } from '@osdlc/typed-git'
import {
  policyDecision as basePolicyDecision,
  policyExecGate as basePolicyExecGate,
  trustDecision as baseTrustDecision,
  type PolicyDecision,
  type PolicyDecisionOptions,
  type TrustBy,
  type TrustDecision,
  type TrustPolicy,
  type ExecGate,
  type TrustStore,
} from '@osdlc/cli-tool/trust'

export type {
  PolicyBy,
  PolicyDecision,
  PolicyDecisionOptions,
  TrustBy,
  TrustDecision,
  TrustPolicy,
} from '@osdlc/cli-tool/trust'

/**
 * Git variables the caller's environment must not apply to the owner lookup:
 * they point git at another repository or add config that rewrites the
 * remote. Git itself exports `GIT_DIR`, `GIT_INDEX_FILE`, `GIT_COMMON_DIR`
 * and `GIT_CONFIG_PARAMETERS` (from `-c`) to hooks and aliases, so they leak
 * into a tool by accident. `GIT_CONFIG_GLOBAL`, `GIT_CONFIG_SYSTEM` and
 * `GIT_CONFIG_NOSYSTEM` are kept on purpose: they are deliberate user setup,
 * like `~/.gitconfig`, whose `insteadOf` rules still apply.
 */
const GIT_LOCATION_VARS = ['GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR']
const GIT_CONFIG_VAR = /^GIT_CONFIG(?:$|_COUNT$|_PARAMETERS$|_KEY_\d+$|_VALUE_\d+$)/

/**
 * Run `fn` with the git variables listed above removed from `process.env`,
 * then put them back. The typed git client's `env` option is add-only
 * (`Record<string, string>`), and an empty `GIT_DIR` is an error, so the
 * variables are removed here around one call. `fn` must be synchronous: the
 * process environment is shared, so an await inside would let other code see
 * the change. A typed-git change that allows removal would replace this helper.
 */
function withoutGitOverrides<T>(fn: () => T): T {
  const saved = new Map<string, string>()
  for (const [name, value] of Object.entries(process.env)) {
    if (value === undefined) continue
    if (GIT_LOCATION_VARS.includes(name) || GIT_CONFIG_VAR.test(name)) saved.set(name, value)
  }
  for (const name of saved.keys()) delete process.env[name]
  try {
    return fn()
  } finally {
    for (const [name, value] of saved) process.env[name] = value
  }
}

/** A remote git reads as a URL (`scheme://...`) or as scp-style (`[user@]host:path`). */
const URL_REMOTE = /^[a-z][a-z0-9+.-]*:\/\//i
const SCP_REMOTE = /^(?:[^@/:\s]+@)?[^@/:\s]+:(?!\/\/)/
/**
 * hosted-git-info shortcuts (`github:owner/repo`). Git reads these as scp-style
 * ssh to a host called `github`, so they have no owner here.
 */
const SHORTCUT_REMOTE = /^(?:github|gitlab|bitbucket|gist|sourcehut):/

/**
 * `root`'s `origin` remote owner, or null when there is none we can read.
 * Git runs in `root` with the caller's git location and config variables
 * removed, so they cannot point it at another repository. Git still searches
 * upward from `root`, so a directory without its own `.git` inside a
 * repository gets that repository's owner. A remote that is
 * neither a URL nor scp-style is a local path (`owner/repo` is one) and has
 * no owner.
 */
function originOwner(root: string): string | null {
  const res = withoutGitOverrides(() => new Git(root).try.remoteGetUrl('origin'))
  if (!res.ok || res.value === null) return null
  if (SHORTCUT_REMOTE.test(res.value)) return null
  if (!URL_REMOTE.test(res.value) && !SCP_REMOTE.test(res.value)) return null
  return parseOwnerRepo(res.value)?.owner ?? null
}

/** {@link PolicyDecisionOptions}, with the git-backed owner lookup filled in. */
function withGit(opts: PolicyDecisionOptions): PolicyDecisionOptions {
  return { ownerOf: originOwner, ...opts }
}

/**
 * `policy.paths`/`policy.owners` only — never a marker store. Exposed
 * separately from {@link trustDecision} so a caller can ask "does policy
 * ALSO cover this root" independent of whether a marker exists (an
 * `untrust`-style "removing the marker changes nothing" notice). The owner is
 * read from the root's `origin` remote.
 */
export function policyDecision(
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<PolicyDecision> {
  return basePolicyDecision(root, policy, withGit(opts))
}

/**
 * Whether `root` (any spelling — a symlink and its target are one decision)
 * is trusted, and by what: a marker grant in `store` first, then `policy`
 * ({@link policyDecision}).
 */
export function trustDecision(
  store: TrustStore,
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<TrustDecision> {
  return baseTrustDecision(store, root, policy, withGit(opts))
}

/**
 * `resolveExecGate` (`@osdlc/cli-tool/trust`), with {@link trustDecision}
 * standing in for the store's own marker-only `isTrusted` check. Turns "is this
 * root trusted, by marker or by policy" plus "is execution configured on, and
 * did a per-run flag say otherwise" into the single boolean a tool acts on,
 * with `by`/`rule` attached.
 */
export function policyExecGate(
  store: TrustStore,
  policy: TrustPolicy,
  args: { root: string; configured: boolean; flag?: boolean | undefined },
  opts: PolicyDecisionOptions = {},
): Promise<ExecGate & { by: TrustBy | null; rule?: string }> {
  return basePolicyExecGate(store, policy, args, withGit(opts))
}
