/**
 * `@sksizer/sdlc-tool`: decide whether a repository root is trusted, from a
 * marker in a trust store, path patterns and the owner of its `origin` remote.
 *
 * It knows git and GitHub through `@osdlc/typed-git` and `@osdlc/typed-gh`, and
 * it builds on the trust engine in `@osdlc/cli-tool`. It does not know the
 * config format or vocabulary of any tool that uses it.
 *
 * The same functions and types are also exported from the `./trust` subpath.
 */

export {
  policyDecision,
  policyExecGate,
  trustDecision,
  type PolicyBy,
  type PolicyDecision,
  type PolicyDecisionOptions,
  type TrustBy,
  type TrustDecision,
  type TrustPolicy,
} from './trust.ts'
