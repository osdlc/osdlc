# Contributing

Thanks for your interest in `@sksizer/sdlc-tool`.

## Issues

Report bugs and ask for features in the
[issue tracker](https://github.com/osdlc/osdlc/issues). For a bug, include the
library version, your runtime and its version, your operating system, and the
call and inputs that misbehave. Report security problems privately. See
[SECURITY.md](./SECURITY.md).

## Pull requests

Open pull requests in the repository that holds this package. They are
reviewed and merged there.

## Running the tests

The tests run on [Bun](https://bun.sh). `git` must be on `PATH`: the tests
create real temporary repositories.

```sh
bun install
bun test
```

Other checks:

```sh
bun run typecheck
bun run lint
bun run format:check
```

## Code style

- TypeScript, ES modules, and explicit `.ts` import paths.
- Prettier formats the code and oxlint checks it. Run `bun run format` and
  `bun run lint` before you commit.
- Add a test for each behaviour change or bug fix. Use real temporary git
  repositories, not mocks of git.
- A new export gets TSDoc and an example in `examples/`, which imports the package by name. A test
  fails if an exported function is not called, or an exported type not imported, in `examples/`.
- Add a line to `CHANGELOG.md` under `[Unreleased]` for a change users can see.
