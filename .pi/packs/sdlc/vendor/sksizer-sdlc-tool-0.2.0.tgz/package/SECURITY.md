# Security policy

## Reporting a vulnerability

Please report vulnerabilities privately. Do not open a public issue.

Use GitHub private vulnerability reporting on the repository: open the
[Security tab](https://github.com/osdlc/osdlc/security) and choose
"Report a vulnerability".

Include the version, a short description, and steps to reproduce. A minimal
code sample helps.

## Supported versions

Only the latest release gets security fixes. While the version is 0.x, that
is the latest minor release. Upgrade to it.

## What to expect

This is a small project. We aim to reply within a week. We will tell you
whether we accept the report and keep you updated until a fix is released.
We will credit you in the release notes if you want that.

## Threat model

This package decides whether a repository root is trusted. A wrong "trusted"
answer lets a tool run code from a repository the user did not consent to, so
reports about wrong answers are in scope.

- **The owner lookup runs `git remote get-url origin` in the candidate root.**
  The call runs before trust is decided, and only when the policy lists
  owners. The verb reads configuration and runs no hook. The caller's
  `GIT_DIR`, `GIT_WORK_TREE`, `GIT_INDEX_FILE`, `GIT_COMMON_DIR`,
  `GIT_CONFIG_PARAMETERS`, `GIT_CONFIG_COUNT` and `GIT_CONFIG_KEY_<n>` /
  `GIT_CONFIG_VALUE_<n>` variables are removed for that call. Git itself exports
  `GIT_DIR`, `GIT_INDEX_FILE`, `GIT_COMMON_DIR` and `GIT_CONFIG_PARAMETERS`
  (from `-c`) to hooks and aliases, so they leak into a tool by accident.
  `GIT_CONFIG_GLOBAL`, `GIT_CONFIG_SYSTEM` and `GIT_CONFIG_NOSYSTEM` are kept
  on purpose: they are deliberate user setup, like `~/.gitconfig`, whose
  `insteadOf` rules still apply.
- **Owner trust rests on the unverified local `.git/config`.** A
  `url.<base>.insteadOf` rewrite changes the owner that is read. A directory
  that ships its own `.git/config`, such as an unpacked archive, chooses its
  own `origin`.
- **A directory without its own `.git` gets the owner of the repository around
  it.** Git searches upward from the root. Pass the repository top level.
- **A repository cannot grant itself owner trust through its tracked files.**
  The `origin` URL lives in `.git/config`, which is written at clone time or
  by hand. Tracked content, hooks and submodule config cannot rewrite another
  checkout's `.git/config`.
- **Only some remote shapes have an owner.** A URL (`scheme://...`) or an
  scp-style address with a user (`git@github.com:mine/x`) is parsed. A
  relative path (`mine/x`) and a hosted-git-info shortcut (`github:mine/x`,
  which git reads as ssh to a host named `github`) have no owner. Scp-style
  without a user (`github.com:mine/x`) is not matched. A self-hosted host
  that `hosted-git-info` does not know has no owner either: use
  `policy.paths`.
- **The host is ignored when owners are matched.** An owner `my-org` on GitLab
  satisfies `owners: ['my-org']`.
- **The `origin` owner is a proxy, not proof.** It reports who a repository
  was cloned from, not who wrote its code. A fork or a mirror answers to a
  different owner than its authors.
- **Trust is per repository, not per branch.** Linked worktrees share one
  `.git` directory and so one `origin`.
- **A policy entry travels with the config it is written in.** A marker grant
  is a decision made by hand on one machine. A policy entry is not.

The package starts no process of its own, writes no files, and reads no
configuration file. Path matching and the marker store are in
`@osdlc/cli-tool/trust`; report problems in those there.
