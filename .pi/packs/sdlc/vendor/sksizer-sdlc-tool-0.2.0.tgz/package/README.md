# `@sksizer/sdlc-tool`

Decide whether a repository root is trusted, so a tool can safely run that
repository's own scripts, evaluate its build config or fire its hooks. Three
layers decide, in order: a marker a person granted by hand, path patterns, and
the owner of the repository's `origin` remote. You supply the policy as plain
data. This package reads no config file.

It is for authors of command-line tools that act on repositories they did not
write. It is not a sandbox, and it does not verify who wrote a repository: the
owner layer only reports who the repository was cloned from (see the threat
model below).

## When not to use it

- To parse a git remote URL: use
  [`hosted-git-info`](https://www.npmjs.com/package/hosted-git-info). This
  package gets its owner lookup through it, via `@osdlc/typed-gh`.
- To read the `origin` URL or its owner and nothing else: the
  [`remote-origin-url`](https://www.npmjs.com/package/remote-origin-url) and
  [`git-username`](https://www.npmjs.com/package/git-username) packages do that.
  This package adds the policy and the precedence on top of the lookup.
- To read the workspace-trust stores of editors and agent tools:
  [`agent-trust`](https://www.npmjs.com/package/agent-trust) does that. This
  package keeps no such store.
- If you do not need git: the policy and marker store, without the owner
  lookup, are in `@osdlc/cli-tool/trust`.

## Install

The package is not published yet. The target name is `@osdlc/sdlc-tool`.

## Runtimes and platforms

The tests run under Bun. The package is plain TypeScript and ES modules with
no native code. It runs `git`, so `git` must be on `PATH`. Linux and macOS are
supported for 0.x. Windows is not claimed.

## Quick start

The examples folder in the repository runs the same calls as tests.

```ts
import { trustStore } from '@osdlc/cli-tool/trust'
import { policyDecision, trustDecision } from '@sksizer/sdlc-tool/trust'

const policy = { paths: ['/home/me/work/**'], owners: ['my-org'] }

// Policy only: no marker store consulted.
const p = await policyDecision(repoRoot, policy)

// Marker first, then policy.
const store = trustStore({ tool: 'my-tool' })
const t = await trustDecision(store, repoRoot, policy)
if (t.trusted) console.log(`trusted by ${t.by}`, t.rule ?? '')
```

`policyExecGate` turns a trust decision into the boolean a tool acts on:

```ts
import { trustStore } from '@osdlc/cli-tool/trust'
import { policyExecGate } from '@sksizer/sdlc-tool/trust'

const store = trustStore({ tool: 'my-tool' })
const gate = await policyExecGate(store, policy, { root: repoRoot, configured, flag })
if (gate.allowExec) {
  /* ... */
}
// gate.by / gate.rule say which layer decided, for a `--show`-style report.
```

## Trust policy

The policy itself (glob matcher, marker, path and owner precedence,
`policyExecGate`) lives in `@osdlc/cli-tool/trust`, which knows no git: it
takes the owner of a root's `origin` remote as an injected `ownerOf`. This
package binds that one thing to `@osdlc/typed-git` and re-exports the
functions, so a tool that mounts it gets the owner rule and a standalone tool
built on `@osdlc/cli-tool` alone does not.

A setting a repository can write is a setting it can grant itself, so such a
setting cannot authorize running that repository's own code. The marker store
in `@osdlc/cli-tool/trust` answers "has a person consented to this
repository, once, by hand?". This package adds two more layers that a tool's
own configuration can use to pre-authorize a whole class of repositories, and
the precedence between all three: marker, then path, then owner.

### API

| Export | From | Does |
|---|---|---|
| `policyDecision(root, policy, opts?)` | `.`, `./trust` | `policy.paths`/`policy.owners` only, never a marker store |
| `trustDecision(store, root, policy, opts?)` | `.`, `./trust` | a marker grant in `store` first, then `policyDecision` |
| `policyExecGate(store, policy, args, opts?)` | `.`, `./trust` | `trustDecision` layered over `@osdlc/cli-tool/trust`'s `resolveExecGate`; `args` is `{ root, configured, flag? }`, the result is an `ExecGate` with `by`/`rule` attached |
| `TrustPolicy` | `.`, `./trust` | `{ paths: string[]; owners: string[] }`, plain caller-supplied data |
| `TrustBy` / `PolicyBy` | `.`, `./trust` | which layer decided: `'marker' \| 'path' \| 'owner'`, or the two `policyDecision` can return |
| `TrustDecision` / `PolicyDecision` | `.`, `./trust` | `{ trusted, by, rule? }` |
| `PolicyDecisionOptions` | `.`, `./trust` | `{ expandPath?, ownerOf?, store? }`, see below |

`opts.expandPath?: (raw: string) => Promise<string> | string` expands a
`policy.paths` pattern's own vocabulary (a leading `~`, `{name}` tokens,
whatever the caller's paths format defines) before matching. This package has
no such vocabulary, so patterns are matched literally when `expandPath` is
omitted.

`opts.ownerOf?: (root: string) => string | null` supplies the owner of a root.
When `opts` has an `ownerOf` it is used in place of the git lookup.

`opts.store` lets a caller that already holds a `TrustStore` reuse its root
resolution instead of resolving twice. A marker key and a path match always
agree on one root's resolved spelling, whichever one supplied it.

Owner comparison is case-insensitive. Pass `policy.owners` exactly as
configured. The host is ignored when owners are matched: an owner `my-org` on
GitLab satisfies `owners: ['my-org']`.

### The glob dialect

`policy.paths` entries are matched against a small, deliberate glob dialect —
not a general-purpose glob engine, a directory policy matcher. Only `*`,
`?`, and `**` are special. `*` and `?` do not cross a `/` (`*` is "anything
within one path segment", `?` is "one character within one path segment");
`**` does cross `/` (any number of segments, including zero) and swallows one
adjoining slash, so `a/**/b` also matches `a/b`. `[...]` character classes
and `{a,b}` brace alternation are NOT part of the dialect, so each of those
characters matches only itself, literally, with no diagnostic when that is
not what was meant. A trailing `/**` matches descendants only, never the
named directory itself: `/home/me/work/**` does not match `/home/me/work`.
To trust a directory that IS itself a repo root, list it literally in
addition to (or instead of) the `/**` glob.

`policy.owners` only matches hosts `@osdlc/typed-gh`'s `parseOwnerRepo`
(built on `@osdlc/typed-git`'s `parseGitUrl`, in turn built on
`hosted-git-info`) knows — GitHub, GitLab, Bitbucket, and Sourcehut. A
self-hosted or enterprise origin (`https://ghe.example.com/owner/repo`) is
never recognized as belonging to any owner, however the entry is spelled;
use `policy.paths` for those repos instead.

A scp-style remote without a user (`github.com:mine/x`) is not matched, and
neither is a shortcut such as `github:mine/x`. Use `git@github.com:mine/x`.

### Threat model

`policy.owners` trusts whoever a repository was cloned from, not who wrote its
code. The owner comes from the local `.git/config`, which this package does not
verify: an unpacked archive can ship its own `origin`, and trust applies to the
whole repository, not to one branch. A policy entry in a config file also
travels to other machines, unlike a marker. Prefer `policy.paths` for "repos I
keep under this directory". The full threat model and the limits of the owner
lookup are in [SECURITY.md](./SECURITY.md).

## Dependencies

`@osdlc/cli-tool/trust`, `@osdlc/typed-git` and `@osdlc/typed-gh` only. This
package starts no process of its own; `@osdlc/typed-git` runs `git`.
