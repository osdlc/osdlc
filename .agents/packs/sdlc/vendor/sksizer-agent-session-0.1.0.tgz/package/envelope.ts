/**
 * The envelope every line of an agent log carries, and the correlation ids
 * that fill it.
 *
 * `session`, `run` and `subject` are present when known: from the caller, or
 * from the `SDLC_SESSION`, `SDLC_RUN` and `SDLC_SUBJECT` variables a launched
 * session's process tree inherits (`sessionEnv` in `./env.ts`).
 */

import { z } from 'zod'

/** The envelope version written as `v`. */
export const LOG_ENVELOPE_VERSION = 1

export const LOG_SOURCES = ['launcher', 'hook', 'digest', 'op', 'cli'] as const
export const LogSourceSchema = z.enum(LOG_SOURCES)
export type LogSource = z.infer<typeof LogSourceSchema>

export const LogEnvelopeSchema = z.object({
  v: z.literal(LOG_ENVELOPE_VERSION),
  ts: z.string().describe('RFC 3339 instant the event happened.'),
  kind: z.string(),
  writer: z
    .string()
    .describe(
      'The machine that wrote the line (`machineId()`: a stable derived id, not the hostname).',
    ),
  session: z.string().optional(),
  run: z.string().optional(),
  subject: z.string().optional(),
  source: LogSourceSchema,
})
export type LogEnvelope = z.infer<typeof LogEnvelopeSchema>

/** The ids that tie a line to a session, a unit of work and the task or PR it is about. */
export interface Correlation {
  session?: string
  run?: string
  subject?: string
}

export const RUN_ENV_VAR = 'SDLC_RUN'
export const SUBJECT_ENV_VAR = 'SDLC_SUBJECT'
/**
 * The id of the top-level op invocation in progress (the consumer's op journal
 * exports it for the op's duration). A session that op launches records it as its parent
 * invocation; the session's own tree clears it (`sessionEnv` in `./env.ts`).
 */
export const INVOCATION_ENV_VAR = 'SDLC_INVOCATION'
/**
 * The pid of the process that exported `SDLC_INVOCATION`. `correlationFromEnv` does not
 * check it; the launcher's `resolveLineage` pid check drops an invocation id whose
 * pid is gone, so a leaked id is not recorded as a session's parent.
 */
export const INVOCATION_PID_ENV_VAR = 'SDLC_INVOCATION_PID'
/** Names the session a launched agent belongs to; the process scan reads it back. */
export const SESSION_ENV_VAR = 'SDLC_SESSION'

/** The correlation `env` names; an unset or empty variable is absent. */
export function correlationFromEnv(
  env: Record<string, string | undefined> = process.env,
): Correlation {
  const out: Correlation = {}
  const session = env[SESSION_ENV_VAR]
  const run = env[RUN_ENV_VAR]
  const subject = env[SUBJECT_ENV_VAR]
  if (session) out.session = session
  if (run) out.run = run
  if (subject) out.subject = subject
  return out
}

// Crockford base32: no I, L, O or U, so an id reads aloud and copies cleanly.
const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'

/**
 * A sortable id: `prefix`, 10 base32 characters of the millisecond time, then
 * 16 of randomness (the ULID layout). Ids minted later sort later as strings.
 * Within one millisecond the order is random.
 */
export function newSortableId(prefix: string, now: number = Date.now()): string {
  let time = ''
  let rest = now
  for (let i = 0; i < 10; i++) {
    time = CROCKFORD[rest % 32]! + time
    rest = Math.floor(rest / 32)
  }
  const bytes = crypto.getRandomValues(new Uint8Array(16))
  let random = ''
  for (const b of bytes) random += CROCKFORD[b % 32]!
  return `${prefix}${time}${random}`
}

/** The session and op invocation that started a session, from the environment `env` names; `null` when neither is set. */
export function lineageFromEnv(
  env: Record<string, string | undefined> = process.env,
  selfSession?: string,
): { session: string | null; invocation: string | null } | null {
  const session = env[SESSION_ENV_VAR]
  const invocation = env[INVOCATION_ENV_VAR]
  const parentSession = session && session !== selfSession ? session : null
  const parentInvocation = invocation || null
  return parentSession === null && parentInvocation === null
    ? null
    : { session: parentSession, invocation: parentInvocation }
}

/** A run id: `r-` and a sortable id. It names a run in logs only, never a file. */
export function newRunId(now?: number): string {
  return newSortableId('r-', now)
}
