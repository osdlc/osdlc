# Changelog

## Unreleased

### Changed

- The machine id is stable: `machineId()` is `m-` plus 16 hex characters derived from the
  platform's machine UUID (macOS `IOPlatformUUID`, Linux `/etc/machine-id`, Windows `MachineGuid`),
  resolved once per process, instead of `os.hostname()`, which a laptop's network renames change.
  The UUID itself is never written. A machine whose UUID cannot be read falls back to its hostname.
  New: `deriveMachineId(probe)` and `MachineProbe`. Hard cutover, no migration: records written
  with a hostname keep it and read as another machine's, so reconcile and the live checks leave
  them alone.
  `sessionEnv` now also sets `SDLC_MACHINE_ID` (`MACHINE_ENV_VAR`), and `machineId()` reads it
  first, so a session's hook processes (one per tool call) never spawn `ioreg`/`reg`; only a cold
  start probes the platform.
- `Originator.hostname` is optional and the record's `hostname`/`tz` are `string | undefined`
  (only `startedBy` is nullable). `resolveOriginator(cwd, probe?, identity = true)`: with
  `identity` false (`log.capture.originator` off) it reads neither the person nor the hostname.
- `appendJsonl` takes `{ sync }`; `readJsonlFrom` returns `lines` and `lineCount`; `parseJsonlLines`
  and `resolveMachineId` are exported; `parsePsEnvironment` can return `null`.

### Added

- The `resumed` event reopens an ended session for a new run of the same harness session: state
  `starting`, `endedAt`, `exitCode` and the outcome cleared, `host` and `pid` refreshed. On a
  session that has not ended it is ignored (`illegal_transition`).
- First release, extracted from sdlc: the log
  envelope and JSONL writer, `defineSessionModel` (event log, reducer, state
  machine, record) over a consumer's harness, host and launch-flag vocabulary,
  `looseSessionModel`, the session env tags (`sessionEnv`), the process scan,
  `runStateForStatus`, the reconcile decision (`decideReconcile`,
  `reconcileSessions`), and the start lifecycle behind ports
  (`runHeadlessSession`, `runInteractiveSession`, `endSession`, `resolveRun`,
  `resolveLineage`).
  `scanTaggedProcesses` returns `null` when the scan fails, and
  `decideReconcile` takes a host-pane input of `'failed'` (the probe threw):
  neither ever ends a record.
- `SDLC_AUTHOR` (`AUTHOR_ENV_VAR`) joins the session env tags: `sessionEnv`
  takes the launcher's `author` text, and `authorFromEnv` reads it back.
