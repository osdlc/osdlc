/**
 * `@sksizer/agent-session` — the record of an agent session a launcher starts:
 * an append-only event log per session that reduces to a record, the state
 * machine it moves through, the JSONL writer and log envelope it shares with
 * other journals, the env tags a launched agent carries, a process scan that
 * reads them back, and the reconcile decision that ends a record whose session
 * is gone. The harness, host and launch-flag vocabularies are the consumer's:
 * {@link defineSessionModel} builds the model from them.
 */

export {
  correlationFromEnv,
  INVOCATION_ENV_VAR,
  INVOCATION_PID_ENV_VAR,
  lineageFromEnv,
  LOG_ENVELOPE_VERSION,
  LOG_SOURCES,
  LogEnvelopeSchema,
  LogSourceSchema,
  newRunId,
  newSortableId,
  RUN_ENV_VAR,
  SUBJECT_ENV_VAR,
  type Correlation,
  type LogEnvelope,
  type LogSource,
} from './envelope.ts'

export {
  appendJsonl,
  jsonlSize,
  parseJsonl,
  parseJsonlLines,
  readJsonl,
  readJsonlFrom,
  type AppendOptions,
  type JsonlTail,
} from './writer.ts'

export * from './model.ts'

export {
  AUTHOR_ENV_VAR,
  authorFromEnv,
  deriveMachineId,
  isThisMachine,
  MACHINE_ENV_VAR,
  machineId,
  type Originator,
  type OriginatorProbe,
  resolveOriginator,
  PINNED_CMD_ENV_VAR,
  PROJECT_ROOT_ENV_VAR,
  SESSION_ENV_VAR,
  SESSION_ID_RE,
  sessionEnv,
  TASK_ENV_VAR,
  type MachineProbe,
  type SessionEnv,
} from './env.ts'

export * from './process-scan.ts'
export { runStateForStatus, type AgentStatus } from './status.ts'
export * from './reconcile.ts'
export * from './lifecycle.ts'
