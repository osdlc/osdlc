/**
 * How a launched agent process is tagged: the environment a launcher sets on
 * every launch and resume, read back by the process scan (`./process-scan.ts`)
 * and by the agent's own tools. Also the machine a record belongs to, since a
 * store can be shared between machines and only this machine's records say
 * anything about live processes.
 */

import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir, hostname, platform, userInfo } from 'node:os'
import { dirname, join } from 'node:path'

import { spawnRunner } from '@sksizer/command-seam'

import {
  INVOCATION_ENV_VAR,
  INVOCATION_PID_ENV_VAR,
  RUN_ENV_VAR,
  SESSION_ENV_VAR,
  SUBJECT_ENV_VAR,
} from './envelope.ts'

export { SESSION_ENV_VAR }

/**
 * The shape `crypto.randomUUID()` produces, the only shape a session id has.
 */
export const SESSION_ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

/**
 * The project root a session was launched from. An installed hook has a fixed
 * command that cannot carry it, so a hook reporter reads it from here.
 */
export const PROJECT_ROOT_ENV_VAR = 'SDLC_PROJECT_ROOT'
/** Names the task the session works on; empty otherwise. */
export const TASK_ENV_VAR = 'SDLC_TASK'
/** The exact command the agent should run its tool as; unset when the session has no pin. */
export const PINNED_CMD_ENV_VAR = 'SDLC_PINNED_CMD'
/**
 * Who runs the session's work, as the launcher's text for it (sdlc's is a
 * model reference, `claude/claude-opus-5-5@high`); empty when unknown. This
 * package carries the text and does not parse it.
 */
export const AUTHOR_ENV_VAR = 'SDLC_AUTHOR'

/**
 * The launching process's {@link machineId}, handed down so a child (every
 * `session hook`, which fires once per tool call) reads it instead of probing the
 * platform again. Absent on a cold start, where `machineId()` probes.
 */
export const MACHINE_ENV_VAR = 'SDLC_MACHINE_ID'

/** Environment to set on a child: a value sets the variable, `undefined` unsets it. */
export type SessionEnv = Record<string, string | undefined>

/**
 * Env tags for a session's agent process, applied on every launch and resume.
 * Each tag is always overridden so a parent session's value does not leak
 * through:
 *
 * - `SDLC_TASK` is the given task or empty.
 * - `SDLC_RUN` is empty when the session has no run.
 * - `SDLC_SUBJECT` is the given subject, else the task, else empty.
 * - `SDLC_INVOCATION` and its pid are empty (the agent's own tool calls set
 *   theirs; the launching op's must not read as theirs).
 * - `SDLC_AUTHOR` is the given author text or empty.
 * - `SDLC_PINNED_CMD` is unset when there is no pin.
 * - `SDLC_MACHINE_ID` carries this machine's id, so the session's hook
 *   processes do not probe the platform per tool call.
 *
 * A launcher reads the PARENT's `SDLC_SESSION` and `SDLC_INVOCATION` from its
 * own environment (`lineageFromEnv`) before these overwrite them for the child.
 */
export function sessionEnv(session: {
  id: string
  sdlcPin?: string | undefined
  /** The task the session works on, when the caller knows one. */
  task?: string | null | undefined
  /** The project root of the launch; unset (as is the tag) when the caller does not know it. */
  projectRoot?: string | undefined
  run?: string | null | undefined
  subject?: string | null | undefined
  /** Who runs the work, as the launcher's text (`SDLC_AUTHOR`). */
  author?: string | null | undefined
}): SessionEnv {
  const task = session.task ?? ''
  return {
    [SESSION_ENV_VAR]: session.id,
    [PROJECT_ROOT_ENV_VAR]: session.projectRoot,
    [TASK_ENV_VAR]: task,
    [RUN_ENV_VAR]: session.run ?? '',
    [SUBJECT_ENV_VAR]: session.subject ?? task,
    [INVOCATION_ENV_VAR]: '',
    [INVOCATION_PID_ENV_VAR]: '',
    [AUTHOR_ENV_VAR]: session.author ?? '',
    [PINNED_CMD_ENV_VAR]: session.sdlcPin,
    [MACHINE_ENV_VAR]: machineId(),
  }
}

/** The author text `env` carries (`SDLC_AUTHOR`); `undefined` when unset or empty. */
export function authorFromEnv(
  env: Record<string, string | undefined> = process.env,
): string | undefined {
  return env[AUTHOR_ENV_VAR] || undefined
}

/**
 * What {@link machineId} reads to tell machines apart. Injected so tests never
 * touch the real platform: `platform` is a `process.platform` value, `readFile`
 * returns a file's text or `null` when unreadable, `run` returns a command's
 * stdout or `null` when it failed, `hostname` is the fallback.
 */
export interface MachineProbe {
  platform: string
  readFile(path: string): string | null
  run(argv: string[]): string | null
  hostname(): string
}

const LIVE_PROBE: MachineProbe = {
  platform: platform(),
  readFile(path) {
    try {
      return readFileSync(path, 'utf8')
    } catch {
      return null
    }
  },
  run(argv) {
    const result = spawnRunner(argv[0] ?? '').run(argv.slice(1), {
      cwd: process.cwd(),
      timeoutMs: 5000,
    })
    return result.exitCode === 0 ? result.stdout : null
  },
  hostname: () => hostname(),
}

/** The platform's own machine UUID, or `null` when it cannot be read. */
function platformUuid(probe: MachineProbe): string | null {
  const clean = (v: string | null | undefined) => (v && v.trim() !== '' ? v.trim() : null)
  if (probe.platform === 'darwin') {
    const out = probe.run(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'])
    return clean(out?.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/)?.[1])
  }
  if (probe.platform === 'linux') {
    return (
      clean(probe.readFile('/etc/machine-id')) ?? clean(probe.readFile('/var/lib/dbus/machine-id'))
    )
  }
  if (probe.platform === 'win32') {
    const out = probe.run([
      'reg',
      'query',
      'HKLM\\SOFTWARE\\Microsoft\\Cryptography',
      '/v',
      'MachineGuid',
    ])
    return clean(out?.match(/MachineGuid\s+REG_SZ\s+(\S+)/i)?.[1])
  }
  return null
}

/**
 * The stable id for the machine `probe` describes: `m-` plus the first 16 hex
 * characters of `sha256("sdlc-machine:" + platformUuid)`. The platform UUID is a
 * hardware identifier, so only this derived id is ever written down. A machine
 * whose UUID cannot be read hashes its hostname the same way (under a different
 * prefix, so the two never collide): a raw hostname is never an id, because the
 * id lands on every record and envelope even when `log.capture.originator` is off.
 */
export function deriveMachineId(probe: MachineProbe): string {
  const uuid = platformUuid(probe)
  const seed = uuid !== null ? `sdlc-machine:${uuid}` : `sdlc-machine-host:${probe.hostname()}`
  return `m-${createHash('sha256').update(seed).digest('hex').slice(0, 16)}`
}

const MACHINE_ID_RE = /^m-[0-9a-f]{16}$/

/** Where {@link resolveMachineId} keeps the derived id: `$XDG_CACHE_HOME` or `~/.cache`, under `sdlc/`. */
function machineIdCachePath(): string {
  const base = process.env['XDG_CACHE_HOME']?.trim() || join(homedir(), '.cache')
  return join(base, 'sdlc', 'machine-id')
}

/**
 * The machine's id: the file at `cachePath` when it holds one, else
 * {@link deriveMachineId}, which is then written there. On a cold start (a
 * command typed in a user shell, no inherited {@link MACHINE_ENV_VAR}) this
 * saves the platform probe (a process spawn on darwin and windows) from the
 * critical path of every command after the first. The file holds only the
 * derived id, never the hardware UUID; a write that fails is ignored.
 */
export function resolveMachineId(probe: MachineProbe, cachePath: string | null): string {
  if (cachePath !== null) {
    try {
      const cached = readFileSync(cachePath, 'utf8').trim()
      if (MACHINE_ID_RE.test(cached)) return cached
    } catch {
      // not cached yet
    }
  }
  const id = deriveMachineId(probe)
  if (cachePath !== null) {
    try {
      mkdirSync(dirname(cachePath), { recursive: true })
      writeFileSync(cachePath, `${id}\n`, { mode: 0o600 })
    } catch {
      // an unwritable cache only costs the next probe
    }
  }
  return id
}

let cachedMachineId: string | undefined

/**
 * This machine's id in a record's `machine` and in a journal envelope's
 * `writer`: stable across hostname changes (a laptop's network renames), resolved
 * once per process. A process launched inside a session inherits it from
 * {@link MACHINE_ENV_VAR}; a cold start reads the cache file, and only the
 * first ever resolve probes the platform (see {@link resolveMachineId}).
 */
export function machineId(): string {
  cachedMachineId ??=
    process.env[MACHINE_ENV_VAR]?.trim() || resolveMachineId(LIVE_PROBE, machineIdCachePath())
  return cachedMachineId
}

/**
 * Whether `record` was launched by this machine. Liveness readers (`pid`,
 * `endedAt === null`, the process scan) consider only these; another
 * machine's records are history.
 */
export function isThisMachine(record: { machine: string }): boolean {
  return record.machine === machineId()
}

/** Who started something and where: recorded at session launch and on `run.start`. */
export interface Originator {
  /** The git `user.name` in the launch directory, else the OS login; `null` when neither could be read or identity is not captured. */
  startedBy: string | null
  /** The machine's readable name (`os.hostname()`); the derived {@link machineId} stays its identity. Absent when identity is not captured. */
  hostname?: string | undefined
  /** The IANA zone the machine's clock is set to, e.g. `Europe/Berlin`. */
  tz: string
}

/** What {@link resolveOriginator} reads; injected so tests never touch the real machine. */
export interface OriginatorProbe {
  /** `git config user.name` as run in `cwd`; `null` when unset or git failed. */
  gitUserName(cwd: string): string | null
  /** The OS login name; `null` when it cannot be read. */
  osUser(): string | null
  hostname(): string
  tz(): string
}

const LIVE_ORIGINATOR_PROBE: OriginatorProbe = {
  gitUserName(cwd) {
    try {
      const result = spawnRunner('git').run(['config', 'user.name'], { cwd, timeoutMs: 5000 })
      return result.exitCode === 0 ? result.stdout : null
    } catch {
      return null
    }
  },
  osUser() {
    try {
      return userInfo().username
    } catch {
      return null
    }
  },
  hostname: () => hostname(),
  tz: () => Intl.DateTimeFormat().resolvedOptions().timeZone,
}

/**
 * Who is launching from `cwd`: git `user.name`, falling back to the OS login.
 * With `identity` false (`log.capture.originator` off) neither the person nor the
 * machine's name is read: `startedBy` is `null`, `hostname` absent, and only the
 * time zone is reported.
 */
export function resolveOriginator(
  cwd: string,
  probe: OriginatorProbe = LIVE_ORIGINATOR_PROBE,
  identity = true,
): Originator {
  if (!identity) return { startedBy: null, tz: probe.tz() }
  const clean = (v: string | null): string | null =>
    v !== null && v.trim() !== '' ? v.trim() : null
  return {
    startedBy: clean(probe.gitUserName(cwd)) ?? clean(probe.osUser()),
    hostname: probe.hostname(),
    tz: probe.tz(),
  }
}
