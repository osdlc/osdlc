# @sksizer/agent-session

The record of an agent session a launcher starts. One directory per session
holds an append-only `events.jsonl`; `record.json` is the projection a reducer
computes from it. A writer appends and re-reduces the whole log, so two
processes on one machine cannot overwrite newer state with stale state.

What it holds:

- **Log envelope and writer** (`envelope.ts`, `writer.ts`): the `{v, ts, kind,
  writer, session?, run?, subject?, source}` envelope shared with other
  journals, correlation read from the environment, sortable ids, and a JSONL
  appender, reader and tail.
- **Session model** (`model.ts`): `defineSessionModel({harness, host,
  launchFlags})` builds the event schema, the record schema, the reducer and
  the read/append functions over the consumer's own vocabulary.
  `looseSessionModel` accepts any string, for a reader that must keep reading
  logs written by an older or newer writer.
- **Env tags** (`env.ts`): `sessionEnv` — the variables a launcher sets on an
  agent so its tools and the process scan can tell which session it belongs
  to — plus the machine a record belongs to.
- **Process scan** (`process-scan.ts`): reads those tags back from the
  environment of running processes (macOS `ps -E`, Linux `/proc`), through an
  injected `@sksizer/command-seam` runner.
- **Status** (`status.ts`): the harness-agnostic hook status a harness adapter
  maps into, and the state it reports.
- **Reconcile** (`reconcile.ts`): the decision that ends a record whose session
  is gone (`lost`), over injected probes. A failed process scan or a host probe
  that throws is `unknown` and never ends a record.
- **Lifecycle** (`lifecycle.ts`): what a launcher appends between `launched`
  and the end. `runHeadlessSession` attaches the spawned pid and ends the record
  with the exit code; `runInteractiveSession` opens the session on a host and
  ends it only when the host waited for it; a failed spawn or open still ends
  the record `failed`. `resolveRun` and `resolveLineage` read the run and the
  launching session from the environment. The launcher supplies the ports:
  where events go, how to read the state back, how to spawn or open.

This is sdlc's session model made reusable, not a neutral one: the record
carries some sdlc-shaped fields (`sdlcPin`, origin kinds `task`, `lease`,
`wizard` and `orchestrator`, `claudeFlags`, the `SDLC_*` env tags). Only the
harness, host and launch-flag vocabularies are supplied by the consumer.

Not here: which harnesses exist and their argv, host (terminal multiplexer)
adapters, hook installation, transcripts, digests, usage capture and
notifications. Those stay with the launcher, behind the lifecycle's ports.

Intended consumers: `sdlc` (`solutions/ontological`), and launchers such as
`waypost` and `detect-runners` that want the same session record without
depending on sdlc.

The environment variable names keep their `SDLC_` prefix, so a session
launched by any consumer is visible to every other one's process scan.
