# Security policy

## Reporting a vulnerability

Please report vulnerabilities privately. Do not open a public issue.

Use GitHub private vulnerability reporting on the repository: open the
[Security tab](https://github.com/osdlc/osdlc/security) and choose
"Report a vulnerability".

Include the version, a short description, and steps to reproduce.

## Supported versions

Only the latest release gets security fixes. While the version is 0.x, that
is the latest minor release.

## What to expect

This is a small project. We aim to reply within a week, tell you whether we
accept the report, and credit you in the release notes if you want that.

## Threat model

The `trust` entry decides whether a repository's own scripts may run, and the
`devlink` entry writes a launcher script and runs a development checkout in
place of an installed tool. Reports that let an untrusted repository run code
without consent, bypass a stored trust decision or policy, or make a launcher
run a different checkout than the one selected are in scope. The trust entry is
experimental and has not had a security review.
