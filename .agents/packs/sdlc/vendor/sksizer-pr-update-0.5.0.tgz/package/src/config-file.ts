/**
 * Loading the config of a standalone `pr-update` run: the `pr_update:` and
 * `code_host:` blocks of the project's `sdlc.yaml`, layered under
 * `sdlc.local.yaml`, through `@osdlc/config-layers` — the loader sdlc
 * itself uses ([[D-CXJE-config-sections-and-standalone-tools]]). `SDLC_CONFIG`
 * relocates the pair exactly as it does for sdlc.
 *
 * pr-update mounts only the two sections it reads and ignores every other
 * top-level key (`unknownTopLevel: 'ignore'`), so a file that also holds an
 * `orchestrator:` block — even a malformed one — still works. A mounted block
 * that is invalid is a `ConfigInvalidError` (exit 14).
 *
 * A host embedding this package as a library skips this file entirely and
 * builds a `PrUpdateConfig` from its own config format instead.
 */

import { existsSync } from 'node:fs'
import { join } from 'node:path'

import {
  ConfigInvalidError,
  assembleConfig,
  type ConfigHandle,
  type ConfigLayers,
  type ConfigOf,
} from '@osdlc/config-layers'
import { codeHostSection } from '@sksizer/code-host'

import { PR_UPDATE_CONFIG_FILE, PR_UPDATE_CONFIG_FILE_NAME } from './config-names.ts'
import { prUpdateStandaloneSection } from './config.ts'

/** The sections a standalone run mounts, in key order. */
export const STANDALONE_SECTIONS = [prUpdateStandaloneSection, codeHostSection] as const

export type StandaloneConfig = ConfigOf<typeof STANDALONE_SECTIONS>

/** The retired private config file; its presence is an error, never a fallback. */
const RETIRED_FILE = '.pr-update.yaml'

/** The environment and working directory the loader resolves `SDLC_CONFIG` against. */
export interface LoadEnv {
  env?: Record<string, string | undefined>
  cwd?: string
}

/** The config handle for a standalone run; `env` and `cwd` decide where `SDLC_CONFIG` points. */
export function standaloneConfig(opts: LoadEnv = {}): ConfigHandle<typeof STANDALONE_SECTIONS> {
  return assembleConfig({
    file: PR_UPDATE_CONFIG_FILE,
    sections: STANDALONE_SECTIONS,
    unknownTopLevel: 'ignore',
    label: 'pr-update config',
    resolve: {
      ...(opts.env !== undefined ? { env: opts.env } : {}),
      ...(opts.cwd !== undefined ? { cwd: opts.cwd } : {}),
    },
  })
}

/**
 * Refuse a project that still carries the retired private config file. There
 * is no fallback and no alias: the keys move under `pr_update:` in `sdlc.yaml`.
 */
export function assertNoRetiredFile(projectRoot: string): void {
  const leftover = join(projectRoot, RETIRED_FILE)
  if (!existsSync(leftover)) return
  throw new ConfigInvalidError(
    [leftover],
    [
      {
        path: '(root)',
        message: `${RETIRED_FILE} is no longer read; move its keys under a \`pr_update:\` block in ${PR_UPDATE_CONFIG_FILE_NAME} and delete the file`,
      },
    ],
    'pr-update config',
  )
}

/**
 * Load the layered config of `projectRoot`: the retired-file check, then the
 * two mounted sections with every default filled. Neither file present is not
 * an error — every key has a default.
 */
export function loadConfigLayers(
  projectRoot: string,
  opts: LoadEnv = {},
): ConfigLayers<StandaloneConfig> {
  assertNoRetiredFile(projectRoot)
  return standaloneConfig(opts).loadLayers(projectRoot)
}
