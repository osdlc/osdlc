/**
 * The project config file a standalone `pr-update` run reads and the variable
 * that relocates it. pr-update shares sdlc's file today, so the values are
 * sdlc's; making them a caller's choice is T-P3SK.
 */

/** The project config file name, looked for at the project root. */
export const PR_UPDATE_CONFIG_FILE_NAME = 'sdlc.yaml'

/** The env variable that points a run at another config file. */
export const PR_UPDATE_CONFIG_ENV = 'SDLC_CONFIG'

/** Both, in the shape `@osdlc/config-layers`'s loader takes. */
export const PR_UPDATE_CONFIG_FILE = {
  name: PR_UPDATE_CONFIG_FILE_NAME,
  envVar: PR_UPDATE_CONFIG_ENV,
} as const
