# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Changed

- Depends on `@osdlc/etag-write` `^0.2.0` from npm instead of `@sksizer/etag-write`.
- **BREAKING:** the standalone `pr-update` binary reads the `pr_update:` and `code_host:` blocks of
  `sdlc.yaml` (layered under `sdlc.local.yaml`, relocatable with `SDLC_CONFIG`) instead of
  `.pr-update.yaml`, through `@sksizer/cli-tool/config`. Other top-level keys are skipped. A
  leftover `.pr-update.yaml` makes `survey`, `update` and `config` exit `14` with a message naming
  `sdlc.yaml` and `pr_update:`; there is no fallback. `loadConfigFile` and `ConfigFileError` are
  removed: `loadConfigLayers` and `standaloneConfig` read through the shared loader, and an unusable
  config is a `ConfigInvalidError` (exit `14`).
- `update` refuses to run a command read from the project file (`lockfile_install`,
  `resolvers[].run`, `repair.command`, `test_command`) without consent and exits `21`.
- Version set to 0.5.0 from the API history, ahead of the first public release.

### Added

- `pr-update config list|get|set|unset|explain|scaffold`, with `pr_update` as the default namespace.
- `pr-update trust`, recording consent for a repository; `--trust` still grants it for one run.
- `prUpdateStandaloneSection`, the `pr_update` section including the standalone-only `test_command`.

### Fixed

- `execute` reads the runner's error where seam stderr is shown.

## [0.2.0] - 2026-10-10

### Changed

- **BREAKING:** the `Forge` port is renamed `CodeHost`
  ([#2472](https://github.com/sksizer/dev/pull/2472)). `survey` lists PRs through the `CodeHost`
  port (`@sksizer/code-host`) instead of `@sksizer/easy-gh`; `SurveyEnv.codeHost` swaps the adapter
  (default GitHub over `gh`) ([#2886](https://github.com/sksizer/dev/pull/2886)).
- CLI and config ergonomics ([#2660](https://github.com/sksizer/dev/pull/2660)); caller-glue
  enhancements from the command-seam, easy-git and easy-gh APIs
  ([#2950](https://github.com/sksizer/dev/pull/2950)).

### Added

- `conflictBaseSha` on a survey row's conflict prediction: the base ref's resolved SHA when
  `merge-tree` measured it, so a caller can tell whether the prediction is still fresh.
- Structured `conflicts: {path, why}[]` alongside `update`'s free-text `detail`.
- `--strategy rebase|merge` on `pr-update update`, overriding the run's default strategy without
  bypassing a per-PR `overrides` rule or the `unpushed_local` guard
  ([#2662](https://github.com/sksizer/dev/pull/2662)).
- Optional `Ports.generators`: in-process rebuild steps, a ladder rung after `resolvers`.
- Optional `Ports.repair` and the `repair: { command, on }` config block: a last-resort repair for
  an unclaimed conflict or failed verify step, called only under `--apply`. The executor rejects a
  repair that moves HEAD, creates refs, or leaves conflict markers or `git diff --check` errors.
  `updated` outcomes gain `repaired: {kind, note}[]`.

## [0.1.0] - 2026-09-27

### Added

- Extracted from sdlc's `lib/services/pr/` ([#2373](https://github.com/sksizer/dev/pull/2373)) so it
  can run standalone: `runSurvey` and `runUpdate` as a library, plus a `pr-update` CLI (`survey` /
  `update`) built on `@sksizer/cli-tool`, with a Forge port (GitHub and Forgejo adapters).
