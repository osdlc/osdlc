# @osdlc/diffkit

Two commands over a pull request or a branch diff, both deterministic with no LLM.
`diffkit stats` is descriptive statistics beyond GitHub's `+N -M`: what kind of lines
changed, what kind of change each file got, what happened to the public API, and where
complexity moved; it writes the result into the PR body, idempotently. `diffkit prep`
is a JSON manifest that readies a change for a reviewer: which files to read, how to
group them by package, and where to look first. It keeps no state.

```sh
diffkit stats 123                 # a PR (needs gh)
diffkit stats --base origin/main  # the current branch (origin/main...HEAD)
diffkit stats --base v1 --head v2 # exactly v1..v2, e.g. what changed since a last review
diffkit stats --worktree          # HEAD against the working tree, untracked files too
diffkit stats 123 --write         # put the table in the PR body
diffkit stats 123 --detail --json # per-file detail / structured output
```

```sh
diffkit prep 123                  # the manifest for a PR, on stdout
diffkit prep --base origin/main     # the current branch, kept and dropped files, groups
```

What is measured is a `Change` (`src/change.ts`): a base and head revision, resolved from
a PR (`resolvePr`: merge-base of the PR's base and head, to the head), a commit pair
(`resolveRange`: exactly `a..b`, two-dot, so a base that has since moved shows), a branch
(`resolveBranch`: `base...HEAD`, merge-base form) or the working tree (`resolveWorktree`:
tracked staged and unstaged edits against HEAD, plus untracked non-ignored files counted as
added; ignored files never). Only the PR resolver uses `gh`. `--write` needs a PR.

Works in any git repository with an authenticated `gh`. No sdlc needed. Inside
sdlc the same pipeline is `sdlc pr stats`, and the task-work skill runs it after
opening a PR.

## Install

```sh
npx @osdlc/diffkit 123            # once published
bun run packages/ts/diffkit/src/cli.ts stats 123   # from a checkout of this monorepo
```

## As a skill

The craft plugin ships `/craft:pr-stats`, which runs a single-file bundle of this
package with plain Node and needs no sdlc: `node <skill-dir>/diffkit.mjs stats …`.
Rebuild it with `bun run bundle` (`bun run bundle:check` fails if it is stale);
then copy it into the four craft pack mirrors the way the mirror flow does.
`typescript` is not bundled; the script finds the measured project's own copy
from the working directory.

## What it reports

One marked block, `<!-- sdlc-diffkit-stats:start -->` to `<!-- sdlc-diffkit-stats:end -->`:

1. **Lines** added / removed / net for Code, Comments, Blank / whitespace, Prose / docs.
2. **File groups**: Source, Tests, Docs, Generated, Other, with files and lines.
3. **Code summary**: a change-category table, dependency changes, public API
   delta, and the top five complexity movers. `--detail` adds the per-file list.

### Classifying a line

Whitespace-only is blank. In `.md .mdx .txt .rst` anything else is prose. In a
source file (the extension table in `src/heuristic.ts`) a line that starts with
a comment opener is a comment. Everything else, including config and data
files, is code.

Generated files (`cli/sdlc.js`, `list-ops.js`, `_generated/`, `packs/`,
lockfiles, `*.min.*`) are counted in the file-group table only, so a regenerated
bundle does not swamp the numbers.

**Limits.** The comment test is a one-line prefix check, a floor and not a
parser: a Rust `#[derive]` reads as a comment, code after a closing `*/` on the
same line counts as comment, lines inside a multi-line string are judged as
code, and `#` comments in yaml/toml count as code. Good to a few percent.

### Change categories

Each file lands in exactly one, first match wins: generated, deleted, added, renamed (with
similarity), dependencies, docs, tests, formatting, config, comments, logic. A new test file is
"added", not "tests". "Formatting" means the removed and added lines pair up one to one, in order,
and differ only in whitespace outside string literals (and, in `.py`, `.yaml`, `.yml`, `.mk` and
`Makefile`, not in leading indentation). A call re-wrapped across lines, a reorder, or changed
whitespace inside a string stays a kept change. "Dependencies" parses `package.json` and
`Cargo.toml` dependency-looking lines (name plus a version-like value), pairing removed and added
lines into added / removed / bumped.

### Public API

Heuristic, by regex over exported declarations (comments stripped), not type-aware. TypeScript:
every changed non-test module, entry points (`index.*`) flagged, reading `export function|class|
interface|type|enum|const|…`, `export { … }` lists and `export * from`. Rust:
`pub` items in changed `.rs` files. A change is a different first line of the
declaration, so a changed type below a wrapped parameter list is missed. When
`typescript` can be found, public members of exported classes and interfaces are
read from the AST as `Class.member` with their full signature.

### Complexity

Cyclomatic (McCabe): 1 plus `if`, loops, non-default `case`, `catch`, `?:`,
`&&`, `||`, `??`; a nested function scores separately. Computed per function on
the base and head versions of each changed file (`git show <rev>:<path>`), so
rows are before / after per function, with added and removed functions counted
as 0 on the missing side. Accurate for TS/JS (real AST); other languages via
`lizard` when it is on PATH, otherwise skipped with a line saying so.

Caps: at most 150 files, 400 KB each, and a 20 s budget for the content passes.
Anything skipped is listed in the report's `notes`, never silently dropped.

## Prep

`diffkit prep [<pr> | --base <ref> [--head <ref>] | --worktree] [--group-size <n>]` prints ONE
JSON manifest (`schema: 1`, the zod `prepManifestSchema`). It makes no model call, creates no
worktree, keeps no state and reads the checkout it runs in; git and `gh` are reached only through
the injected runners. The change is named as for `stats`, so a PR needs `gh` and a head commit
present in the checkout.

| Field | Content |
| --- | --- |
| `change` | The resolved `Change`: kind, label, base and head revisions. |
| `coverage` | Languages the flags cover: `["ts"]`. A language that is not listed has no flags, and that is not the same as clean. |
| `thresholds` | The numbers this run used, so a reader can see how strict it was. |
| `files.kept` | `{path, status, group, category, added, removed}` for each file worth reading; `category` is the diff-content category, so `comments` shows a file is light. |
| `files.dropped` | `{path, reason}`: `lockfile`, `generated` or `formatting-only`. |
| `groups` | `{id, roots, files, lines}`: the kept files grouped for separate reviewers; `roots` lists the package roots a group holds. |
| `flags` | A reading order, below. |
| `notes` | A check that could not run, such as the TypeScript compiler API being absent. |

**Dropped files** reuse the package's own classification, in this order: a lockfile (`bun.lock`,
`package-lock.json`, `Cargo.lock`, …), a generated file (the `stats` rule: bundles, `_generated/`,
`packs/`, `*.min.*`), then the diff-content category `formatting`. That rule is conservative, since
a false "logic" costs a reviewer a glance and a false "formatting" hides a change. Within each block
of changed lines (a run of removed lines and the added lines that replace it, no context between)
the lines must pair one to one in order and differ only in spaces and tabs outside string literals,
except where a space separates two word characters or two operator characters (`a + +b` is not
`a++b`, and a gap between words is compared exactly). A pure move, a `\r` change, a backtick, a
heredoc or triple quote, an unbalanced quote (also a stray apostrophe in a comment) and a
regex-looking `/…/` token all refuse. Leading indentation must match in every file except the brace
languages
(`.ts .tsx .js .jsx .mjs .cjs .json .rs .go .java .kt .c .h .cpp .hpp .cs .swift .css .scss`). The
diff has no context lines, so a whitespace edit in the middle of a multi-line string is caught only
by its look. A file whose changed lines are all comments or blank is kept, with
`category: "comments"`, because comment accuracy is reviewed. Added, deleted and renamed files are
always kept, and so is a reformatted test or doc file, because the categories put those first.

**Groups.** A kept file belongs to its nearest package root: the closest ancestor directory, at the
change's head commit, that holds `package.json`, `Cargo.toml`, `pyproject.toml`, `go.mod`,
`deno.json`, `pom.xml`, `build.gradle(.kts)`, `setup.py`, `Gemfile`, `composer.json`,
`Package.swift`, `mix.exs` or `pubspec.yaml`. A file with none above it is in the repo root group,
`"."`. The markers are read from the head's tree (`git ls-tree -r`), so no checkout is needed; for
`--worktree` the checkout's tracked and untracked files are used, a marker deleted in the working
tree excluded. Everything runs from the repository's top level, wherever `diffkit` was started. A
group of more than `--group-size` files (default 12) is split into even slices that keep its `root`,
in path order: count = ceil(n / limit), size = ceil(n / count), so 13 files become 7+6 and not 12+1.
`--group-size 0` turns splitting off. Ids are `g1`, `g2`, … in root order. Afterwards, consecutive
groups whose combined size stays within the limit are packed into one (`roots` then lists several),
so thirty one-file packages are three reviewers, not thirty. diffkit does not depend on sdlc, so the
splitter (`splitEven` in `src/core/split.ts`) is a copy of `shardFiles` in `agent-dev`; change both
together.

### Flags are a reading order

A flag says where to look first. None is a finding, and a file with no flag has not been
shown to be fine: every check is cheap, deterministic and partial. Each carries
`basis`: `measured` is a count taken from the diff and the syntax tree (the number is
exact, whether it matters is a judgement); `heuristic` is a pattern that is often right
and sometimes not, with its `measurements` giving the evidence to check. The checks cover
TypeScript only and need the `typescript` compiler API (found as for complexity); without
it they are skipped and `notes` says so.

| Kind | Basis | Rule |
| --- | --- | --- |
| `long-function` | measured | A function of at least 90 lines (first to last line) of which more than 50% is added by this change. Nested functions count separately; test files are not considered. Measurements: `lines`, `addedShare`. |
| `test-only-export` | heuristic | A name added to a changed module's exports (declarations, `export { … }` lists; not defaults or `export … from`) whose only importers in the checkout are test files. Importers come from a scan of top-level `import` and `export … from` declarations with relative specifiers; a namespace import counts for every name. Re-exports through an index count as a non-test importer, dynamic `import()`, `require()` and package-name imports are not seen, and an export nobody imports is not flagged. Measurements: `name`, `importers`. |

## Evaluation of existing tools

| Tool | Verdict |
| --- | --- |
| `tokei`, `scc`, `cloc` | Count code / comment / blank per language, but of whole files, not diffs. Getting diff numbers means running them over a before and an after tree and subtracting, which loses which lines moved, needs a checkout of both sides, and adds a hard binary dependency. None were installed on the development machine. Not used. Their per-language comment syntax is richer than our prefix table; adopting it is the upgrade path if the floor proves too coarse. |
| `cloc --diff` | Closest in spirit (compares two trees) but a Perl dependency and whole-tree cost for a per-PR number. Not used. |
| `lizard` | Multi-language cyclomatic complexity with CSV output. Used as an OPTIONAL analyzer for non-TS languages; absent, those files are skipped with a note. |
| `typescript` (compiler API) | Already in every TS repo; gives an exact AST for TS/JS complexity with no new dependency. Used, as an optional peer. |
| `ts-morph`, `typhonjs-escomplex`, oxlint/eslint `complexity` rule | Heavier wrappers over the same AST, or rule output that reports only violations over a threshold, not a per-function number. Not used. |
| `rust-code-analysis` | Accurate for Rust but a separate crate to build and run. Not used; `lizard` covers Rust coarsely. |
| `scc` complexity column | A per-file keyword-count estimate, not per function. Not used. |

Decision: the line and category passes use only the diff, so they are fast,
dependency-free and work offline; the content passes (API, complexity) read
base and head files through git and degrade to a "skipped" line when an
analyzer is missing.

## Library

```ts
import { runStats } from '@osdlc/diffkit'
import { spawnRunner } from '@osdlc/command-seam'

const { report, markdown } = runStats(
  { cwd: process.cwd(), pr: 123, base: null, write: false, detail: false },
  { git: spawnRunner('git'), gh: spawnRunner('gh') },
)
```

`runPrep(args, { git, gh })` returns the prep manifest; `prepManifestSchema` validates it.
`buildReport(source, diff, ports)` is the pure core (the `ports` supply file
content by revision; pass `null` to skip the API and complexity passes);
`renderReport` and `spliceBody` render and splice. `reportSchema` is the zod
schema of the structured output (`--json`).

Body splice: a body holding a marked block gets it replaced in place; otherwise
a `## Change statistics` section goes before a trailing `<!-- sdlc-lease: … -->`
footer, which stays the last line byte for byte; otherwise it is appended.
