# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Renamed from `@sksizer/pr-stats` (0.1.0, [#2911](https://github.com/sksizer/dev/pull/2911)).
There is no alias for the old package name, binary or PR-body markers (pre-1.0 hard cutover).

### Added

- `diffkit prep [<pr>|--base <ref> [--head <ref>]|--worktree] [--group-size <n>]`: one JSON
  manifest (`prepManifestSchema`, `schema: 1`) that tells a reviewer what to read. `files.kept`
  and `files.dropped` (lockfile, generated, formatting-only; comment-only files are kept, tagged
  `category: comments`), `groups` of kept files by nearest package root, and two TypeScript
  reading-order flags, `long-function` and `test-only-export`, each with its `basis`. The manifest
  is stateless: review state and deltas live in the review skills, not here.
- Groups follow the nearest ancestor directory, at the change's head commit, holding
  `package.json`, `Cargo.toml`, `pyproject.toml`, `go.mod`, `deno.json`, `pom.xml` or
  `build.gradle(.kts)`; a file with none goes to the repo root group (`.`). Markers are read with
  `git ls-tree` on the head, so no checkout is needed. A group over `--group-size` files
  (default 12) splits evenly in path order. Library: `runPrep`, `buildGroups`, `packageRoots`,
  `nearestRoot`, `splitEven`.
- `Change` and the resolvers `resolvePr`, `resolveRange` (exact `a..b`), `resolveBranch`
  (`base...HEAD`) and `resolveWorktree` (HEAD against the working tree, untracked files as
  added), plus `readDiff` / `prDiff`. `diffkit stats` takes `<pr>`, `--base <ref> [--head <ref>]`
  or `--worktree`; `--head` makes the pair exact.

### Changed

- Renamed from `@sksizer/pr-stats`. The single `diffkit` binary takes `stats` and `prep`
  subcommands (was the `pr-stats` binary). The bundled script is `diffkit.mjs`. Source is split
  into `src/core/` (pure), `src/stats/` and `src/prep/`.
- The PR-body markers are now `<!-- sdlc-diffkit-stats:start -->` and
  `<!-- sdlc-diffkit-stats:end -->`; a body carrying the old markers gets a second section on the
  next `--write`; delete the old one by hand.
- A PR's base is the commit GitHub reports (`baseRefOid`), not `origin/<branch>`; the default
  branch falls back to `origin/HEAD` when there is no `origin/main`; a fork head missing locally
  says to run `gh pr checkout <n>`; `--group-size` takes digits only.
- `prep` and `stats` run every git call and file read from the repository's top level, so a
  subdirectory start gives the same paths and package roots; a marker deleted in the working tree
  is not a root; more markers (`setup.py`, `Gemfile`, `composer.json`, `Package.swift`,
  `mix.exs`, `pubspec.yaml`); small groups are packed to `--group-size` and `groups[].roots` is a
  list; a TypeScript without the JS compiler API (7, native) is skipped and a failure while
  computing flags becomes a `notes` entry.
- The `formatting` category is conservative: it pairs lines within each change block, refuses
  a pure move, backticks, regex-looking tokens, unbalanced quotes, heredocs, `\r` changes and
  fused tokens (`a + +b`), and compares indentation in every language outside a brace-language
  allow-list. Re-wrapped calls and reorders are not dropped from `prep` as formatting-only.
- Diff header paths are read correctly for names git C-quotes (spaces, quotes, non-ASCII bytes).

([#3089](https://github.com/sksizer/dev/pull/3089))

## [0.1.0] - 2026-10-09 (as `@sksizer/pr-stats`)

Initial cut ([#2911](https://github.com/sksizer/dev/pull/2911)).

### Added

- Line statistics by code / comments / blank / prose and by file group, with
  generated files counted apart.
- Change categories per file, dependency-manifest changes, public API delta
  (TS entry points, Rust `pub` items) and a cyclomatic-complexity movers table.
- `pr-stats [<pr>|--base <ref>] [--write] [--detail] [--json]`, and
  `runStats` / `buildReport` / `renderReport` / `spliceBody` as a library.
- `scripts/bundle.ts` (`bun run bundle`, `bundle:check`): a single-file `pr-stats.mjs`
  for plain Node, shipped in the craft plugin's `pr-stats` skill.
- Exported-API delta now reads every changed TS module (entry points flagged), and the
  public members of exported classes and interfaces when `typescript` is found.

### Changed

- Unnamed functions are named after their nearest named enclosing scope plus an ordinal,
  and unmatched ones are shown only under `--detail`.
