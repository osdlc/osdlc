/**
 * A `Change` is a resolved pair of revisions: the thing every diffkit command
 * measures. The resolvers turn the four ways a person names a change (a PR, a
 * commit pair, a branch, the working tree) into one shape, so a command never
 * cares which it was given. Only {@link resolvePr} touches `gh`; everything
 * else is git. All access goes through the typed-git / typed-gh clients over
 * injectable runners.
 */

import { Gh } from '@osdlc/typed-gh'
import { CommandFailed, type CommandRunner } from '@osdlc/command-seam'
import { Git } from '@osdlc/typed-git'

import { DiffkitError } from './error.ts'

/** A change that could not be selected or read; `usage` is set for a contradictory selector. */
export class ChangeError extends DiffkitError {}

export interface Change {
  kind: 'pr' | 'range' | 'branch' | 'worktree'
  /** What the change is called in output: `PR #7`, `a..b`, `base...HEAD`. */
  label: string
  /** The "before" side, as a revision git can resolve. */
  baseRev: string
  /** The "after" side; null is the working tree. */
  headRev: string | null
  pr?: { number: number }
}

/**
 * The repository's top-level directory for `cwd` (cwd itself outside a
 * repository). Every git call and file read of a pipeline runs from here, so a
 * command started in a subdirectory sees the same root-relative paths git
 * prints in a diff.
 */
export function repoRoot(cwd: string, runner: CommandRunner): string {
  return guard(() => new Git(cwd, { runner }).topLevel()) || cwd
}

export interface ChangeEnv {
  cwd: string
  git: CommandRunner
  /** Only read by {@link resolvePr} and {@link prDiff}. */
  gh: CommandRunner
}

/**
 * A PR: the merge-base of the PR's base branch and its head, to the head, the
 * same span GitHub shows. Throws when the head commit is not in this
 * checkout, since a revision pair cannot name it; {@link prDiff} alone can
 * read such a PR's diff, from GitHub, without a `Change`.
 */
export function resolvePr(n: number, env: ChangeEnv): Change {
  const git = new Git(env.cwd, { runner: env.git })
  const gh = new Gh(env.cwd, { runner: env.gh })
  const view = guard(() =>
    parseOids(gh.rawChecked(['pr', 'view', String(n), '--json', 'baseRefOid,headRefOid']).stdout),
  )
  if (view === null) throw new ChangeError(`could not read PR #${n}`)
  const head = view.headRefOid
  if (!git.objectExists(head)) {
    throw new ChangeError(
      `PR #${n} head ${head.slice(0, 12)} is not in this checkout; run \`gh pr checkout ${n}\` or \`git fetch origin pull/${n}/head\``,
    )
  }
  // The base commit GitHub reports, whatever the remote is called; it may need a fetch.
  if (!git.objectExists(view.baseRefOid)) {
    throw new ChangeError(
      `PR #${n} base ${view.baseRefOid.slice(0, 12)} is not in this checkout; fetch its base branch`,
    )
  }
  const base = guard(() => git.mergeBase(view.baseRefOid, head))
  if (base === null) throw new ChangeError(`PR #${n} has no merge base with its base branch`)
  return { kind: 'pr', label: `PR #${n}`, baseRev: base, headRev: head, pr: { number: n } }
}

function parseOids(text: string): { baseRefOid: string; headRefOid: string } | null {
  try {
    const raw = JSON.parse(text) as Record<string, unknown>
    const { baseRefOid, headRefOid } = raw
    if (typeof baseRefOid !== 'string' || typeof headRefOid !== 'string') return null
    if (baseRefOid === '' || headRefOid === '') return null
    return { baseRefOid, headRefOid }
  } catch {
    return null
  }
}

/**
 * Exactly `a..b` (two-dot): `a` is the base itself, not its merge-base with
 * `b`. After the base branch advances, `a..b` still includes the base's new
 * commits as reversals, which is what a "what changed since I last looked"
 * delta needs and `a...b` would hide.
 */
export function resolveRange(a: string, b: string, env: ChangeEnv): Change {
  const git = new Git(env.cwd, { runner: env.git })
  return {
    kind: 'range',
    label: `${a}..${b}`,
    baseRev: verified(git, a),
    headRev: verified(git, b),
  }
}

/**
 * The current branch against `base` (default origin/main, else the remote's
 * default branch, origin/HEAD) in the merge-base form, `base...HEAD`: only what this branch added, whatever the base did since.
 */
export function resolveBranch(base: string | null, env: ChangeEnv): Change {
  const git = new Git(env.cwd, { runner: env.git })
  const ref =
    base ?? (guard(() => git.resolveRef('origin/main')) !== null ? 'origin/main' : 'origin/HEAD')
  const mergeBase = guard(() => git.mergeBase(ref, 'HEAD'))
  if (mergeBase === null) throw new ChangeError(`no merge base between ${ref} and HEAD`)
  return { kind: 'branch', label: `${ref}...HEAD`, baseRev: mergeBase, headRev: 'HEAD' }
}

/**
 * HEAD against the working tree: tracked files' staged and unstaged edits
 * (what `git diff HEAD` shows) plus untracked, non-ignored files, which
 * {@link readDiff} renders as wholly added. Ignored files are never part of it.
 */
export function resolveWorktree(env: ChangeEnv): Change {
  const git = new Git(env.cwd, { runner: env.git })
  return {
    kind: 'worktree',
    label: 'HEAD...worktree',
    baseRev: verified(git, 'HEAD'),
    headRev: null,
  }
}

/** How a person names a change on the command line; the fields are exclusive but `head` needs `base`. */
export interface ChangeSelector {
  pr: number | null
  base: string | null
  head: string | null
  worktree: boolean
}

/** Throws a usage {@link ChangeError} when the selector contradicts itself. */
export function validateSelector(sel: ChangeSelector): void {
  const named = [sel.pr !== null, sel.base !== null || sel.head !== null, sel.worktree]
  if (named.filter(Boolean).length > 1) {
    throw new ChangeError('a PR, --base/--head and --worktree are mutually exclusive', true)
  }
  if (sel.head !== null && sel.base === null) throw new ChangeError('--head needs --base', true)
}

/**
 * The {@link Change} a selector names: a PR, `base` and `head` (exactly
 * `base..head`), `base` alone (the branch), the working tree, or with nothing
 * named the branch against origin/main. Contradictory selectors throw.
 */
export function selectChange(sel: ChangeSelector, env: ChangeEnv): Change {
  validateSelector(sel)
  if (sel.pr !== null) return resolvePr(sel.pr, env)
  if (sel.worktree) return resolveWorktree(env)
  if (sel.head !== null) return resolveRange(sel.base!, sel.head, env)
  return resolveBranch(sel.base, env)
}

/** `gh pr diff` for a PR, the diff GitHub itself shows (works without a local head). */
export function prDiff(n: number, env: ChangeEnv): string {
  const gh = new Gh(env.cwd, { runner: env.gh })
  return guard(() => gh.prDiff(n))
}

/**
 * The unified diff of a change: GitHub's own (`gh pr diff`, default context) for
 * a PR, otherwise `git diff -U0` (no context lines).
 */
export function readDiff(change: Change, env: ChangeEnv): string {
  if (change.pr !== undefined) return prDiff(change.pr.number, env)
  const git = new Git(env.cwd, { runner: env.git })
  // Fixed prefixes, so a user's `diff.noprefix` or `diff.mnemonicPrefix` cannot change the paths `parseDiff` reads.
  const argv = [
    'diff',
    '-U0',
    '--no-color',
    '--no-ext-diff',
    '--src-prefix=a/',
    '--dst-prefix=b/',
    change.baseRev,
  ]
  if (change.headRev !== null) argv.push(change.headRev)
  return guard(() => {
    let text = git.rawChecked(argv).stdout
    if (change.headRev === null) {
      const untracked = git.lsFiles({ others: true, excludeStandard: true })
      for (const path of untracked) text += addedFileDiff(env, path)
    }
    return text
  })
}

/**
 * An untracked file as a diff of an added file. The prefixes are pinned like
 * `readDiff`'s (`--no-index` honours `diff.noprefix`); exit 1 is its success.
 */
function addedFileDiff(env: ChangeEnv, path: string): string {
  const r = env.git.run(
    [
      'diff',
      '--no-index',
      '--no-color',
      '--src-prefix=a/',
      '--dst-prefix=b/',
      '--',
      '/dev/null',
      path,
    ],
    { cwd: env.cwd },
  )
  return r.exitCode === 1 ? r.stdout : ''
}

/** The sha `rev` names, or a ChangeError saying which revision is bad. */
function verified(git: Git, rev: string): string {
  const sha = guard(() => git.resolveRef(`${rev}^{commit}`))
  if (sha === null) throw new ChangeError(`unknown revision '${rev}'`)
  return sha
}

function guard<T>(fn: () => T): T {
  try {
    return fn()
  } catch (e) {
    if (!(e instanceof CommandFailed)) throw e
    throw new ChangeError(`could not read the diff: ${e.detail.trim().split('\n')[0]}`)
  }
}
