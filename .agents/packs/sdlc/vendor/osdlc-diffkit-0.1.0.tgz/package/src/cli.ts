/**
 * `diffkit <subcommand> …` — the one standalone binary. Works in any git
 * repository; `stats` also needs `gh` authenticated. No sdlc.
 *
 * Subcommands: `stats` (see ./stats/command.ts) and `prep` (./prep/command.ts),
 * the `SUBCOMMANDS` table below, each one a `(argv, ctx) => exit code` function.
 *
 * Exit codes: 0 on success, 1 on a runtime failure, 2 on a malformed command
 * line (the subcommand's own codes pass through).
 */

import { EXIT, runMain, type CliContext } from '@osdlc/cli-tool'

import { prepMain } from './prep/command.ts'
import { statsMain } from './stats/command.ts'

const SUBCOMMANDS: Record<
  string,
  { summary: string; run: (argv: readonly string[], ctx: CliContext) => Promise<number> }
> = {
  stats: {
    summary: 'Line, category, API and complexity statistics for a PR or branch diff.',
    run: statsMain,
  },
  prep: {
    summary: 'A JSON manifest of a change for review: files, groups, flags.',
    run: prepMain,
  },
}

function usage(): string {
  const rows = Object.entries(SUBCOMMANDS).map(([n, c]) => `  ${n.padEnd(8)}${c.summary}`)
  return `Usage: diffkit <command> [options]\n\nCommands:\n${rows.join('\n')}\n\nRun \`diffkit <command> --help\` for a command's options.\n`
}

export async function main(argv: readonly string[], ctx: CliContext): Promise<number> {
  const { io } = ctx
  const [name, ...rest] = argv
  if (name === undefined || name === '--help' || name === '-h') {
    io.stdout(usage())
    return name === undefined ? EXIT.usage : EXIT.ok
  }
  const sub = SUBCOMMANDS[name]
  if (sub === undefined) {
    io.stderr(`diffkit: unknown command '${name}'\n${usage()}`)
    return EXIT.usage
  }
  return sub.run(rest, ctx)
}

// Inert when imported; the published `bin/` shim calls `main` through `runMain`.
if (import.meta.main) {
  await runMain(main, { name: 'diffkit' })
}
