/**
 * Which changed files deserve a reviewer's attention, and which can be set
 * aside with a stated reason. Built on the package's own classification: a
 * path test (`isLockfile`, `isGenerated`) and the diff-content category
 * (`categorize`), so `prep` and `stats` agree on what a generated file or a
 * formatting-only change is.
 */

import { categorize } from '../core/categories.ts'
import type { FileDiff } from '../core/diff.ts'
import { fileGroup, isGenerated, isLockfile } from '../core/lines.ts'
import type { PrepManifest } from './schema.ts'

type Dropped = PrepManifest['files']['dropped'][number]['reason']

/**
 * Why a file is not worth reading, or null when it is. Checked in this order:
 * lockfile, generated, then the content categories, so a file lands in the
 * first reason that applies. A reformatted TEST or DOC file is kept: the
 * category order puts docs and tests ahead of formatting. A comment-only source
 * file is kept too, with `category: 'comments'`: comment accuracy is reviewed.
 */
export function dropReason(f: FileDiff): Dropped | null {
  if (isLockfile(f.path)) return 'lockfile'
  if (isGenerated(f.path)) return 'generated'
  return categorize(f) === 'formatting' ? 'formatting-only' : null
}

export function splitFiles(files: readonly FileDiff[]): PrepManifest['files'] {
  const kept: PrepManifest['files']['kept'] = []
  const dropped: PrepManifest['files']['dropped'] = []
  for (const f of files) {
    const reason = dropReason(f)
    if (reason !== null) dropped.push({ path: f.path, reason })
    else {
      kept.push({
        path: f.path,
        status: f.status,
        group: fileGroup(f.path),
        category: categorize(f),
        added: f.added.length,
        removed: f.removed.length,
      })
    }
  }
  kept.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
  dropped.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
  return { kept, dropped }
}
