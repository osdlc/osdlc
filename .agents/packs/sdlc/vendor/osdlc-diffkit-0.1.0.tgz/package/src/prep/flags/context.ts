import type { TsModule } from '../../core/ts-loader.ts'
import type { Checkout } from '../checkout.ts'
import type { PrepFlag, Thresholds } from '../schema.ts'

/** What every flag check reads. `files` are the kept TypeScript files of the change, deleted ones left out. */
export interface FlagContext {
  ts: TsModule
  thresholds: Thresholds
  checkout: Checkout
  files: readonly ChangedFile[]
  /** A changed file's text at the head revision; null when it cannot be read. */
  readHead(path: string): string | null
}

export interface ChangedFile {
  path: string
  /** New-file line numbers added by this change. */
  added: ReadonlySet<number>
}

/** A flag before its group is known; the orchestrator fills `group` in. */
export type RawFlag = Omit<PrepFlag, 'group'>
