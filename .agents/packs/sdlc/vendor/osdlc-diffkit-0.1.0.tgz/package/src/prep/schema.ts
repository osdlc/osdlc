/**
 * The `diffkit prep` manifest: one JSON document describing a change for a
 * reviewer, deterministic and free of any model. `schema` is the version of
 * this shape; a consumer should refuse a number it does not know.
 */

import { z } from 'zod'

import { CATEGORIES, FILE_GROUPS } from '../core/types.ts'

export const DROP_REASONS = ['generated', 'lockfile', 'formatting-only'] as const
export const FLAG_KINDS = ['long-function', 'test-only-export'] as const

const changeSchema = z.object({
  kind: z.enum(['pr', 'range', 'branch', 'worktree']),
  label: z.string(),
  baseRev: z.string(),
  headRev: z.string().nullable().describe('Null is the working tree.'),
  pr: z.object({ number: z.number() }).optional(),
})

/** What a flag was measured against; recorded so a reader can see how strict the run was. */
export const thresholdsSchema = z.object({
  longFunctionLines: z.number().describe('A function this long or longer can be flagged.'),
  longFunctionAddedShare: z
    .number()
    .describe('...when MORE than this share of its lines is added in this change.'),
  groupSize: z.number().describe('Files per group before a package group is split; 0 is off.'),
})

export const prepManifestSchema = z.object({
  schema: z.literal(1),
  change: changeSchema,
  coverage: z
    .array(z.literal('ts'))
    .describe('Languages the flags cover. A language not listed has no flags, which is not clean.'),
  thresholds: thresholdsSchema,
  files: z.object({
    kept: z.array(
      z.object({
        path: z.string(),
        status: z.enum(['added', 'deleted', 'modified', 'renamed']),
        group: z.enum(FILE_GROUPS),
        category: z
          .enum(CATEGORIES)
          .describe(
            'The diff-content category; `comments` marks a file whose change is only comments.',
          ),
        added: z.number(),
        removed: z.number(),
      }),
    ),
    dropped: z.array(z.object({ path: z.string(), reason: z.enum(DROP_REASONS) })),
  }),
  groups: z.array(
    z.object({
      id: z.string(),
      roots: z
        .array(z.string())
        .describe(
          'The package roots this group holds (a directory with a manifest file; `.` is the repo root). One entry unless small groups were packed together.',
        ),
      files: z.array(z.string()),
      lines: z.number().describe('Added plus removed lines across the group.'),
    }),
  ),
  flags: z.array(
    z.object({
      kind: z.enum(FLAG_KINDS),
      basis: z.enum(['measured', 'heuristic']),
      path: z.string(),
      line: z.number(),
      group: z.string(),
      detail: z.string(),
      measurements: z.record(z.string(), z.json()),
    }),
  ),
  notes: z.array(z.string()).describe('Any check that could not run, and why.'),
})

export type PrepManifest = z.infer<typeof prepManifestSchema>
export type Thresholds = z.infer<typeof thresholdsSchema>
export type PrepFlag = PrepManifest['flags'][number]
export type PrepFile = PrepManifest['files']['kept'][number]
export type PrepGroup = PrepManifest['groups'][number]
