/**
 * `prep`'s pipeline: resolve the change, read its diff, split the files, group
 * them by package root, raise the flags. The repository's top level (found
 * from the working directory) is the checkout; git and gh are reached only
 * through the injected runners.
 */

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { CommandFailed, type CommandRunner } from '@osdlc/command-seam'
import { Git } from '@osdlc/typed-git'

import { ChangeError, readDiff, repoRoot, selectChange } from '../change.ts'
import { parseDiff } from '../core/diff.ts'
import { DiffkitError } from '../error.ts'
import { Checkout } from './checkout.ts'
import { splitFiles } from './files.ts'
import { raiseFlags } from './flags/index.ts'
import { buildGroups, packageRoots } from './groups.ts'
import { prepManifestSchema, type PrepManifest, type Thresholds } from './schema.ts'

/** A failure `runPrep` raises for the caller to show as a message. */
export class PrepError extends DiffkitError {}

/** Files per group before a package group is split; matches sdlc's `verify.max_files_per_job`. */
export const DEFAULT_GROUP_SIZE = 12

export const DEFAULT_THRESHOLDS: Thresholds = {
  longFunctionLines: 90,
  longFunctionAddedShare: 0.5,
  groupSize: DEFAULT_GROUP_SIZE,
}

export interface PrepArgs {
  cwd: string
  /** What to prep: as in {@link selectChange}. */
  pr: number | null
  base: string | null
  head?: string | null
  worktree?: boolean
  /** Overrides for {@link DEFAULT_THRESHOLDS}. */
  thresholds?: Partial<Thresholds>
}

export interface PrepEnv {
  git: CommandRunner
  gh: CommandRunner
}

export function runPrep(args: PrepArgs, env: PrepEnv): PrepManifest {
  const thresholds: Thresholds = { ...DEFAULT_THRESHOLDS, ...args.thresholds }
  let manifest: PrepManifest
  try {
    // Resolved once: every git call and file read runs from the top level, so a
    // subdirectory start sees the root-relative paths the diff prints.
    const cwd = repoRoot(args.cwd, env.git)
    const cenv = { cwd, git: env.git, gh: env.gh }
    const change = selectChange(
      { pr: args.pr, base: args.base, head: args.head ?? null, worktree: args.worktree === true },
      cenv,
    )
    const diff = parseDiff(readDiff(change, cenv))
    const files = splitFiles(diff)
    const git = new Git(cwd, { runner: env.git })
    const checkout = new Checkout(cwd, env.git)
    // Markers are read from the head's tree, no checkout needed; the working tree has no rev.
    const headPaths =
      change.headRev === null
        ? checkout.files.filter((p) => existsSync(join(cwd, p)))
        : git.lsTree(change.headRev, { recursive: true }).map((e) => e.path)
    const groups = buildGroups(files.kept, packageRoots(headPaths), thresholds.groupSize)
    const { flags, notes } = raiseFlags({
      thresholds,
      checkout,
      kept: files.kept,
      addedAt: new Map(diff.map((f) => [f.path, f.addedAt])),
      groupOf: new Map(groups.flatMap((s) => s.files.map((p) => [p, s.id] as const))),
      readHead: (path) => {
        if (change.headRev !== null) return git.showAtRev(change.headRev, path)
        try {
          return readFileSync(join(cwd, path), 'utf8')
        } catch {
          return null
        }
      },
    })
    manifest = {
      schema: 1,
      change,
      coverage: ['ts'],
      thresholds,
      files,
      groups,
      flags,
      notes,
    }
  } catch (e) {
    if (e instanceof CommandFailed) {
      throw new PrepError(`could not read the repository: ${e.detail.trim().split('\n')[0]}`)
    }
    if (!(e instanceof ChangeError)) throw e
    throw new PrepError(e.message, e.usage)
  }
  return prepManifestSchema.parse(manifest)
}
