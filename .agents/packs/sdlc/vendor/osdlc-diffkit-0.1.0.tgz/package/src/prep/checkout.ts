/**
 * The checkout as the flags see it: the paths git knows about, and their
 * contents read from disk once. The working directory is the checkout, so a
 * flag about a PR is only as good as the checkout being at (or near) its head;
 * the changed files themselves are always read at the head revision.
 */

import { readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { type CommandRunner } from '@osdlc/command-seam'
import { Git } from '@osdlc/typed-git'

import { isGenerated, isTest } from '../core/lines.ts'

/** Files larger than this are not parsed: a bundle or a data dump is not worth the time. */
const MAX_BYTES = 400_000

const TS_FILE = /\.(?:ts|tsx|mts|cts)$/
const VENDORED = /(^|\/)(node_modules|vendor|vendored|third_party|dist|fixtures)\//

/** A TypeScript source file (`.d.ts` excluded). */
export function isTsFile(path: string): boolean {
  return TS_FILE.test(path) && !path.endsWith('.d.ts')
}

/** A TS file the structure checks should read: not a test, generated or vendored file. */
export function isFirstPartyTs(path: string): boolean {
  return isTsFile(path) && !isTest(path) && !isGenerated(path) && !VENDORED.test(path)
}

export class Checkout {
  private listed: readonly string[] | undefined
  private readonly cache = new Map<string, string | null>()

  constructor(
    readonly cwd: string,
    private readonly runner: CommandRunner,
  ) {}

  /**
   * Tracked paths plus untracked, non-ignored ones: what a reader of the tree
   * can open. Listed on first use, so a change with no TypeScript never pays.
   */
  get files(): readonly string[] {
    if (this.listed === undefined) {
      const git = new Git(this.cwd, { runner: this.runner })
      this.listed = [
        ...new Set(git.lsFiles({ cached: true, others: true, excludeStandard: true })),
      ].sort()
    }
    return this.listed
  }

  /** The file's text, or null when it is missing, unreadable or too large. */
  read(path: string): string | null {
    if (this.cache.has(path)) return this.cache.get(path)!
    let text: string | null = null
    try {
      const full = join(this.cwd, path)
      if (statSync(full).size <= MAX_BYTES) text = readFileSync(full, 'utf8')
    } catch {
      // deleted in the working tree, or not a regular file
    }
    this.cache.set(path, text)
    return text
  }
}
