/**
 * The flags: a reading order for a reviewer, not findings. Each check is
 * cheap and deterministic and says where to look first; none of them proves
 * anything by being silent. `basis: measured` is a count taken from the diff
 * and the syntax tree; `heuristic` is a pattern that is often right and
 * sometimes not, with the limits written in its own module.
 *
 * Only TypeScript is covered (`coverage: ['ts']` in the manifest). The checks
 * need the `typescript` compiler API; when none can be found they are skipped
 * and the manifest says so in `notes`.
 */

import { loadTs } from '../../core/ts-loader.ts'
import { isTsFile, type Checkout } from '../checkout.ts'
import type { PrepFile, PrepFlag, Thresholds } from '../schema.ts'
import type { ChangedFile, FlagContext } from './context.ts'
import { longFunctions } from './long-function.ts'
import { testOnlyExports } from './test-only-export.ts'

export interface FlagInput {
  thresholds: Thresholds
  checkout: Checkout
  kept: readonly PrepFile[]
  /** New-file line numbers this change added, per path. */
  addedAt: ReadonlyMap<string, readonly number[]>
  groupOf: ReadonlyMap<string, string>
  readHead(path: string): string | null
}

export function raiseFlags(input: FlagInput): { flags: PrepFlag[]; notes: string[] } {
  try {
    return raise(input)
  } catch (e) {
    // A reading aid must never stop the manifest: say what failed and go on.
    return { flags: [], notes: [`the flags could not be computed: ${(e as Error).message}`] }
  }
}

function raise(input: FlagInput): { flags: PrepFlag[]; notes: string[] } {
  const ts = loadTs()
  if (ts === null) {
    return {
      flags: [],
      notes: ['the typescript compiler API was not found, so no flag could be computed'],
    }
  }
  const files: ChangedFile[] = input.kept
    .filter((f) => f.status !== 'deleted' && isTsFile(f.path))
    .map((f) => ({ path: f.path, added: new Set(input.addedAt.get(f.path) ?? []) }))
  const cx: FlagContext = {
    ts,
    thresholds: input.thresholds,
    checkout: input.checkout,
    files,
    readHead: input.readHead,
  }
  const flags = [...longFunctions(cx), ...testOnlyExports(cx)].map((f): PrepFlag => ({
    ...f,
    group: input.groupOf.get(f.path) ?? '',
  }))
  flags.sort(
    (a, b) =>
      (a.path < b.path ? -1 : a.path > b.path ? 1 : 0) ||
      a.line - b.line ||
      (a.kind < b.kind ? -1 : 1),
  )
  return { flags, notes: [] }
}
