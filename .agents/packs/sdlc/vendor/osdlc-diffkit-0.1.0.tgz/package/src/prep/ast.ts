/** Shared TypeScript AST reading for the flags. */

import { extname } from 'node:path'

import type { TsModule } from '../core/ts-loader.ts'

type Ts = typeof import('typescript')
export type Node = import('typescript').Node
export type SourceFile = import('typescript').SourceFile

export function parse(ts: TsModule, path: string, text: string): SourceFile {
  const kind = extname(path) === '.tsx' ? ts.ScriptKind.TSX : ts.ScriptKind.TS
  return ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true, kind)
}

/** 1-based line of a character offset. */
export function lineAt(sf: SourceFile, pos: number): number {
  return sf.getLineAndCharacterOfPosition(pos).line + 1
}

export interface FnInfo {
  /** The declared or assigned name; `(anonymous)` for a callback. */
  name: string
  /** First and last line, the first being the keyword or modifier, not a leading comment. */
  start: number
  end: number
  /** A function declaration, or a function value assigned straight to a top-level `const`. */
  moduleLevel: boolean
  /** The syntax node, for callers that compare bodies. */
  node: Node
}

/**
 * Every function-like node in the file, nested ones included: declarations,
 * function and arrow expressions, methods, constructors and accessors that
 * have a body.
 */
export function functionsOf(ts: Ts, sf: SourceFile): FnInfo[] {
  const out: FnInfo[] = []
  const visit = (node: Node): void => {
    const info = describe(ts, sf, node)
    if (info !== null) out.push(info)
    ts.forEachChild(node, visit)
  }
  visit(sf)
  return out
}

function describe(ts: Ts, sf: SourceFile, node: Node): FnInfo | null {
  let name: string | null = null
  let moduleLevel = false
  if (ts.isFunctionDeclaration(node)) {
    if (node.body === undefined) return null
    name = node.name?.text ?? 'default'
    moduleLevel = ts.isSourceFile(node.parent)
  } else if (ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)) {
    if (node.body === undefined) return null
    name = ts.isConstructorDeclaration(node) ? 'constructor' : propertyName(ts, node.name)
  } else if (ts.isGetAccessorDeclaration(node) || ts.isSetAccessorDeclaration(node)) {
    if (node.body === undefined) return null
    name = propertyName(ts, node.name)
  } else if (ts.isFunctionExpression(node) || ts.isArrowFunction(node)) {
    const p = node.parent
    if (ts.isVariableDeclaration(p) && ts.isIdentifier(p.name)) {
      name = p.name.text
      // declaration -> list -> statement -> file
      moduleLevel = ts.isSourceFile(p.parent.parent.parent)
    } else if (ts.isPropertyAssignment(p)) name = propertyName(ts, p.name)
    else if (ts.isFunctionExpression(node) && node.name !== undefined) name = node.name.text
  } else return null
  return {
    name: name ?? '(anonymous)',
    start: lineAt(sf, node.getStart(sf)),
    end: lineAt(sf, node.getEnd()),
    moduleLevel,
    node,
  }
}

/**
 * The leaf tokens of `node` in source order, each reduced to its kind:
 * identifiers become `id`, string/number/regex/template pieces `lit`, every
 * keyword and punctuation mark keeps its own name. Comments are dropped. Two
 * bodies with the same shape give the same sequence however their names and
 * constants differ.
 */
export function tokenKinds(ts: Ts, sf: SourceFile, node: Node): string[] {
  const out: string[] = []
  const visit = (n: Node): void => {
    if (n.kind >= ts.SyntaxKind.FirstJSDocNode && n.kind <= ts.SyntaxKind.LastJSDocNode) return
    const kids = n.getChildren(sf)
    if (kids.length > 0) {
      for (const k of kids) visit(k)
      return
    }
    switch (n.kind) {
      case ts.SyntaxKind.Identifier:
      case ts.SyntaxKind.PrivateIdentifier:
        out.push('id')
        return
      case ts.SyntaxKind.StringLiteral:
      case ts.SyntaxKind.NumericLiteral:
      case ts.SyntaxKind.BigIntLiteral:
      case ts.SyntaxKind.RegularExpressionLiteral:
      case ts.SyntaxKind.NoSubstitutionTemplateLiteral:
      case ts.SyntaxKind.TemplateHead:
      case ts.SyntaxKind.TemplateMiddle:
      case ts.SyntaxKind.TemplateTail:
        out.push('lit')
        return
      default:
        out.push(ts.SyntaxKind[n.kind] ?? String(n.kind))
    }
  }
  visit(node)
  return out
}

function propertyName(ts: Ts, n: import('typescript').PropertyName): string | null {
  return ts.isIdentifier(n) || ts.isStringLiteral(n) || ts.isPrivateIdentifier(n) ? n.text : null
}

/** True when `node` carries the modifier `kind`. */
export function hasModifier(ts: Ts, node: Node, kind: import('typescript').SyntaxKind): boolean {
  return ts.canHaveModifiers(node) && (ts.getModifiers(node) ?? []).some((m) => m.kind === kind)
}
