/**
 * `diffkit prep [<pr>|--base <ref> [--head <ref>]|--worktree] [--group-size <n>]` — prints one JSON manifest for a
 * reviewer on stdout. Works in any git repository; the checkout is the cwd.
 *
 * Exit codes: 0 on success, 1 when the change could not be read, 2 on a
 * malformed command line.
 */

import { EXIT, defineCli, type CliContext } from '@osdlc/cli-tool'
import { spawnRunner } from '@osdlc/command-seam'

import { PrepError, runPrep } from './run.ts'

const cli = defineCli({
  name: 'diffkit prep',
  summary: 'A JSON manifest of a change for review: files, groups, flags.',
  positionals: [{ name: 'pr', help: 'PR number to prep. Omit to prep the current branch.' }],
  flags: {
    base: {
      kind: 'string',
      valueName: 'ref',
      help: 'Ref to diff against (`<ref>...HEAD`). Default origin/main. Not with a PR or --worktree.',
    },
    head: {
      kind: 'string',
      valueName: 'ref',
      help: 'With --base: exactly `<base>..<head>` (two-dot) instead of the branch.',
    },
    worktree: {
      kind: 'boolean',
      help: 'Prep HEAD against the working tree, untracked files included.',
    },
    groupSize: {
      kind: 'string',
      valueName: 'n',
      help: 'Files per group before a package group is split. Default 12; 0 turns splitting off.',
    },
  },
})

export async function prepMain(argv: readonly string[], ctx: CliContext): Promise<number> {
  const { io } = ctx
  const parsed = cli.parse(argv, io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    io.stderr(`diffkit prep: ${parsed.message}\n`)
    return EXIT.usage
  }
  const v = parsed.values
  let pr: number | null = null
  const raw = parsed.positionals[0]
  if (raw !== undefined) {
    const n = Number(raw.replace(/^#/, ''))
    if (!Number.isInteger(n) || n <= 0) {
      io.stderr(`diffkit prep: not a PR number: '${raw}'\n`)
      return EXIT.usage
    }
    pr = n
  }
  let groupSize: number | undefined
  if (v.groupSize !== undefined) {
    groupSize = Number(v.groupSize)
    if (!/^\d+$/.test(v.groupSize) || !Number.isSafeInteger(groupSize)) {
      io.stderr(`diffkit prep: --group-size must be a whole number, 0 or more\n`)
      return EXIT.usage
    }
  }
  try {
    const manifest = runPrep(
      {
        cwd: ctx.cwd,
        pr,
        base: v.base ?? null,
        head: v.head ?? null,
        worktree: v.worktree,
        ...(groupSize === undefined ? {} : { thresholds: { groupSize } }),
      },
      { git: spawnRunner('git'), gh: spawnRunner('gh') },
    )
    io.stdout(`${JSON.stringify(manifest, null, 2)}\n`)
    return EXIT.ok
  } catch (e) {
    if (!(e instanceof PrepError)) throw e
    io.stderr(`diffkit prep: ${e.message}\n`)
    return e.usage ? EXIT.usage : EXIT.error
  }
}
