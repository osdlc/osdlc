/**
 * `@osdlc/diffkit` — descriptive statistics and a review-prep manifest for a
 * PR or branch diff.
 *
 * `runStats` is the whole pipeline over injectable git/gh runners;
 * `buildReport` + `renderReport` + `spliceBody` are the pure pieces under it.
 * `runPrep` is the sibling pipeline behind `diffkit prep`: a JSON manifest of
 * kept and dropped files, review groups by package root, and flags. `Change` and its resolvers (a PR, a commit pair, a branch,
 * the working tree) say what is being measured by either; `DiffkitError` is the
 * failure they raise for a caller to show as a message.
 */

export {
  COMMENT_START,
  SOURCE_EXT,
  isBlank,
  isCommentLine,
  isCommentOrBlank,
  isSource,
} from './core/heuristic.ts'
export {
  diffHeaderPath,
  parseDiff,
  unquoteCPath,
  type FileDiff,
  type FileStatus,
} from './core/diff.ts'
export { classifyLine, computeLineStats, fileGroup, isGenerated } from './core/lines.ts'
export { categorize, dependencyChange } from './core/categories.ts'
export { apiLanguage, diffApi, extractApi } from './core/api.ts'
export {
  defaultAnalyzers,
  lizardAnalyzer,
  parseLizardCsv,
  typescriptAnalyzer,
  type Analyzer,
} from './core/complexity.ts'
export { buildReport, type ReportOptions, type ReportPorts } from './stats/report.ts'
export { renderReport, type RenderOptions } from './stats/render.ts'
export { STATS_END, STATS_START, spliceBody } from './stats/splice.ts'
export { StatsError, runStats, type RunArgs, type RunEnv, type RunResult } from './stats/run.ts'
export { reportSchema, CATEGORIES, FILE_GROUPS, LINE_KINDS, type Report } from './core/types.ts'
export { DiffkitError } from './error.ts'
export {
  ChangeError,
  prDiff,
  readDiff,
  resolveBranch,
  resolvePr,
  resolveRange,
  resolveWorktree,
  selectChange,
  type Change,
  type ChangeSelector,
  type ChangeEnv,
} from './change.ts'
export {
  DEFAULT_GROUP_SIZE,
  DEFAULT_THRESHOLDS,
  PrepError,
  runPrep,
  type PrepArgs,
  type PrepEnv,
} from './prep/run.ts'
export {
  prepManifestSchema,
  type PrepFile,
  type PrepFlag,
  type PrepManifest,
  type PrepGroup,
  type Thresholds,
} from './prep/schema.ts'
export { PACKAGE_MARKERS, buildGroups, nearestRoot, packageRoots } from './prep/groups.ts'
export { splitEven } from './core/split.ts'
