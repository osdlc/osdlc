/**
 * The one failure type a diffkit command shows as a message, not a stack.
 * `usage` marks a fault in the command line rather than the repository, which
 * the CLI reports with the usage exit code.
 */

export class DiffkitError extends Error {
  /** True when the command line, not the repository, was at fault. */
  readonly usage: boolean
  constructor(message: string, usage = false) {
    super(message)
    this.usage = usage
  }
}
