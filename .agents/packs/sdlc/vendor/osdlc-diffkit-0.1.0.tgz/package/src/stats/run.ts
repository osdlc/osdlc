/**
 * The git/gh-facing half: fetch the diff, resolve base/head revisions, build
 * the report, optionally write the PR body. Everything goes through the
 * typed-git / typed-gh clients over an injectable runner.
 */

import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { Gh } from '@osdlc/typed-gh'
import { type CommandRunner } from '@osdlc/command-seam'
import { Git } from '@osdlc/typed-git'

import {
  ChangeError,
  prDiff,
  repoRoot,
  readDiff,
  resolvePr,
  selectChange,
  validateSelector,
  type Change,
} from '../change.ts'
import { DiffkitError } from '../error.ts'
import { buildReport, type ReportOptions, type ReportPorts } from './report.ts'
import { renderReport } from './render.ts'
import { spliceBody } from './splice.ts'
import type { Report } from '../core/types.ts'

/** A failure `runStats` raises for the caller to show as a message. */
export class StatsError extends DiffkitError {}

/**
 * What to measure, as the command line names it: a PR, `base` alone (the
 * branch, `base...HEAD`), `base` and `head` (exactly `base..head`), or the
 * working tree. With none of them: the branch against origin/main.
 */
export interface RunArgs {
  cwd: string
  /** PR number. Not with `base`, `head` or `worktree`. */
  pr: number | null
  /** Ref to diff against; default origin/main. Not with a PR or `worktree`. */
  base: string | null
  /** With `base`: the exact commit pair `base..head`. Needs `base`. */
  head?: string | null
  /** HEAD against the working tree, untracked files included. */
  worktree?: boolean
  write: boolean
  detail: boolean
  dryRun?: boolean
}

export interface RunEnv {
  git: CommandRunner
  gh: CommandRunner
  report?: ReportOptions
}

export interface RunResult {
  report: Report
  markdown: string
  written: boolean
}

export function runStats(args: RunArgs, env: RunEnv): RunResult {
  const head = args.head ?? null
  const worktree = args.worktree === true
  const selector = { pr: args.pr, base: args.base, head, worktree }

  const gh = new Gh(args.cwd, { runner: env.gh })
  // Git prints root-relative paths; read files from the same root (set once the selector is valid).
  let root = args.cwd
  const cenv = { cwd: root, git: env.git, gh: env.gh }

  let source: string
  let diff: string
  let ports: ReportPorts | null = null
  try {
    validateSelector(selector)
    if (args.write && args.pr === null) throw new StatsError('--write needs a PR number', true)
    root = tryRoot(args.cwd, env.git)
    cenv.cwd = root
    if (args.pr !== null) {
      source = `PR #${args.pr}`
      diff = prDiff(args.pr, cenv)
      // A head that is not in this checkout still gets line statistics.
      try {
        ports = changePorts(resolvePr(args.pr, cenv), root, env.git)
      } catch (e) {
        if (!(e instanceof ChangeError)) throw e
      }
    } else {
      const change = selectChange(selector, cenv)
      source = change.label
      diff = readDiff(change, cenv)
      ports = changePorts(change, root, env.git)
    }
  } catch (e) {
    if (!(e instanceof ChangeError)) throw e
    throw new StatsError(e.message, e.usage)
  }

  const report = buildReport(source, diff, ports, env.report)
  const markdown = renderReport(report, { detail: args.detail })

  let written = false
  if (args.write && args.pr !== null && args.dryRun !== true) {
    const view = gh.prView(args.pr, { fields: ['number', 'body'] })
    if (view === null) throw new StatsError(`could not read PR #${args.pr}`)
    // Always the compact form in the body, whatever was asked for on stdout.
    const next = spliceBody(view.body, renderReport(report))
    if (next !== view.body) gh.editPr(args.pr, { body: next })
    written = true
  }
  return { report, markdown, written }
}

/** Stands in for the working tree as the "after" revision of a worktree change. */
const WORKTREE_REV = '(worktree)'

function tryRoot(cwd: string, runner: CommandRunner): string {
  try {
    return repoRoot(cwd, runner)
  } catch (e) {
    if (e instanceof ChangeError) throw new StatsError(e.message, e.usage)
    throw e
  }
}

function changePorts(change: Change, cwd: string, runner: CommandRunner): ReportPorts {
  const git = new Git(cwd, { runner })
  return {
    baseRev: change.baseRev,
    headRev: change.headRev ?? WORKTREE_REV,
    showAtRev: (rev, path) => {
      if (rev !== WORKTREE_REV) return git.showAtRev(rev, path)
      try {
        return readFileSync(join(cwd, path), 'utf8')
      } catch {
        return null
      }
    },
  }
}
