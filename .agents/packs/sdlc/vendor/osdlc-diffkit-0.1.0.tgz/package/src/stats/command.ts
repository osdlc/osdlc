/**
 * `diffkit stats [<pr>|--base <ref> [--head <ref>]|--worktree] [--write] [--detail] [--json]` — the
 * `stats` subcommand. Works in any git repository with `gh` authenticated;
 * needs no sdlc.
 *
 * Exit codes: 0 on success, 1 when the diff could not be read or the PR body
 * could not be written, 2 on a malformed command line.
 */

import { EXIT, defineCli, type CliContext } from '@osdlc/cli-tool'
import { spawnRunner } from '@osdlc/command-seam'

import { StatsError, runStats } from './run.ts'

const cli = defineCli({
  name: 'diffkit stats',
  summary: 'Line, category, API and complexity statistics for a PR or branch diff.',
  positionals: [{ name: 'pr', help: 'PR number to measure. Omit to measure the current branch.' }],
  flags: {
    base: {
      kind: 'string',
      valueName: 'ref',
      help: 'Ref to diff against (`<ref>...HEAD`). Default origin/main. Not with a PR or --worktree.',
    },
    head: {
      kind: 'string',
      valueName: 'ref',
      help: 'With --base: measure exactly `<base>..<head>` (two-dot) instead of the branch.',
    },
    worktree: {
      kind: 'boolean',
      help: 'Measure HEAD against the working tree, untracked files included.',
    },
    write: { kind: 'boolean', help: "Write the statistics into the PR's body (needs a PR)." },
    detail: { kind: 'boolean', help: 'Long form: per-file list and every complexity mover.' },
    json: { kind: 'boolean', help: 'Print the structured report as JSON.' },
  },
})

export async function statsMain(argv: readonly string[], ctx: CliContext): Promise<number> {
  const { io } = ctx
  const parsed = cli.parse(argv, io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    io.stderr(`diffkit stats: ${parsed.message}\n`)
    return EXIT.usage
  }
  const v = parsed.values
  let pr: number | null = null
  const raw = parsed.positionals[0]
  if (raw !== undefined) {
    const n = Number(raw.replace(/^#/, ''))
    if (!Number.isInteger(n) || n <= 0) {
      io.stderr(`diffkit stats: not a PR number: '${raw}'\n`)
      return EXIT.usage
    }
    pr = n
  }
  try {
    const out = runStats(
      {
        cwd: ctx.cwd,
        pr,
        base: v.base ?? null,
        head: v.head ?? null,
        worktree: v.worktree,
        write: v.write,
        detail: v.detail,
      },
      { git: spawnRunner('git'), gh: spawnRunner('gh') },
    )
    io.stdout(v.json ? `${JSON.stringify(out.report, null, 2)}\n` : `${out.markdown}\n`)
    if (out.written) io.stderr(`diffkit stats: wrote the statistics into PR #${pr}\n`)
    return EXIT.ok
  } catch (e) {
    if (!(e instanceof StatsError)) throw e
    io.stderr(`diffkit stats: ${e.message}\n`)
    return e.usage ? EXIT.usage : EXIT.error
  }
}
