/**
 * Even-split grouping: the rule that turns one oversized list into slices of
 * at most `limit` items, spread evenly.
 *
 * This is the same rule as `shardFiles` in `packages/ts/agent-dev/src/plan.ts`
 * (`sdlc verify changes`, `verify.max_files_per_job`). diffkit stays free of
 * sdlc, so it keeps its own copy rather than importing agent-dev; if one rule
 * changes, change both.
 */

/**
 * Consecutive slices of `items`, each at most `limit` long. `limit <= 0`
 * disables splitting. Spread evenly rather than filled to the limit, so five
 * items over a limit of four become 3+2 and not 4+1: count = ceil(n / limit),
 * size = ceil(n / count).
 */
export function splitEven<T>(items: readonly T[], limit: number): T[][] {
  if (limit <= 0 || items.length <= limit) return [[...items]]
  const count = Math.ceil(items.length / limit)
  const size = Math.ceil(items.length / count)
  const slices: T[][] = []
  for (let i = 0; i < items.length; i += size) slices.push(items.slice(i, i + size))
  return slices
}
