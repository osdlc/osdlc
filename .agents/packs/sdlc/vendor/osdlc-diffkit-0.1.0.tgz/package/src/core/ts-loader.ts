/**
 * Load the `typescript` compiler API if some copy of it can be found.
 *
 * It is an optional peer: the project being measured usually has its own, so
 * resolution tries that first (from the working directory), then whatever this
 * package was installed beside. Absent both, callers fall back or skip, and say
 * so in the report.
 */

import { createRequire } from 'node:module'

export type TsModule = typeof import('typescript')

let cache: TsModule | null | undefined

/** True for a module that has the JS compiler API the flags need (TypeScript 7 native has none). */
export function isCompilerApi(mod: unknown): mod is TsModule {
  const m = mod as Partial<TsModule> | null
  return m != null && typeof m.createSourceFile === 'function' && m.ScriptKind !== undefined
}

export function loadTs(): TsModule | null {
  if (cache !== undefined) return cache
  cache = null
  for (const base of [`${process.cwd()}/`, import.meta.url]) {
    try {
      const mod: unknown = createRequire(base)('typescript')
      // TypeScript 7 (native) ships no JS compiler API; such a copy is skipped.
      if (isCompilerApi(mod)) {
        cache = mod
        break
      }
    } catch {
      // try the next place
    }
  }
  return cache
}
