/**
 * Change categories, from the diff alone. Each file lands in exactly one
 * category, first match wins:
 *
 * generated, deleted, added, renamed (any similarity), dependencies (a
 * dependency manifest whose dependency entries changed), docs, tests,
 * formatting (within each change block the removed and added lines pair up one
 * to one, in order, and differ only in whitespace outside string literals; a
 * line with a backtick, an unbalanced quote or a regex-looking token, a pure
 * move and a `\r` change all refuse, and leading indentation counts outside
 * the brace languages), config (the other non-source
 * files), comments (every changed line is a comment or blank), logic (the rest).
 *
 * Because added/deleted/renamed win over the content categories, a brand-new
 * test file is "added", not "tests". Heuristic limits: "formatting" compares
 * line by line, so a call re-wrapped across lines stays "logic" (kept for
 * review rather than risk hiding a change), as does a reorder. `-U0` gives no
 * context, so a whitespace edit in the middle of a multi-line string can only
 * be caught by its look (a gap between two words is compared exactly); "comments"
 * inherits the comment heuristic's floor.
 */

import type { FileDiff } from './diff.ts'
import { isCommentOrBlank, isSource } from './heuristic.ts'
import { basename, fileGroup } from './lines.ts'
import type { Category, FileGroup } from './types.ts'

export interface DepEntry {
  name: string
  version: string
}
export interface DepChange {
  file: string
  added: DepEntry[]
  removed: DepEntry[]
  bumped: { name: string; from: string; to: string }[]
}

const VERSIONISH = /^(?:[\^~<>=*]|\d|workspace:|npm:|github:|git\+|file:|link:|catalog:)/
const PKG_LINE = /^\s*"([^"]+)"\s*:\s*"([^"]*)"\s*,?\s*$/
const CARGO_SKIP = new Set([
  'name',
  'version',
  'edition',
  'license',
  'description',
  'authors',
  'repository',
  'homepage',
  'readme',
  'rust-version',
  'resolver',
  'path',
  'publish',
])
const CARGO_LINE = /^\s*([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]+)"|\{.*?version\s*=\s*"([^"]+)".*\})\s*$/

/** Dependency-looking entries in one side of a manifest diff. */
function depEntries(file: string, lines: readonly string[]): DepEntry[] {
  const base = basename(file)
  const out: DepEntry[] = []
  for (const l of lines) {
    if (base === 'package.json') {
      const m = PKG_LINE.exec(l)
      if (m !== null && m[1] !== 'version' && m[1] !== 'url' && VERSIONISH.test(m[2]!)) {
        out.push({ name: m[1]!, version: m[2]! })
      }
    } else if (base === 'Cargo.toml') {
      const m = CARGO_LINE.exec(l)
      if (m !== null && !CARGO_SKIP.has(m[1]!)) {
        out.push({ name: m[1]!, version: m[2] ?? m[3] ?? '' })
      }
    }
  }
  return out
}

/** Dependencies added, removed and bumped in a `package.json` / `Cargo.toml` diff; null for other files. */
export function dependencyChange(f: FileDiff): DepChange | null {
  const base = basename(f.path)
  if (base !== 'package.json' && base !== 'Cargo.toml') return null
  const add = depEntries(f.path, f.added)
  const rem = depEntries(f.path, f.removed)
  if (add.length === 0 && rem.length === 0) return null
  const remBy = new Map(rem.map((e) => [e.name, e.version]))
  const addBy = new Map(add.map((e) => [e.name, e.version]))
  const change: DepChange = { file: f.path, added: [], removed: [], bumped: [] }
  for (const e of add) {
    const before = remBy.get(e.name)
    if (before === undefined) change.added.push(e)
    else if (before !== e.version) change.bumped.push({ name: e.name, from: before, to: e.version })
  }
  for (const e of rem) if (!addBy.has(e.name)) change.removed.push(e)
  return change
}

/**
 * Languages whose meaning does not depend on layout: braces and semicolons
 * delimit. Everywhere else leading indentation counts as a change.
 */
const BRACE_LANGUAGE = /\.(?:tsx?|jsx?|mjs|cjs|json|rs|go|java|kt|c|h|cpp|hpp|cs|swift|s?css)$/

const WORD = /[A-Za-z0-9_$]/
const OPERATOR = /[-+*/%<>=!&|^~?:.]/

/** A `/…/` after an operator, bracket or line start, with string contents already blanked. */
const REGEX_LIKE =
  /(?:^|[=(,:;!&|?{}[\]+\-*%<>~^]|\breturn|\btypeof)\s*\/(?![/*])(?:[^/\\\n]|\\.)+\/[dgimsuvy]*/

/** True when removing the whitespace between `a` and `b` would fuse them into other tokens. */
function fuses(a: string, b: string): boolean {
  return (WORD.test(a) && WORD.test(b)) || (OPERATOR.test(a) && OPERATOR.test(b))
}

/**
 * The line with whitespace (spaces and tabs only: `\r` is content) dropped
 * outside string literals, except where it separates two word characters or
 * two operator characters; there the exact run is kept, since `a + +b` is not
 * `a++b`. Returns null when the line cannot be judged: an unbalanced quote
 * (also a stray apostrophe in a comment), a backtick, a heredoc or triple
 * quote, or a regex-looking token.
 */
function normalize(line: string): string | null {
  const triple = ['"', "'"].map((q) => q.repeat(3))
  if (line.includes('`') || line.includes('<<') || triple.some((t) => line.includes(t))) {
    return null
  }
  let out = ''
  let blanked = ''
  let quote = ''
  let pending = ''
  let prev = ''
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i]!
    if (quote !== '') {
      out += ch
      if (ch === '\\') {
        out += line[i + 1] ?? ''
        i += 1
      } else if (ch === quote) {
        quote = ''
        blanked += ch
      }
      continue
    }
    if (ch === ' ' || ch === '\t') {
      pending += ch
      continue
    }
    if (pending !== '' && prev !== '' && fuses(prev, ch)) out += pending
    pending = ''
    out += ch
    blanked += ch
    prev = ch
    if (ch === '"' || ch === "'") quote = ch
  }
  if (quote !== '') return null
  if (REGEX_LIKE.test(blanked)) return null
  return out
}

/** True when the diff only moved whitespace, block for block, outside string literals. */
function isFormattingOnly(f: FileDiff): boolean {
  if (f.hunks.length === 0) return false
  const brace = BRACE_LANGUAGE.test(f.path)
  for (const h of f.hunks) {
    // A block that only removes or only adds, or whose sizes differ, is a move or an edit.
    if (h.added.length !== h.removed.length || h.added.length === 0) return false
    for (let i = 0; i < h.added.length; i += 1) {
      const after = h.added[i]!
      const before = h.removed[i]!
      if (!brace && /^[ \t]*/.exec(after)![0] !== /^[ \t]*/.exec(before)![0]) return false
      const a = normalize(after)
      const b = normalize(before)
      if (a === null || b === null || a !== b) return false
    }
  }
  return true
}

export function categorize(f: FileDiff): Category {
  const group: FileGroup = fileGroup(f.path)
  if (group === 'generated') return 'generated'
  if (f.status === 'deleted') return 'deleted'
  if (f.status === 'added') return 'added'
  if (f.status === 'renamed') return 'renamed'
  if (dependencyChange(f) !== null) return 'dependencies'
  if (group === 'docs') return 'docs'
  if (group === 'tests') return 'tests'
  const changed = f.added.length + f.removed.length
  if (changed > 0 && isFormattingOnly(f)) return 'formatting'
  if (group === 'other') return 'config'
  if (
    changed > 0 &&
    isSource(f.path) &&
    f.added.every(isCommentOrBlank) &&
    f.removed.every(isCommentOrBlank)
  ) {
    return 'comments'
  }
  return 'logic'
}
