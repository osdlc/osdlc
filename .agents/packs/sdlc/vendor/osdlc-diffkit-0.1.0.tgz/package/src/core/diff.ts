/**
 * Parse a unified diff (any context width) into per-file records.
 *
 * Hunk-aware: once a `@@` header announces how many old and new lines follow,
 * exactly that many `-`/`+` lines are body, so a removed line whose text begins
 * with `-- ` (rendered `--- `) is not mistaken for a file header.
 */

export type FileStatus = 'added' | 'deleted' | 'modified' | 'renamed'

/** One run of removed lines and the added lines that replace it, with no context between. */
export interface Hunk {
  removed: string[]
  added: string[]
}

export interface FileDiff {
  /** The new path; for a deleted file, the path it had. */
  path: string
  /** The path before a rename, else null. */
  oldPath: string | null
  status: FileStatus
  /** Rename similarity in percent, else null. */
  similarity: number | null
  binary: boolean
  /** Added line bodies, without the `+`. */
  added: string[]
  /** The line number in the new file of each entry of `added`. */
  addedAt: number[]
  /** Removed line bodies, without the `-`. */
  removed: string[]
  /** The same lines as `added`/`removed`, grouped into change blocks in file order. */
  hunks: Hunk[]
}

const HUNK = /^@@ -\d+(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/

const C_ESCAPES: Record<string, number> = {
  a: 0x07,
  b: 0x08,
  f: 0x0c,
  n: 0x0a,
  r: 0x0d,
  t: 0x09,
  v: 0x0b,
  '\\': 0x5c,
  '"': 0x22,
}

/**
 * A name git wrote C-quoted (`"w\303\251\"rd.ts"`): the text between the quotes
 * with `\n`-style and three-digit octal escapes decoded, the octal bytes read
 * as UTF-8. Text that is not wrapped in double quotes comes back unchanged.
 */
export function unquoteCPath(text: string): string {
  if (text.length < 2 || !text.startsWith('"') || !text.endsWith('"')) return text
  const bytes: number[] = []
  const inner = text.slice(1, -1)
  for (let i = 0; i < inner.length; i += 1) {
    const ch = inner[i]!
    if (ch !== '\\') {
      bytes.push(...Buffer.from(ch, 'utf-8'))
      continue
    }
    const octal = /^[0-7]{1,3}/.exec(inner.slice(i + 1))
    if (octal !== null) {
      bytes.push(Number.parseInt(octal[0], 8))
      i += octal[0].length
      continue
    }
    const next = inner[i + 1]
    const code = next === undefined ? undefined : C_ESCAPES[next]
    if (code === undefined) {
      bytes.push(0x5c)
    } else {
      bytes.push(code)
      i += 1
    }
  }
  return Buffer.from(bytes).toString('utf-8')
}

/**
 * The file a `+++ ` or `--- ` header line names, or null for `/dev/null`.
 * Git appends a TAB after a name that holds spaces and C-quotes one with a
 * quote, a control character or a non-ASCII byte; both are undone. The `a/` or
 * `b/` prefix is stripped, so callers pass `--src-prefix=a/ --dst-prefix=b/`
 * (and `-c diff.noprefix=false`) to pin it against the user's git config.
 */
export function diffHeaderPath(line: string): string | null {
  let name = line.slice(4)
  if (!name.startsWith('"')) {
    const tab = name.indexOf('\t')
    if (tab >= 0) name = name.slice(0, tab)
  }
  name = unquoteCPath(name)
  if (name === '/dev/null') return null
  return /^[ab]\//.test(name) ? name.slice(2) : name
}

/** `b/<path>` out of `diff --git a/<old> b/<new>`; the fallback when no `+++` names it. */
function headerPath(line: string): string | null {
  const quoted = line.lastIndexOf(' "b/')
  if (line.endsWith('"') && quoted >= 0) return unquoteCPath(line.slice(quoted + 1)).slice(2)
  const i = line.lastIndexOf(' b/')
  return i < 0 ? null : line.slice(i + 3)
}

export function parseDiff(diff: string): FileDiff[] {
  const files: FileDiff[] = []
  let cur: FileDiff | null = null
  let oldLeft = 0
  let newLeft = 0
  let newLine = 0
  let block: Hunk | null = null

  for (const raw of diff.split('\n')) {
    if (oldLeft > 0 || newLeft > 0) {
      if (raw.startsWith('\\')) continue
      const sign = raw[0]
      if (sign === '-' && oldLeft > 0) {
        oldLeft -= 1
        cur?.removed.push(raw.slice(1))
        if (cur !== null) {
          if (block === null || block.added.length > 0) {
            block = { removed: [], added: [] }
            cur.hunks.push(block)
          }
          block.removed.push(raw.slice(1))
        }
        continue
      }
      if (sign === '+' && newLeft > 0) {
        newLeft -= 1
        cur?.added.push(raw.slice(1))
        cur?.addedAt.push(newLine)
        if (cur !== null) {
          if (block === null) {
            block = { removed: [], added: [] }
            cur.hunks.push(block)
          }
          block.added.push(raw.slice(1))
        }
        newLine += 1
        continue
      }
      if (sign === ' ') {
        block = null
        oldLeft -= 1
        newLeft -= 1
        newLine += 1
        continue
      }
      // Malformed hunk: stop trusting the counts and fall through to header parsing.
      oldLeft = 0
      newLeft = 0
    }

    if (raw.startsWith('diff --git ')) {
      const path = headerPath(raw)
      cur = {
        path: path ?? '',
        oldPath: null,
        status: 'modified',
        similarity: null,
        binary: false,
        added: [],
        addedAt: [],
        removed: [],
        hunks: [],
      }
      block = null
      files.push(cur)
    } else if (cur === null) {
      continue
    } else if (raw.startsWith('new file mode')) {
      cur.status = 'added'
    } else if (raw.startsWith('deleted file mode')) {
      cur.status = 'deleted'
    } else if (raw.startsWith('similarity index ')) {
      cur.similarity = Number.parseInt(raw.slice('similarity index '.length), 10)
    } else if (raw.startsWith('rename from ')) {
      cur.status = 'renamed'
      cur.oldPath = unquoteCPath(raw.slice('rename from '.length))
    } else if (raw.startsWith('rename to ')) {
      cur.path = unquoteCPath(raw.slice('rename to '.length))
    } else if (raw.startsWith('Binary files ') || raw.startsWith('GIT binary patch')) {
      cur.binary = true
    } else if (raw.startsWith('+++ ')) {
      // The `+++` side is authoritative (paths with spaces make the header ambiguous).
      const path = diffHeaderPath(raw)
      if (path !== null) cur.path = path
    } else if (raw.startsWith('--- ')) {
      // A deleted file has `+++ /dev/null`; the `---` side then names it.
      const path = diffHeaderPath(raw)
      if (path !== null && cur.status === 'deleted') cur.path = path
    } else {
      const m = HUNK.exec(raw)
      if (m !== null) {
        block = null
        oldLeft = m[1] === undefined ? 1 : Number(m[1])
        newLine = Number(m[2])
        newLeft = m[3] === undefined ? 1 : Number(m[3])
      }
    }
  }
  return files
}
