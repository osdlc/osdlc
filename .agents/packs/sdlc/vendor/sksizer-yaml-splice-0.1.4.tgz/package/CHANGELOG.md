# Changelog

## [Unreleased]

First public release. Edits top-level fields of a YAML mapping in place, on bytes: set, remove
or rename a field, and every byte outside the edited span stays as it was, including comments,
key order, quoting, a BOM and line endings. It runs the `yaml-splice` Rust crate through
WebAssembly, so it has no runtime dependencies and no native code.

### Fixed

- `Set` on a quoted value with a comment after it (`title: 'Draft'  # note`) no longer deletes
  the comment.
- `Set` on a block scalar (`|` or `>`) no longer joins the next key onto the new value's line,
  and `Remove` on one no longer deletes the next line too.
- A comment indented less than a block scalar is kept: `Set` no longer joins it onto the new
  value's line, and `Remove` no longer deletes it.
- An empty block scalar (`a: |`, also with a tag or an anchor) can now be set and removed. Both
  were refused.
- When a new value is written as a block, the old value's trailing comment moves to the block's
  header line instead of becoming part of the value.
- A keep-chomped (`|+`) value keeps its trailing line breaks: setting `"kept\n\n"` no longer
  writes `"kept\n"`.
- `editYaml` checks each edit against what it asked for. It throws
  `EditError('InvalidResult', …)` when an edit would change the value or order of a key it does
  not address, or when the addressed key would not read back as set, removed or renamed. Before,
  it returned that document. A `.nan` value in another key no longer counts as a change.

## History before the first public release

These versions were never published. They are rebuilt from the git history.

### [0.1.3] - 2026-09-07 (unpublished)

#### Fixed

- `editYaml` refuses `NaN`, `Infinity` and `-Infinity` anywhere in a `Set` value, nested values
  included, with `EditError('UnrenderableValue', …)` before any byte is written. Before, they
  were written as YAML `null`.

### [0.1.2] - 2026-09-06 (unpublished)

#### Fixed

- The built entry (`dist/`) loads under Node. It imported the WebAssembly glue from a path the
  build did not create.

### [0.1.1] - 2026-07-21 (unpublished)

#### Fixed

- `EditError.span` is a truly optional property, so it type-checks under a consumer's
  `exactOptionalPropertyTypes`.

### [0.1.0] - 2026-07-21 (unpublished)

#### Added

- `editYaml(source, edits)`: set, remove or rename top-level fields of a YAML mapping without
  reserializing it, with the types `FieldEdit`, `EditValue`, `EditOutcome`, `EditError`,
  `EditErrorCode` and `EditSpan`.
