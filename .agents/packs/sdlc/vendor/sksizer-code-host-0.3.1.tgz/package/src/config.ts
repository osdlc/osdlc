/**
 * The `code_host` config section: which adapter `selectCodeHost` picks. The
 * package owns it and sdlc mounts it ([[D-CXJE-config-sections-and-standalone-tools]]).
 */

import { z } from 'zod'

import { defineConfigSection } from '@osdlc/config-layers'

export const codeHostSection = defineConfigSection({
  key: 'code_host',
  schema: z
    .object({
      override: z
        .enum(['github', 'forgejo'])
        .nullable()
        .default(null)
        .describe(
          "Force which CodeHost adapter `selectCodeHost`'s callers use, bypassing auto-detection from the `origin` remote's URL. Null (the default) auto-detects: a `github.com` remote uses the GitHub adapter, anything else uses Forgejo.",
        ),
    })
    .strict()
    .prefault({})
    .describe(
      'Which code host the PR commands, the orchestrator `prs` tick, `session focus` and `project doctor` talk to, via `selectCodeHost`. `pr survey`/`pr update` (the standalone `@sksizer/pr-update` package) and the dashboard read GitHub directly and do not consult this key yet. Every key has a default, so this block is optional.',
    ),
  meta: {
    category: 'integration',
    consumers: ['src/select.ts#selectCodeHost'],
    layers: ['project', 'local'],
    applies_via: 'read',
    enforcement: 'read',
    runs_in: ['cli', 'loop'],
  },
})
